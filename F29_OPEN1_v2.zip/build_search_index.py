#!/usr/bin/env python3
"""build_search_index.py — DEV_SPEC §2 정본 + OPEN-1 입력 어댑터.
정본 구조(스키마 {c,n,m,t} · B-1 검증 · tempfile+rename · version/generated_at) 유지.
OPEN-1 최소 변경(입력 어댑터만):
  · 종목 원천 = --stocks-dir 의 <code>.json (code,name만 읽음)  ← 정본 SRC_ALL {code:name} 대체
  · 서비스 가능 = --stock-root 의 <code>/index.html 실재 + code [0-9A-Z]{6}  ← 정본 SRC_UNIVERSE 대체
  · OPEN 검색 노출 집합 = (stocks_public 코드) ∩ (실제 stock 착지 코드)
  · Lite 미존재 → 노출 집합 전부 t='f'. 개수 하드코딩 없음.
norm()은 정본 normalize.norm 사양(NFKC→UPPER→[^0-9A-Z가-힣] 제거)을 인라인(라우터 f29-search.js norm과 동일).
"""
import argparse, glob, hashlib, json, os, re, sys, tempfile, datetime, unicodedata

CODE_RE = re.compile(r'[0-9A-Z]{6}')

def norm(s):  # == normalize.norm (정본) == f29-search.js norm (라우터)
    return re.sub(r'[^0-9A-Z가-힣]', '', unicodedata.normalize('NFKC', str(s)).upper())

def fail(msg):
    print('[search_index][ERROR] %s' % msg, file=sys.stderr); sys.exit(1)

def load_stocks_public(d):
    """<code>.json 에서 code,name만. 중복 코드·빈 정규화명 검증."""
    recs, dups = {}, []
    for p in sorted(glob.glob(os.path.join(d, '*.json'))):
        try:
            o = json.load(open(p, encoding='utf-8'))
        except Exception as e:
            fail('JSON 구문 오류: %s (%s)' % (p, e))
        code = str(o.get('code', '')).strip()
        name = o.get('name', '')
        if not code:
            fail('필수 필드 code 누락: %s' % p)
        if not name:
            fail('필수 필드 name 누락: %s' % code)
        if not CODE_RE.fullmatch(code):
            fail('코드계약 위반 [0-9A-Z]{6}: %s' % code)
        if norm(name) == '':
            fail('빈 정규화명: %s (%r)' % (code, name))
        if code in recs:
            dups.append(code)
        recs[code] = name
    if dups:
        fail('원천 중복 코드: %s' % sorted(set(dups)))
    return recs

def landing_codes(stock_root):
    s = set()
    for name in sorted(os.listdir(stock_root)):
        if CODE_RE.fullmatch(name) and os.path.isfile(os.path.join(stock_root, name, 'index.html')):
            s.add(name)
    return s

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--stocks-dir', required=True)   # /root/krx-moneyflow/output/stocks_public
    ap.add_argument('--stock-root', required=True)   # /var/www/f29-stock
    ap.add_argument('--aliases', required=True)      # aliases_kr.json
    ap.add_argument('--out', required=True)          # 출력 경로 (CLI, production 경로는 OPEN-2)
    a = ap.parse_args()

    src = load_stocks_public(a.stocks_dir)           # {code: name}
    land = landing_codes(a.stock_root)               # {code}
    open_codes = set(src) & land                     # OPEN 검색 노출 집합 (교집합)
    if not open_codes:
        fail('OPEN 노출 집합 0건 (stocks_public ∩ stock 착지)')

    stocks, name_norms = [], {}
    for code in sorted(open_codes):
        m = norm(src[code])
        stocks.append({'c': code, 'n': src[code], 'm': m, 't': 'f'})   # Lite 미존재 → 전부 f
        name_norms.setdefault(m, []).append(code)

    aliases = json.load(open(a.aliases, encoding='utf-8'))
    norm_aliases, b1, missing = {}, 0, []
    for alias, code in aliases.items():
        al = norm(alias); code = str(code).strip()
        if al == '':
            fail('통칭 "%s" 정규화 결과 빈 문자열' % alias)
        if al in name_norms:                                   # B-1 정식명 충돌
            b1 += 1; fail('B-1 충돌: 통칭 "%s"(%s) == 정식명 %s' % (alias, al, name_norms[al]))
        if code not in open_codes:                             # 타깃이 OPEN 집합에 존재
            missing.append('%s->%s' % (alias, code))
        if al in norm_aliases:                                 # alias 정규화 중복
            fail('통칭 정규화 중복: "%s" vs 기존 %s' % (alias, norm_aliases[al]))
        norm_aliases[al] = code
    if missing:
        fail('alias 타깃 OPEN 집합 부재: %s' % missing)

    for m, codes in name_norms.items():
        if len(codes) > 1:
            print('[search_index][WARN] 동명 정규화 %s: %s — 라우터 후보 리스트' % (m, codes), file=sys.stderr)

    out = {'version': 'v1.9.1',
           'generated_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'index_size': len(stocks), 'universe_size': len(stocks),  # OPEN=전부 f
           'stocks': stocks, 'aliases': norm_aliases}

    # 출력 JSON 필수 필드·개수 자기검증
    assert all(set(s) == {'c', 'n', 'm', 't'} for s in out['stocks']), '스키마 필드 오류'
    assert out['index_size'] == len(out['stocks']) == len(open_codes), '개수 불일치'
    assert len(out['aliases']) == len(aliases), 'alias 개수 불일치'

    d = os.path.dirname(os.path.abspath(a.out)) or '.'
    fd, tmp = tempfile.mkstemp(dir=d)
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, separators=(',', ':'))
    os.chmod(tmp, 0o644); os.replace(tmp, a.out)                # tempfile 작성 후 rename

    raw = open(a.out, 'rb').read()
    print('[search_index] OK source=%d landing=%d intersection=%d aliases=%d b1=%d missing=%d out_sha=%s out_bytes=%d'
          % (len(src), len(land), len(open_codes), len(norm_aliases), b1, len(missing),
             hashlib.sha256(raw).hexdigest(), len(raw)), file=sys.stderr)

if __name__ == '__main__':
    main()
