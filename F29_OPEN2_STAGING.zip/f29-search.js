/* f29-search.js — v1.9.1+D1 (D-1 코드 계약 개정 2026-07-13). 의존: f29-metrics.js (F29M.track) */
(function () {
  'use strict';
  const track = (typeof F29M !== 'undefined' && F29M && typeof F29M.track === 'function') ? F29M.track.bind(F29M) : function () {};
  let IDX = null, exactMap = null;

  function norm(s) {
    return s.normalize('NFKC').toUpperCase().replace(/[^0-9A-Z가-힣]/g, '');
  }
  // C-2: innerHTML 삽입값 이스케이프 — 내부 데이터 포함 (적합성 항목, lock 비차단)
  function esc(s) {
    return String(s).replace(/[&<>"']/g, c =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  async function loadIndex() {
    if (IDX) return IDX;
    const r = await fetch('/data/search_index.json', { cache: 'no-cache' });
    IDX = await r.json();
    exactMap = new Map();
    for (const s of IDX.stocks) {
      if (!exactMap.has(s.m)) exactMap.set(s.m, []);
      exactMap.get(s.m).push(s);
    }
    return IDX;
  }

  // 미국 인식: {별칭|티커 → 정식 티커} Map — 한글 별칭 원문을 앵커에 붙이는 구현 금지 (마스터 C-1)
  const US_ALIAS = new Map([
    ['NVDA','NVDA'],['엔비디아','NVDA'],['AAPL','AAPL'],['애플','AAPL'],
    ['MSFT','MSFT'],['마이크로소프트','MSFT'],['TSLA','TSLA'],['테슬라','TSLA'],
    ['GOOGL','GOOGL'],['GOOG','GOOGL'],['구글','GOOGL'],['AMZN','AMZN'],['아마존','AMZN'],
    ['META','META'],['메타','META'],['AMD','AMD'],['MU','MU'],['마이크론','MU'],
    ['DELL','DELL'],['델','DELL'],['INTC','INTC'],['인텔','INTC'],
    ['AVGO','AVGO'],['브로드컴','AVGO'],['TSM','TSM'],['QCOM','QCOM'],['퀄컴','QCOM']
  ]); // [ADAPT] Money Flow 유니버스와 동기화. 키는 대문자 고정
  const CRYPTO = { '비트코인':'btc','BTC':'btc','비트':'btc','이더리움':'eth','ETH':'eth','이더':'eth' };

  function route(q) {
    const m = norm(q);
    if (!m) return { type: 'fail' };
    if (/^[0-9A-Z]{6}$/.test(m)) {                              // ① 코드 — D-1: 영숫자 6자 계약 (예: 005930, 0126Z0)
      const hit = IDX.stocks.find(s => s.c === m);
      if (hit) return { type: 'kr_code', stock: hit };
      // D-1 부수 규정: 코드 패턴이지만 인덱스 미등재 → 즉시 실패하지 않고 ②~⑦ 계속
      // (영숫자 6자 정식명이 ①에 선점되어 죽는 회귀 방지. 순수 숫자 미등재 코드도 동일 경로로 ⑦ 도달)
    }
    const ex = exactMap.get(m);                                 // ② 정식명 완전
    if (ex) return ex.length === 1 ? { type: 'kr_exact', stock: ex[0] }
                                   : { type: 'kr_exact', list: ex };
    if (IDX.aliases[m]) {                                       // ③ 통칭 완전
      const hit = IDX.stocks.find(s => s.c === IDX.aliases[m]);
      return { type: 'kr_alias', stock: hit };
    }
    const pre = IDX.stocks.filter(s => s.m.startsWith(m));      // ④ 접두
    if (pre.length === 1) return { type: 'kr_partial', stock: pre[0] };
    if (pre.length >= 2)  return { type: 'kr_partial', list: rankCandidates(pre).slice(0, 10) };
    const usKey = q.trim().toUpperCase();                        // ⑤ 미국 — 별칭은 티커로 변환
    if (US_ALIAS.has(usKey)) return { type: 'us', ticker: US_ALIAS.get(usKey) };
    if (CRYPTO[usKey] || CRYPTO[q.trim()])                       // ⑥ 크립토
      return { type: 'crypto', asset: CRYPTO[usKey] || CRYPTO[q.trim()] };
    return { type: 'fail' };                                     // ⑦ 실패
  }

  // 후보 정렬: Full 우선 → 이름 가나다. (거래대금 정렬은 인덱스에 필드 없음 — P1 검토)
  function rankCandidates(arr) {
    return arr.slice().sort((a, b) =>
      (a.t === b.t) ? a.n.localeCompare(b.n, 'ko') : (a.t === 'f' ? -1 : 1));
  }

  function go(res, qtype) {
    track('search_submit', { query_type: qtype });
    if (res.stock) {
      track('search_result_click', { code: res.stock.c, query_type: qtype });
      location.href = `/stock/${res.stock.c}/?ref=search`;
    }
  }

  function submit(q) {
    const res = route(q);
    switch (res.type) {
      case 'kr_code': case 'kr_exact': case 'kr_alias': case 'kr_partial':
        if (res.stock) return go(res, res.type);
        track('search_submit', { query_type: res.type });
        return renderCandidates(res.list, res.type);            // 자동 이동 금지
      case 'us':
        track('search_submit', { query_type: 'us' });
        return location.href = `/moneyflow/#stock-${res.ticker}`; // [ADAPT] 앵커 규격, 배너는 착지 측
      case 'crypto':
        track('search_submit', { query_type: 'crypto' });
        return location.href = `/index.html?asset=${res.asset}`;
      default:
        track('search_submit', { query_type: 'fail' });
        track('search_no_result', { q: q.trim().slice(0, 20) });
        return renderFail();
    }
  }

  function renderCandidates(list, qtype) {
    const box = document.getElementById('f29-search-results');
    box.innerHTML = list.map(s =>
      `<button class="f29-cand" data-code="${s.c}">${esc(s.n)}</button>`).join('');
    box.hidden = false;
    box.querySelectorAll('.f29-cand').forEach(b => b.addEventListener('click', () => {
      track('search_result_click', { code: b.dataset.code, query_type: qtype });
      location.href = `/stock/${b.dataset.code}/?ref=search`;
    }));
  }

  function renderFail() {
    const box = document.getElementById('f29-search-results');
    box.innerHTML = `<div class="f29-fail">현재 F29 데이터에서 이 종목을 찾지 못했습니다.<br>
      종목명 또는 6자리 코드를 다시 확인해주세요. 통칭보다 정식 종목명이 정확합니다.</div>`;
    box.hidden = false;
  }

  window.F29Search = {
    async init(inputEl) {
      await loadIndex();
      inputEl.addEventListener('focus', () => track('search_focus', {}), { once: true });
      inputEl.addEventListener('keydown', e => { if (e.key === 'Enter' && inputEl.value.trim()) submit(inputEl.value); });
    }
  };
})();
