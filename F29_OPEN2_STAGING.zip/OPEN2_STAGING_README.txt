F29 OPEN-2 반입 번들 (승인 바이트 — production apply용)

수록 파일 SHA-256 (unzip 후 sha256sum으로 검증):
  740765b358b41cdea8048c09611087e08c4f09b4a6731729210309ef2f433b3b  open2_apply.sh
  45fdce0e861ddc48fd259cd1ac160ff20d06a29d26ab17a8826c2fbe8ff49393  apply_open2_portal.py
  fc8675537336b74c4fac06beec9bcd581444488e0e17520475f55f006542d47f  f29-search.js
  2bd3e02acf38565ccd558b50222c313c24471f634f3f27db1785800cc31c2836  portal_css_block.txt
  65febedbad7000d5fbcdd5a27361b1a5f2436118a562e058331157215eda3653  portal_script_block.txt

실행: bash open2_apply.sh  (승인된 10단계, 실패 시 4개 백업 자동 복원)
전제: /tmp/search_index.open1.json (OPEN-1 산출물) 존재.
STEP 10(브라우저 스모크)은 스크립트 완료 후 수동.
