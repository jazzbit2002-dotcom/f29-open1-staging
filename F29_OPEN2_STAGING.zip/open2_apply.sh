#!/usr/bin/env bash
# F29 OPEN-2 production apply — 승인된 10단계. 실패 시 4개 백업 자동 복원.
set -euo pipefail
STAGE="$(cd "$(dirname "$0")" && pwd)"
ROUTER=/var/www/f29/assets/f29-search.js
PORTAL=/var/www/f29-portal/index.html
DATADIR=/var/www/f29-portal/data
INDEXJSON=$DATADIR/search_index.json
NGINX=/etc/nginx/sites-enabled/f29
SRCINDEX=/tmp/search_index.open1.json
ROUTER_SHA_EXPECT=fc8675537336b74c4fac06beec9bcd581444488e0e17520475f55f006542d47f
TS=$(date -u +%Y%m%dT%H%M%SZ)
BK=/root/f29-backups/open2-$TS
mkdir -p "$BK"

INDEX_PREEXIST=0; [ -f "$INDEXJSON" ] && INDEX_PREEXIST=1
NGINX_RELOADED=0

restore() {
  echo "!!! 실패 감지 — 백업 복원 시작"
  [ -f "$BK/f29-search.js" ]   && cp -p "$BK/f29-search.js" "$ROUTER"
  [ -f "$BK/index.html" ]      && cp -p "$BK/index.html" "$PORTAL"
  [ -f "$BK/f29.nginx" ]       && cp -p "$BK/f29.nginx" "$NGINX"
  if [ "$INDEX_PREEXIST" = "1" ]; then [ -f "$BK/search_index.json" ] && cp -p "$BK/search_index.json" "$INDEXJSON";
  else rm -f "$INDEXJSON"; fi
  if [ "$NGINX_RELOADED" = "1" ] || nginx -t 2>/dev/null; then nginx -t && systemctl reload nginx && echo "nginx 원복 reload 완료" || echo "WARN nginx reload 원복 실패 — 수동 확인 필요"; fi
  echo "!!! 복원 종료 (프로덕션 = apply 이전 상태)"
}
trap restore ERR

echo "=== STEP 1: 백업 4개 ($BK) ==="
cp -p "$ROUTER" "$BK/f29-search.js"
cp -p "$PORTAL" "$BK/index.html"
cp -p "$NGINX"  "$BK/f29.nginx"
[ "$INDEX_PREEXIST" = "1" ] && cp -p "$INDEXJSON" "$BK/search_index.json" || echo "  (search_index.json 신규 — 백업 없음)"
ls -la "$BK"

echo "=== STEP 2: 포털 patch dry-run (staging 복사본, live 미대상) ==="
cp -p "$PORTAL" "$STAGE/index.staging.html"
python3 "$STAGE/apply_open2_portal.py" --target "$STAGE/index.staging.html" --css "$STAGE/portal_css_block.txt" --script "$STAGE/portal_script_block.txt"
grep -c 'id="f29-search-results"' "$STAGE/index.staging.html.open2candidate"

echo "=== STEP 3: 라우터 후보 node --check ==="
if command -v node >/dev/null 2>&1; then node --check "$STAGE/f29-search.js" && echo "  node --check PASS";
else echo "  WARN node 부재 — 샌드박스 node --check PASS(SHA $ROUTER_SHA_EXPECT)로 무결성 대체"; fi
GOT=$(sha256sum "$STAGE/f29-search.js" | cut -d' ' -f1)
[ "$GOT" = "$ROUTER_SHA_EXPECT" ] || { echo "라우터 후보 SHA 불일치"; false; }
echo "  후보 SHA 일치"

echo "=== STEP 4: search_index.json 배치 (mode 644) ==="
[ -f "$SRCINDEX" ] || { echo "$SRCINDEX 부재 — OPEN-1 재실행 필요"; false; }
mkdir -p "$DATADIR"
install -m 644 "$SRCINDEX" "$INDEXJSON"
stat -c '%a %U:%G %s bytes' "$INDEXJSON"

echo "=== STEP 5: nginx exact-match location 추가 ==="
python3 - "$NGINX" <<'PYEOF'
import sys
p=sys.argv[1]; s=open(p,encoding='utf-8').read()
ANC='    location = /stock { return 308 /stock/; }'
BLK=('    location = /data/search_index.json {\n'
     '        alias /var/www/f29-portal/data/search_index.json;\n'
     '        default_type application/json;\n'
     '        add_header Cache-Control "no-cache";\n'
     '    }\n')
if 'location = /data/search_index.json' in s:
    sys.stderr.write('[nginx] 이미 존재 — 중복 방지 중단\n'); sys.exit(1)
if s.count(ANC)!=1:
    sys.stderr.write('[nginx] 앵커 count!=1\n'); sys.exit(1)
s=s.replace(ANC, BLK+ANC, 1)
open(p,'w',encoding='utf-8',newline='').write(s)
print('[nginx] location 추가 완료')
PYEOF

echo "=== STEP 6: nginx -t ==="
nginx -t

echo "=== STEP 7: nginx reload ==="
systemctl reload nginx; NGINX_RELOADED=1; echo "  reload 완료"

echo "=== STEP 8: 라우터 후보 배치 ==="
install -m 644 "$STAGE/f29-search.js" "$ROUTER"
sha256sum "$ROUTER"

echo "=== STEP 9: 포털 --apply (live) ==="
python3 "$STAGE/apply_open2_portal.py" --target "$PORTAL" --css "$STAGE/portal_css_block.txt" --script "$STAGE/portal_script_block.txt" --apply

trap - ERR
echo ""
echo "############ POST-APPLY 확인 ############"
echo "portal index mode: $(stat -c '%a %U:%G' $PORTAL)"
echo "router SHA       : $(sha256sum $ROUTER | cut -d' ' -f1)"
echo "  (기대 $ROUTER_SHA_EXPECT)"
echo "구 v1.1 마커     : $(grep -c 'PATCH:f29-portal-search:v1.1' $PORTAL || true)"
echo "v2.0 START       : $(grep -c 'PATCH:f29-portal-search:v2.0 START' $PORTAL || true)"
echo "v2.0 END         : $(grep -c 'PATCH:f29-portal-search:v2.0 END' $PORTAL || true)"
echo "f29-search-results: $(grep -c 'id=\"f29-search-results\"' $PORTAL || true)"
echo "--- /data/search_index.json HTTP ---"
curl -s -o /dev/null -w "  HTTP %{http_code}\n" https://f29.io/data/search_index.json
echo "--- index JSON 필드 ---"
python3 - <<'PYEOF'
import json
d=json.load(open('/var/www/f29-portal/data/search_index.json'))
print('  index_size   =', d.get('index_size'))
print('  universe_size=', d.get('universe_size'))
print('  aliases      =', len(d.get('aliases',{})))
print('  stocks       =', len(d.get('stocks',[])))
bad=[x['c'] for x in d.get('stocks',[]) if not __import__('re').match(r'^[0-9A-Z]{6}$', x['c'])]
print('  code형식 위반 =', len(bad))
PYEOF
echo "--- nginx config test ---"
nginx -t 2>&1 | tail -1
echo "############ apply 완료 — 브라우저 스모크(STEP 10)는 수동 ############"
