#!/usr/bin/env python3
# OPEN-2 포털 배선 apply (L2) — literal-anchor str.replace 3연산 + 마커 span 삭제.
# §8: 리터럴 앵커만, whole-file rewrite 금지, 각 앵커 count 검증, 실패 시 무변경 종료.
# 사용: python3 apply_open2_portal.py --target <index.html> --css <css.txt> --script <script.txt> [--apply]
import sys, argparse, os, tempfile

CSS_ANCHOR = '  #searchEmpty{display:block;margin-top:8px;font-size:.8rem;color:var(--txt3);text-align:center}\n</style>'
CONTAINER_ANCHOR = '      <div id="stockSearchResults" style="display:none"></div>\n'
CONTAINER_ADD    = '      <div id="f29-search-results" hidden></div>\n'
SPAN_START = '<!-- PATCH:f29-portal-search:v1.1 START -->'
SPAN_END   = '<!-- PATCH:f29-portal-search:v1.1 END -->'

def fail(m):
    sys.stderr.write('[open2-portal][ERROR] '+m+'\n'); sys.exit(1)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--target',required=True)
    ap.add_argument('--css',required=True)
    ap.add_argument('--script',required=True)
    ap.add_argument('--apply',action='store_true')
    a=ap.parse_args()
    src=open(a.target,encoding='utf-8').read()
    css_block=open(a.css,encoding='utf-8').read()
    script_block=open(a.script,encoding='utf-8').read().rstrip('\n')

    # --- anchor count gate (each must be exactly 1) ---
    for name,anc,n in [('CSS_ANCHOR',CSS_ANCHOR,1),('CONTAINER_ANCHOR',CONTAINER_ANCHOR,1),
                       ('SPAN_START',SPAN_START,1),('SPAN_END',SPAN_END,1)]:
        c=src.count(anc)
        if c!=n: fail(f'{name} count={c} (expected {n})')
    if 'id="f29-search-results"' in src: fail('타깃에 이미 f29-search-results 존재 — 중복 적용 방지')
    if 'PATCH:f29-portal-search:v2.0' in src: fail('타깃에 이미 v2.0 마커 존재 — 중복 적용 방지')

    # --- op1: CSS insert before </style> ---
    out=src.replace(CSS_ANCHOR, CSS_ANCHOR.replace('\n</style>', '\n'+css_block+'</style>'), 1)
    # --- op2: container div after #stockSearchResults ---
    out=out.replace(CONTAINER_ANCHOR, CONTAINER_ANCHOR+CONTAINER_ADD, 1)
    # --- op3: remove entire v1.1 span (marker-to-marker inclusive), insert v2.0 block ---
    si=out.index(SPAN_START); ei=out.index(SPAN_END)+len(SPAN_END)
    if ei<=si: fail('SPAN_END가 SPAN_START보다 앞')
    out=out[:si]+script_block+out[ei:]

    # --- post checks ---
    if out.count('id="f29-search-results"')!=1: fail('post: f29-search-results count!=1')
    if 'PATCH:f29-portal-search:v1.1' in out: fail('post: 구 v1.1 마커 잔존')
    if out.count('PATCH:f29-portal-search:v2.0 START')!=1 or out.count('PATCH:f29-portal-search:v2.0 END')!=1:
        fail('post: v2.0 마커 쌍 이상')
    if 'f29-search.js?v=20260713a' not in out: fail('post: 라우터 script 참조 부재')
    if out.count('id="stockSearch"')<1 or out.count('id="searchBtn"')<1: fail('post: 기존 input/btn 훼손')

    sys.stderr.write(f'[open2-portal] OK in_bytes={len(src.encode())} out_bytes={len(out.encode())} '
                     f'delta={len(out.encode())-len(src.encode())}\n')
    if a.apply:
        d=os.path.dirname(os.path.abspath(a.target))
        mode=os.stat(a.target).st_mode & 0o777          # 대상 기존 권한 보존 (mkstemp 기본 600 유출 방지)
        fd,tmp=tempfile.mkstemp(dir=d)
        with os.fdopen(fd,'w',encoding='utf-8',newline='') as f: f.write(out)
        os.chmod(tmp,mode)
        os.replace(tmp,a.target)
        sys.stderr.write(f'[open2-portal] APPLIED mode={oct(os.stat(a.target).st_mode & 0o777)}\n')
    else:
        open(a.target+'.open2candidate','w',encoding='utf-8',newline='').write(out)
        sys.stderr.write('[open2-portal] DRYRUN wrote '+a.target+'.open2candidate\n')

if __name__=='__main__': main()
