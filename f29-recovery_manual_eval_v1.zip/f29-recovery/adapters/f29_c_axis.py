"""
f29_c_axis.py — C축(derivatives_quality) adapter.

스펙 §5-C 계약:
- 기존 F29 위험 엔진의 정규화 산출을 **읽기 전용**으로 소비한다.
- raw CVD·OI·펀딩·청산 값을 다시 독립 점수화하지 않는다.
- 실제 JSON 필드 바인딩은 서버 샘플·필드 사전 감사 후 adapter에서만 수행한다.

필드 사전 감사 (2026-07-16, /api/internal/pro 실측):
  updated                      ISO8601 UTC(ms) — 기준 시각
  pro.btcBucket / flowBtc / premBtcDir / cvdBtcDir / transition   이산 라벨
  pro.gates{demand,flow,price,structure}                          MET|UNMET
  pro.btcPos / premBtc / cvdBtc / structBtc                       연속값

derivatives_pressure 매핑:
  위험 엔진은 normal|strong|overheated 에 해당하는 단일 정규화 라벨을
  노출하지 않는다. 매핑 규칙을 코드에서 발명하는 것은 H3 위반이므로,
  매핑은 config/c_axis_mapping.json 의 비준된 mapping 으로만 주입한다.
  mapping 이 null(UNRATIFIED)이면 unknown 을 반환한다 — unknown ≠ inactive.
"""

from __future__ import annotations

import json
import os
import urllib.request
from datetime import datetime, timezone

VALID_PRESSURE = ("normal", "strong", "overheated", "unknown")


class CAxisError(Exception):
    pass


def _load_mapping(base: str) -> dict:
    path = os.path.join(base, "config", "c_axis_mapping.json")
    with open(path, "rb") as f:
        return json.loads(f.read().decode("utf-8"))


def fetch_f29_pro(url: str = "http://127.0.0.1:3000/api/internal/pro",
                  input_file: str | None = None) -> dict:
    """읽기 전용 취득. input_file 지정 시 파일에서(샌드박스 검증용)."""
    if input_file:
        with open(input_file, "rb") as f:
            return json.loads(f.read().decode("utf-8"))
    with urllib.request.urlopen(url, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))


def build_c_observation(doc: dict, base: str, now_utc: str | None = None) -> dict:
    """
    F29 내부 JSON → C축 정규화 관측치.
    반환 dict:
      derivatives_pressure: normal|strong|overheated|unknown
      observation_time / available_at / ingested_at (UTC ISO)
      provenance: 감사된 이산·연속 필드 스냅샷 (재점수화 없음, 기록만)
      trace: 판정 근거
    """
    if now_utc is None:
        now_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    updated = doc.get("updated")
    pro = doc.get("pro")
    trace = []

    if not isinstance(pro, dict) or not updated:
        return {
            "derivatives_pressure": "unknown",
            "observation_time": updated,
            "available_at": updated,
            "ingested_at": now_utc,
            "provenance": {},
            "trace": ["pro 블록 또는 updated 부재 -> unknown"],
        }

    # provenance: 감사된 필드만 스냅샷 (값 기록 — 분류·재점수화 없음)
    provenance = {
        "updated": updated,
        "btcBucket": pro.get("btcBucket"),
        "flowBtc": pro.get("flowBtc"),
        "premBtc": pro.get("premBtc"),
        "premBtcDir": pro.get("premBtcDir"),
        "cvdBtc": pro.get("cvdBtc"),
        "cvdBtcDir": pro.get("cvdBtcDir"),
        "btcPos": pro.get("btcPos"),
        "structBtc": pro.get("structBtc"),
        "gates": pro.get("gates"),
        "transition": pro.get("transition"),
    }

    mapping_doc = _load_mapping(base)
    mapping = mapping_doc.get("mapping")

    if mapping is None or mapping_doc.get("status") != "RATIFIED":
        trace.append(
            "c_axis_mapping UNRATIFIED(null) -> derivatives_pressure=unknown "
            "(매핑 발명 금지 — H3 절차·비준 후 config 주입)"
        )
        pressure = "unknown"
    else:
        # 비준된 매핑: {"field": "pro.<name>", "table": {<라벨>: <pressure>}}
        field = mapping.get("field", "")
        table = mapping.get("table", {})
        key = field.split(".", 1)[1] if field.startswith("pro.") else field
        raw = pro.get(key)
        pressure = table.get(str(raw), "unknown")
        if pressure not in VALID_PRESSURE:
            raise CAxisError(f"비준 매핑이 유효 enum 밖 값 반환: {pressure}")
        trace.append(f"비준 매핑 적용: {field}={raw} -> {pressure}")

    return {
        "derivatives_pressure": pressure,
        "observation_time": updated,
        "available_at": updated,
        "ingested_at": now_utc,
        "provenance": provenance,
        "trace": trace,
    }
