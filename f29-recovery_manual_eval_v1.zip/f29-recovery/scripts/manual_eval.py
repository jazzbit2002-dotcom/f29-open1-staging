"""
manual_eval.py — 수동 1회 평가 (cron 없음, 명시 실행 전용).

관제 2단계: 서버 배치 후 기존 합법 데이터(F29 내부 위험 엔진)만 연결해
수동 1회 평가 JSON을 생성한다.

권리 근거: f29_internal_risk_engine = internal_shadow/derived_retention/
raw_retention 전부 allowed (RECOVERY_USAGE_RIGHTS §sources). A(Realized
Price)·B(현물 CVD)·E(확산)는 권리 pending 또는 미연결 → missing 으로
정직 기록. 빠진 축을 확인된 것으로 간주하지 않는다.

사용:
  python3 scripts/manual_eval.py --kind daily              # preliminary (기본)
  python3 scripts/manual_eval.py --kind us_close           # canonical
  python3 scripts/manual_eval.py --input sample.json       # 파일 입력(검증용)

출력: snapshots/shadow_latest.json + ledger/evaluations.jsonl 1행 append.
공개 파일은 release gate hold 이므로 생성되지 않는다.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)

from engine import canon
from engine.models import RecoveryConfig
from engine import blockers as BLK
from engine.blockers import BlockerInputs
from engine import state_machine as SM
from engine.state_machine import PersistentState, PillarSnapshot
from engine import writers as WR
from adapters.f29_c_axis import fetch_f29_pro, build_c_observation

STATE_PATH = os.path.join(BASE, "ledger", "state.json")
LEDGER_PATH = os.path.join(BASE, "ledger", "evaluations.jsonl")
CANON_IDX_PATH = os.path.join(BASE, "ledger", "canonical_index.json")


def load_state() -> dict:
    if os.path.exists(STATE_PATH):
        with open(STATE_PATH, "rb") as f:
            return json.loads(f.read().decode("utf-8"))
    return {
        "effective_stage": "B1",
        "effective_stage_age_days": 0,
        "promotion_streaks": {"B3": 0, "B4": 0, "B5": 0},
        "maintenance_breach_streak": 0,
        "spot_confirmed_anchor": None,
        "spot_weakness_streak": 0,
    }


def save_state(d: dict) -> None:
    os.makedirs(os.path.dirname(STATE_PATH), exist_ok=True)
    tmp = STATE_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(tmp, STATE_PATH)


def ledger_has(evaluation_id: str) -> bool:
    if not os.path.exists(LEDGER_PATH):
        return False
    with open(LEDGER_PATH, "r", encoding="utf-8") as f:
        for line in f:
            try:
                if json.loads(line).get("evaluation_id") == evaluation_id:
                    return True
            except Exception:
                continue
    return False


def ledger_append(record: dict) -> None:
    os.makedirs(os.path.dirname(LEDGER_PATH), exist_ok=True)
    with open(LEDGER_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def update_canonical_index(market_date: str, evaluation_id: str) -> None:
    idx = {}
    if os.path.exists(CANON_IDX_PATH):
        with open(CANON_IDX_PATH, "rb") as f:
            idx = json.loads(f.read().decode("utf-8"))
    idx[market_date] = evaluation_id
    tmp = CANON_IDX_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(idx, f, ensure_ascii=False, indent=2)
    os.replace(tmp, CANON_IDX_PATH)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--kind", choices=["daily", "us_close"], default="daily")
    ap.add_argument("--url", default="http://127.0.0.1:3000/api/internal/pro")
    ap.add_argument("--input", default=None, help="파일 입력(검증용, URL 대신)")
    ap.add_argument("--market-date", default=None, help="기본: 오늘(UTC)")
    args = ap.parse_args()

    now = datetime.now(timezone.utc)
    now_iso = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    market_date = args.market_date or now.strftime("%Y-%m-%d")
    is_preliminary = args.kind == "daily"
    evaluation_id = f"{market_date}.{args.kind}"

    print("=== [1] 정본 SHA 재검사 ===")
    canon.verify_contracts(BASE)
    print("  정본 3종 PASS")

    print("=== [2] F29 내부 JSON 취득 (읽기 전용) ===")
    doc = fetch_f29_pro(url=args.url, input_file=args.input)
    c_obs = build_c_observation(doc, BASE, now_utc=now_iso)
    print(f"  updated={c_obs['observation_time']}")
    print(f"  derivatives_pressure={c_obs['derivatives_pressure']}")
    for t in c_obs["trace"]:
        print(f"  trace: {t}")

    print("=== [3] pillar 스냅샷 (미연결 축 = missing, 추정 금지) ===")
    snap = PillarSnapshot(
        a_state="unconfirmed", a_fresh="missing",       # Realized Price 권리 pending
        b_state="unconfirmed", b_fresh="missing",       # 현물 CVD 미연결
        b_maturity="provisional",                        # source_bindings 계약
        e_state="unconfirmed", e_fresh="missing",       # 확산 미연결
        derivatives_pressure=c_obs["derivatives_pressure"],
    )
    print("  A=missing / B=missing(provisional) / E=missing / C=위 실측")

    print("=== [4] blocker 판정 ===")
    st = load_state()
    cfg = RecoveryConfig.from_runtime(BASE)  # 운영 config: 전부 null — B1 평가는 임계값 불요
    sw_state = BLK.eval_spot_weakness(
        snap.b_state, snap.b_fresh, snap.b_maturity,
        st["spot_confirmed_anchor"], st["spot_weakness_streak"],
        history_sufficient=st["spot_confirmed_anchor"] is not None, cfg=cfg,
    )
    binp = BlockerInputs(
        spot_state=snap.b_state, spot_freshness=snap.b_fresh,
        spot_maturity=snap.b_maturity,
        structure_state=snap.a_state, structure_freshness=snap.a_fresh,
        derivatives_pressure=snap.derivatives_pressure,
    )
    blockers = {
        "derivatives_led": BLK.eval_derivatives_led(binp),
        "derivatives_overheated": BLK.eval_derivatives_overheated(binp),
        "structure_break": BLK.eval_structure_break(binp, sw_state),
    }
    spot_weakness = {
        "state": sw_state,
        "confirmed_anchor": st["spot_confirmed_anchor"],
        "weakness_streak": st["spot_weakness_streak"],
    }
    print(f"  {blockers}  spot_weakness={sw_state}")

    print("=== [5] 상태기계 평가 ===")
    prev = PersistentState(
        effective_stage=st["effective_stage"],
        effective_stage_age_days=st["effective_stage_age_days"],
        promotion_streaks=dict(st["promotion_streaks"]),
        maintenance_breach_streak=st["maintenance_breach_streak"],
    )
    r = SM.evaluate(prev, snap, blockers, spot_weakness, cfg,
                    is_preliminary=is_preliminary)
    # 핵심축(A·B) missing → 공개 stage 갱신 불가 상태
    status = "data_delayed"
    print(f"  candidate={r.candidate_stage} effective={r.effective_stage} "
          f"status={status} frozen={r.frozen_reason}")

    print("=== [6] ledger append (append-only) ===")
    rerun = ledger_has(evaluation_id)
    record = {
        "evaluation_id": evaluation_id,
        "market_date": market_date,
        "kind": "preliminary" if is_preliminary else "canonical",
        "is_canonical": not is_preliminary,
        "rerun": rerun,
        "evaluated_at": now_iso,
        "candidate_stage": r.candidate_stage,
        "effective_stage": r.effective_stage,
        "ceiling_sources": r.ceiling_sources,
        "promotion_streaks": r.promotion_streaks,
        "maintenance_breach_streak": r.maintenance_breach_streak,
        "effective_stage_age_days": r.effective_stage_age_days,
        "blockers": r.blockers,
        "spot_weakness": spot_weakness,
        "status": status,
        "reproducibility": "decision_replay",
        "c_axis_provenance": c_obs["provenance"],
        "c_axis_trace": c_obs["trace"],
        "rights_matrix_sha256": canon.RIGHTS_SHA,
        "compliance_version": "recovery-compliance.1",
    }
    ledger_append(record)
    print(f"  {evaluation_id} 기록 (rerun={rerun})")

    if not is_preliminary and not rerun:
        # canonical: 영속 상태 갱신 (spot run 은 B축 missing → 동결)
        anchor, streak = BLK.update_spot_weakness_run(
            st["spot_confirmed_anchor"], st["spot_weakness_streak"],
            snap.b_state, snap.b_fresh, snap.b_maturity, evaluation_id,
        )
        save_state({
            "effective_stage": r.effective_stage,
            "effective_stage_age_days": r.effective_stage_age_days,
            "promotion_streaks": r.promotion_streaks,
            "maintenance_breach_streak": r.maintenance_breach_streak,
            "spot_confirmed_anchor": anchor,
            "spot_weakness_streak": streak,
        })
        update_canonical_index(market_date, evaluation_id)
        print("  영속 상태 갱신 (canonical)")
    else:
        print("  영속 상태 불변 (preliminary 또는 rerun)")

    print("=== [7] shadow 기록 (내부 전용, 공개 경로 밖) ===")
    shadow_payload = {
        "market_date": market_date,
        "evaluation_id": evaluation_id,
        "is_canonical": not is_preliminary,
        "candidate_stage": r.candidate_stage,
        "effective_stage": r.effective_stage,
        "ceiling": min(r.ceiling_applied, key=lambda c: SM.STAGE_ORDINAL[c]) if r.ceiling_applied else None,
        "ceiling_sources": r.ceiling_sources,
        "effective_stage_age_days": r.effective_stage_age_days,
        "promotion_streaks": r.promotion_streaks,
        "maintenance_breach_streak": r.maintenance_breach_streak,
        "blockers": r.blockers,
        "spot_weakness": spot_weakness,
        "pillars": {
            "structure": {"state": snap.a_state, "freshness": snap.a_fresh},
            "spot_demand": {"state": snap.b_state, "freshness": snap.b_fresh,
                            "maturity": snap.b_maturity},
            "derivatives_quality": {"pressure": snap.derivatives_pressure,
                                    "freshness": "fresh"},
            "breadth": {"state": snap.e_state, "freshness": snap.e_fresh},
        },
        "status": status,
        "reproducibility": "decision_replay",
    }
    sp = WR.write_shadow_latest(os.path.join(BASE, "snapshots"), shadow_payload)
    print(f"  {sp}")

    print("=== [8] 공개 파일 미생성 확인 (release gate hold) ===")
    out_dir = os.path.join(BASE, "output")
    pubs = [f for f in os.listdir(out_dir) if f.endswith(".json")] if os.path.isdir(out_dir) else []
    print(f"  output/ 공개 JSON: {pubs if pubs else '없음 (정상 — hold)'}")

    print("\n=== 수동 1회 평가 완료 ===")
    return 0


if __name__ == "__main__":
    sys.exit(main())
