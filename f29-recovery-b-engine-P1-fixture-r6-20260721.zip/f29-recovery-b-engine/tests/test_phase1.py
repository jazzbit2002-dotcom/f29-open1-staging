"""Phase 1 fixture suite.

Every contract has a paired negative test: the bypass attempt must raise.
No loose behaviour is pinned as acceptable anywhere in this file.
"""
import json
import os
import sqlite3
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engine import contracts, guard, statespace  # noqa: E402
from engine.adapters import etf_core_ro  # noqa: E402
from engine.errors import (  # noqa: E402
    EnvelopeContractError,
    LedgerContractError,
    MaturityContractError,
    ReplayContractError,
    TimeContractError,
    WriteGuardError,
)
from engine.ledger import CanonicalLedger  # noqa: E402
from engine.statespace import StageState, evaluate  # noqa: E402

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG = os.path.join(BASE, "config", "engine_config.json")
ENGINE_DIR = os.path.join(BASE, "engine")


def payload(day, *, A="RECOVERED", B="SPOT_LED", C="HEALTHY", E="CONFIRMED",
            maturity="validated", data="ok", structure="inactive",
            dled="inactive", dover="inactive", spotweak="inactive",
            kind="us_close", **extra):
    d = "2026-07-%02d" % day
    body = {
        "evaluation_id": "%s.%s" % (d, kind),
        "market_date": d,
        "kind": kind,
        "evaluation_cutoff": "%sT21:30:00+00:00" % d,
        "pillars": {"A": A, "B": B, "C": C, "E": E},
        "blockers": {
            "structure_break": structure,
            "spot_weakness": spotweak,
            "derivatives_led": dled,
            "derivatives_overheated": dover,
        },
        "b_maturity": maturity,
        "data_status": data,
        "observations": {
            "core_etf": {
                "available_at": "%sT20:00:00+00:00" % d,
                "source_as_of": "%sT00:00:00+00:00" % d,
            }
        },
    }
    body.update(extra)
    return body


def env(day, **kw):
    return contracts.build_envelope(payload(day, **kw), CONFIG, engine_dir=ENGINE_DIR)


CFG = contracts.load_config(CONFIG)
D = CFG["promotion_consecutive_days"]
W = CFG["maintenance_breach_days"]
S_MAX = CFG["S_max"]


def run(days_kwargs, start=None):
    state = start or StageState()
    for i, kw in enumerate(days_kwargs, start=1):
        state = evaluate(state, env(i, **kw), CFG)
    return state


class TestConfigInjection(unittest.TestCase):
    def test_thresholds_come_from_config(self):
        self.assertGreaterEqual(D, 1)
        self.assertGreaterEqual(W, 1)
        self.assertGreaterEqual(S_MAX, 1)
        with open(os.path.join(ENGINE_DIR, "statespace.py")) as _fh:
            src = _fh.read()
        self.assertIn('cfg["promotion_consecutive_days"]', src)
        self.assertIn('cfg["maintenance_breach_days"]', src)
        self.assertIn('cfg["S_max"]', src)
        # no literal threshold constants in the transition logic
        self.assertNotIn("promotion_streak >= 3", src)

    def test_missing_config_key_fails(self):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as fh:
            json.dump({"promotion_consecutive_days": 3}, fh)
            p = fh.name
        with self.assertRaises(EnvelopeContractError):
            contracts.load_config(p)
        os.unlink(p)


class TestPromotionStreak(unittest.TestCase):
    def test_promotes_after_D_consecutive(self):
        # from B1 it takes D evaluations per step; check the first step lands
        state = run([{}] * D)
        self.assertEqual(state.effective_stage, "B2")
        self.assertEqual(state.promotion_streak, 0)

    def test_does_not_promote_at_D_minus_1(self):
        state = run([{}] * (D - 1))
        self.assertEqual(state.effective_stage, "B1")
        self.assertEqual(state.promotion_streak, D - 1)

    def test_streak_resets_when_conditions_lapse(self):
        state = run([{}] * (D - 1) + [{"A": "BROKEN", "B": "NO_DEMAND"}])
        self.assertEqual(state.promotion_streak, 0)


class TestCeilingTruthTable(unittest.TestCase):
    def test_derivatives_led_ceils_at_B2(self):
        s = evaluate(StageState(), env(1, dled="active"), CFG)
        self.assertEqual(s.ceiling_stage, "B2")
        self.assertIn("blocker:derivatives_led", s.ceiling_sources)

    def test_overheated_ceils_at_B3(self):
        s = evaluate(StageState(), env(1, dover="active"), CFG)
        self.assertEqual(s.ceiling_stage, "B3")

    def test_alt_breadth_collapse_blocks_B4_B5(self):
        for e_state in ("COLLAPSING", "BTC_ONLY"):
            s = evaluate(StageState(), env(1, E=e_state), CFG)
            self.assertEqual(s.ceiling_stage, "B3", e_state)

    def test_provisional_cannot_reach_B3_candidate(self):
        s = evaluate(StageState(), env(1, maturity="provisional"), CFG)
        self.assertEqual(s.candidate_stage, "B2")
        self.assertIn("maturity:spot_demand:provisional", s.ceiling_sources)

    def test_derivatives_led_blocks_promotion_to_B4(self):
        state = StageState(effective_stage="B3")
        for i in range(D + 2):
            state = evaluate(state, env(i + 1, dled="active"), CFG)
        self.assertNotIn(state.effective_stage, ("B4", "B5"))


class TestMaturityAuthority(unittest.TestCase):
    def test_provisional_cannot_satisfy_B3_axis(self):
        p = payload(1, maturity="provisional")
        self.assertFalse(statespace.b_axis_satisfied(p, statespace._rank("B3")))
        self.assertTrue(statespace.b_axis_satisfied(p, statespace._rank("B2")))

    def test_no_promotion_path_exists(self):
        with self.assertRaises(MaturityContractError):
            statespace.promote_maturity("spot_demand")


class TestStructureBreak(unittest.TestCase):
    def test_immediate_B1_regardless_of_streak(self):
        state = StageState(effective_stage="B4", promotion_streak=D - 1,
                           maintenance_breach_streak=1, stage_age=40)
        s = evaluate(state, env(1, structure="active"), CFG)
        self.assertEqual(s.effective_stage, "B1")
        self.assertEqual(s.promotion_streak, 0)
        self.assertEqual(s.maintenance_breach_streak, 0)
        self.assertEqual(s.status, "structure_break")


class TestDowngrade(unittest.TestCase):
    def test_downgrades_after_W_consecutive_breach(self):
        state = StageState(effective_stage="B4")
        for i in range(W):
            state = evaluate(state, env(i + 1, dled="active"), CFG)
        self.assertEqual(state.effective_stage, "B3")

    def test_holds_at_W_minus_1(self):
        state = StageState(effective_stage="B4")
        for i in range(W - 1):
            state = evaluate(state, env(i + 1, dled="active"), CFG)
        self.assertEqual(state.effective_stage, "B4")
        self.assertEqual(state.maintenance_breach_streak, W - 1)


class TestFreeze(unittest.TestCase):
    def test_unknown_blocker_freezes_promotion_without_downgrade(self):
        state = StageState(effective_stage="B3", promotion_streak=D - 1)
        s = evaluate(state, env(1, dled="unknown"), CFG)
        self.assertTrue(s.frozen)
        self.assertEqual(s.effective_stage, "B3")
        self.assertEqual(s.promotion_streak, D - 1)  # held, not advanced
        self.assertIn("blocker_unknown:derivatives_led", s.freeze_reasons)

    def test_unknown_pillar_freezes(self):
        s = evaluate(StageState(effective_stage="B3"), env(1, E="UNKNOWN"), CFG)
        self.assertTrue(s.frozen)
        self.assertEqual(s.effective_stage, "B3")

    def test_unknown_is_never_treated_as_safe(self):
        clean = evaluate(StageState(), env(1), CFG)
        unk = evaluate(StageState(), env(1, dled="unknown"), CFG)
        self.assertGreater(
            statespace._rank(clean.effective_stage) + clean.promotion_streak,
            statespace._rank(unk.effective_stage) + unk.promotion_streak - 1,
        )
        self.assertTrue(unk.frozen)

    def test_data_delayed_freezes_and_flags_after_S_max(self):
        state = StageState(effective_stage="B3")
        for i in range(S_MAX):
            state = evaluate(state, env(i + 1, data="stale"), CFG)
            self.assertEqual(state.status, "frozen")
        state = evaluate(state, env(S_MAX + 1, data="stale"), CFG)
        self.assertEqual(state.status, "data_delayed_exceeded")
        self.assertEqual(state.effective_stage, "B3")  # freeze never downgrades


class TestSingleAxisNegatives(unittest.TestCase):
    """v1.4 section 28.4: single soft signals must not move the stage."""

    def test_exchange_inflow_alone_does_not_downgrade(self):
        base = evaluate(StageState(effective_stage="B3"), env(1), CFG)
        with_inflow = evaluate(
            StageState(effective_stage="B3"),
            env(1, exchange_inflow_spike=True, exchange_netflow=12345.0),
            CFG,
        )
        self.assertEqual(base.effective_stage, with_inflow.effective_stage)
        self.assertEqual(base.maintenance_breach_streak,
                         with_inflow.maintenance_breach_streak)

    def test_etf_slowing_alone_is_not_structure_break(self):
        s = evaluate(StageState(effective_stage="B3"),
                     env(1, etf_flow_state="SLOWING"), CFG)
        self.assertNotEqual(s.status, "structure_break")
        self.assertEqual(s.effective_stage, "B3")


class TestTimeContract(unittest.TestCase):
    def test_future_available_at_rejected(self):
        p = payload(1)
        p["observations"]["core_etf"]["available_at"] = "2026-07-02T00:00:00+00:00"
        with self.assertRaises(TimeContractError):
            contracts.build_envelope(p, CONFIG, engine_dir=ENGINE_DIR)

    def test_naive_timestamp_rejected(self):
        p = payload(1)
        p["observations"]["core_etf"]["available_at"] = "2026-07-01T00:00:00"
        with self.assertRaises(TimeContractError):
            contracts.build_envelope(p, CONFIG, engine_dir=ENGINE_DIR)

    def test_missing_required_time_field_rejected(self):
        p = payload(1)
        del p["observations"]["core_etf"]["available_at"]
        with self.assertRaises(TimeContractError):
            contracts.build_envelope(p, CONFIG, engine_dir=ENGINE_DIR)

    def test_no_invented_field_is_required(self):
        # ingested_at is not part of the v1.4 field set; absence must be fine
        p = payload(1)
        self.assertNotIn("ingested_at", p["observations"]["core_etf"])
        contracts.build_envelope(p, CONFIG, engine_dir=ENGINE_DIR)


class TestTrustBoundary(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.led = CanonicalLedger(self.tmp, CONFIG, private_roots=(self.tmp,),
                                   engine_dir=ENGINE_DIR)

    def test_direct_construction_refused(self):
        with self.assertRaises(EnvelopeContractError):
            contracts.ValidatedEnvelope(payload(1), "x", "y", "z", object())
        with self.assertRaises(TypeError):
            contracts.ValidatedEnvelope(payload(1), "x", "y")

    def test_raw_dict_cannot_be_appended(self):
        with self.assertRaises(LedgerContractError):
            self.led.append(payload(1), CFG)

    def test_missing_required_field_rejected(self):
        p = payload(1)
        del p["b_maturity"]
        with self.assertRaises(EnvelopeContractError):
            contracts.build_envelope(p, CONFIG, engine_dir=ENGINE_DIR)

    def test_null_field_rejected(self):
        p = payload(1)
        p["blockers"]["structure_break"] = None
        with self.assertRaises(EnvelopeContractError):
            contracts.build_envelope(p, CONFIG, engine_dir=ENGINE_DIR)

    def test_stripped_sha_rejected_on_load(self):
        p = payload(1)
        p["engine_code_sha256"] = contracts.engine_code_sha256(ENGINE_DIR)
        p["config_sha256"] = contracts.config_sha256(CONFIG)
        del p["engine_code_sha256"]
        with self.assertRaises(EnvelopeContractError):
            contracts.load_envelope(p, CONFIG, engine_dir=ENGINE_DIR)

    def test_caller_assembled_sha_rejected(self):
        p = payload(1)
        p["engine_code_sha256"] = "f" * 64
        p["config_sha256"] = contracts.config_sha256(CONFIG)
        with self.assertRaises(EnvelopeContractError):
            contracts.load_envelope(p, CONFIG, engine_dir=ENGINE_DIR)

    def test_append_has_no_supersedes_parameter(self):
        import inspect
        sig = inspect.signature(CanonicalLedger.append)
        self.assertNotIn("supersedes", sig.parameters)


class TestRevisionPath(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.led = CanonicalLedger(self.tmp, CONFIG, private_roots=(self.tmp,),
                                   engine_dir=ENGINE_DIR)
        self.state = StageState()
        for i in (1, 2, 3):
            self.state = self.led.append(env(i), CFG)

    def test_nonexistent_supersedes_rejected(self):
        e = contracts.build_envelope(
            dict(payload(3), evaluation_id="2026-07-03.us_close.r1"),
            CONFIG, engine_dir=ENGINE_DIR)
        with self.assertRaises(LedgerContractError):
            self.led.revise(e, CFG, "DOES_NOT_EXIST", "reason")

    def test_wrong_market_date_rejected(self):
        e = contracts.build_envelope(
            dict(payload(2), evaluation_id="2026-07-02.us_close.r1"),
            CONFIG, engine_dir=ENGINE_DIR)
        with self.assertRaises(LedgerContractError):
            self.led.revise(e, CFG, "2026-07-03.us_close", "reason")

    def test_mid_history_revision_rejected(self):
        # day 2 is not the latest market_date; revising it would leave day 3
        # stored state stale and break the replay invariant
        e = contracts.build_envelope(
            dict(payload(2), evaluation_id="2026-07-02.us_close.r1"),
            CONFIG, engine_dir=ENGINE_DIR)
        with self.assertRaises(LedgerContractError):
            self.led.revise(e, CFG, "2026-07-02.us_close", "mid-history")

    def test_missing_reason_rejected(self):
        e = contracts.build_envelope(
            dict(payload(3), evaluation_id="2026-07-03.us_close.r1"),
            CONFIG, engine_dir=ENGINE_DIR)
        with self.assertRaises(LedgerContractError):
            self.led.revise(e, CFG, "2026-07-03.us_close", "  ")

    def test_valid_revision_preserves_replay_invariant(self):
        e = contracts.build_envelope(
            dict(payload(3, dled="active"), evaluation_id="2026-07-03.us_close.r1"),
            CONFIG, engine_dir=ENGINE_DIR)
        self.led.revise(e, CFG, "2026-07-03.us_close", "issuer restated")
        self.assertTrue(self.led.verify_replay_invariant(CFG))

    def test_backdated_append_rejected(self):
        with self.assertRaises(LedgerContractError):
            self.led.append(env(2), CFG)


class TestReplay(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.led = CanonicalLedger(self.tmp, CONFIG, private_roots=(self.tmp,),
                                   engine_dir=ENGINE_DIR)

    def test_same_input_same_verdict(self):
        a = evaluate(StageState(), env(1), CFG)
        b = evaluate(StageState(), env(1), CFG)
        self.assertEqual(a.to_dict(), b.to_dict())

    def test_stored_equals_full_replay(self):
        for i in range(1, 8):
            self.led.append(env(i), CFG)
        self.assertTrue(self.led.verify_replay_invariant(CFG))

    def test_replay_rejects_entry_with_stripped_sha(self):
        self.led.append(env(1), CFG)
        with open(self.led.path) as _fh:
            rows = [json.loads(l) for l in _fh if l.strip()]
        del rows[0]["envelope"]["engine_code_sha256"]
        with open(self.led.path, "w") as fh:
            for r in rows:
                fh.write(json.dumps(r, sort_keys=True) + "\n")
        with self.assertRaises(ReplayContractError):
            self.led.replay(CFG)

    def test_replay_rejects_entry_with_tampered_sha(self):
        self.led.append(env(1), CFG)
        with open(self.led.path) as _fh:
            rows = [json.loads(l) for l in _fh if l.strip()]
        rows[0]["envelope"]["config_sha256"] = "0" * 64
        with open(self.led.path, "w") as fh:
            for r in rows:
                fh.write(json.dumps(r, sort_keys=True) + "\n")
        with self.assertRaises(ReplayContractError):
            self.led.replay(CFG)


class TestWritePathSeparation(unittest.TestCase):
    def test_canonical_ledger_refuses_transition_kind(self):
        tmp = tempfile.mkdtemp()
        led = CanonicalLedger(tmp, CONFIG, private_roots=(tmp,), engine_dir=ENGINE_DIR)
        p = payload(1)
        p["kind"] = "transition_h1"
        with self.assertRaises(EnvelopeContractError):
            contracts.build_envelope(p, CONFIG, engine_dir=ENGINE_DIR)
        self.assertEqual(led.entries(), [])

    def test_canonical_kinds_exclude_transition(self):
        from engine.ledger import CANONICAL_KINDS
        self.assertEqual(set(CANONICAL_KINDS), {"us_close", "daily_fallback"})
        for k in ("transition_h1", "transition_h3", "prediction"):
            self.assertNotIn(k, CANONICAL_KINDS)

    def test_canonical_writes_stay_in_canonical_root(self):
        tmp = tempfile.mkdtemp()
        led = CanonicalLedger(tmp, CONFIG, private_roots=(tmp,), engine_dir=ENGINE_DIR)
        led.append(env(1), CFG)
        written = [os.path.join(r, f) for r, _d, fs in os.walk(tmp) for f in fs]
        self.assertEqual(written, [led.path])


class TestAuditPatchP1(unittest.TestCase):
    """Negative tests for the five bypasses found in the first fixture round."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.led = CanonicalLedger(self.tmp, CONFIG, private_roots=(self.tmp,),
                                   engine_dir=ENGINE_DIR)

    def test_p1_1_payload_mutation_after_validation_rejected(self):
        e = env(1, A="BROKEN", B="NO_DEMAND", maturity="provisional")
        self.assertEqual(evaluate(StageState(), e, CFG).candidate_stage, "B1")
        e.payload["pillars"]["A"] = "RECOVERED"
        e.payload["b_maturity"] = "validated"
        with self.assertRaises(EnvelopeContractError):
            evaluate(StageState(), e, CFG)
        with self.assertRaises(EnvelopeContractError):
            self.led.append(e, CFG)

    def test_p1_1_stale_envelope_after_config_change_rejected(self):
        e = env(1)
        tmpcfg = os.path.join(self.tmp, "engine_config.json")
        with open(CONFIG) as fh:
            cfg = json.load(fh)
        cfg["promotion_consecutive_days"] = 9
        with open(tmpcfg, "w") as fh:
            json.dump(cfg, fh)
        led = CanonicalLedger(self.tmp, tmpcfg, private_roots=(self.tmp,),
                              engine_dir=ENGINE_DIR)
        with self.assertRaises(EnvelopeContractError):
            led.append(e, tmpcfg)

    def test_p1_2_forged_state_cannot_be_injected(self):
        import inspect
        self.assertNotIn("state", inspect.signature(CanonicalLedger.append).parameters)
        self.assertNotIn("state", inspect.signature(CanonicalLedger.revise).parameters)
        state = self.led.append(env(1, A="BROKEN", B="NO_DEMAND"), CFG)
        self.assertEqual(state.effective_stage, "B1")
        with open(self.led.path) as fh:
            stored = json.loads(fh.readline())
        self.assertEqual(stored["state"]["effective_stage"], "B1")

    def test_p1_3_forged_thresholds_are_ignored_not_trusted(self):
        """Values are re-read from the bound file; a forged dict cannot lower D."""
        e = env(1)
        forged = dict(CFG)
        forged["promotion_consecutive_days"] = 1   # would promote immediately
        s = evaluate(StageState(), e, forged)
        self.assertEqual(s.effective_stage, "B1")          # not promoted
        self.assertEqual(s.promotion_streak, 1)            # real D still applies

    def test_p1_3_config_without_source_binding_rejected(self):
        e = env(1)
        loose = {k: v for k, v in CFG.items() if k != "_source_path"}
        with self.assertRaises(EnvelopeContractError):
            evaluate(StageState(), e, loose)

    def test_p1_3_different_config_file_rejected(self):
        e = env(1)
        other = os.path.join(self.tmp, "other.json")
        with open(other, "w") as fh:
            json.dump({"promotion_consecutive_days": 1,
                       "maintenance_breach_days": 1, "S_max": 1}, fh)
        with self.assertRaises(EnvelopeContractError):
            evaluate(StageState(), e, other)   # sha != envelope.config_sha256

    def test_p1_4_deleted_state_field_rejected(self):
        for i in (1, 2):
            self.led.append(env(i), CFG)
        with open(self.led.path) as fh:
            rows = [json.loads(l) for l in fh if l.strip()]
        del rows[-1]["state"]["status"]
        with open(self.led.path, "w") as fh:
            for r in rows:
                fh.write(json.dumps(r, sort_keys=True) + "\n")
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)

    def test_p1_4_altered_state_value_rejected(self):
        self.led.append(env(1), CFG)
        with open(self.led.path) as fh:
            rows = [json.loads(l) for l in fh if l.strip()]
        rows[0]["state"]["effective_stage"] = "B5"
        with open(self.led.path, "w") as fh:
            for r in rows:
                fh.write(json.dumps(r, sort_keys=True) + "\n")
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)

    def test_p1_5_duplicate_revision_id_rejected(self):
        for i in (1, 2):
            self.led.append(env(i), CFG)
        same = contracts.build_envelope(payload(2, dled="active"), CONFIG,
                                        engine_dir=ENGINE_DIR)
        with self.assertRaises(LedgerContractError):
            self.led.revise(same, CFG, "2026-07-02.us_close", "same id")

    def test_p1_5_revision_id_equal_to_supersedes_rejected(self):
        self.led.append(env(1), CFG)
        e = contracts.build_envelope(payload(1, dled="active"), CONFIG,
                                     engine_dir=ENGINE_DIR)
        with self.assertRaises(LedgerContractError):
            self.led.revise(e, CFG, e.evaluation_id, "self reference")

    def test_stage_age_accumulates_on_repeated_structure_break(self):
        state = StageState(effective_stage="B1", stage_age=10)
        s1 = evaluate(state, env(1, structure="active"), CFG)
        self.assertEqual(s1.stage_age, 11)
        from_b4 = StageState(effective_stage="B4", stage_age=10)
        s2 = evaluate(from_b4, env(1, structure="active"), CFG)
        self.assertEqual(s2.stage_age, 1)


class TestAuditPatchN(unittest.TestCase):
    """Negative/state tests for the three bypasses found in the r2 round."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.led = CanonicalLedger(self.tmp, CONFIG, private_roots=(self.tmp,),
                                   engine_dir=ENGINE_DIR)

    # ---- N1 -----------------------------------------------------------
    def test_n1_confirmed_downgrade_proceeds_while_unknown_freezes_promotion(self):
        state = StageState(effective_stage="B4", promotion_streak=0)
        for i in range(W - 1):
            state = evaluate(state, env(i + 1, spotweak="active", dled="unknown"), CFG)
            self.assertEqual(state.effective_stage, "B4")
            self.assertTrue(state.frozen)
            self.assertEqual(state.maintenance_breach_streak, i + 1)
        state = evaluate(state, env(W, spotweak="active", dled="unknown"), CFG)
        self.assertEqual(state.effective_stage, "B3")
        self.assertTrue(state.frozen)
        self.assertEqual(state.promotion_streak, 0)

    def test_n1_unknown_alone_never_downgrades(self):
        state = StageState(effective_stage="B4")
        for i in range(W + 3):
            state = evaluate(state, env(i + 1, A="UNKNOWN", dled="unknown"), CFG)
            self.assertEqual(state.effective_stage, "B4")
            self.assertEqual(state.maintenance_breach_streak, 0)
            self.assertTrue(state.frozen)

    def test_n1_promotion_stays_frozen_during_confirmed_downgrade(self):
        state = StageState(effective_stage="B4", promotion_streak=D - 1)
        state = evaluate(state, env(1, spotweak="active", dled="unknown"), CFG)
        self.assertEqual(state.promotion_streak, D - 1)  # held, never advanced
        self.assertTrue(state.frozen)

    def test_n1_no_regression_when_nothing_unknown(self):
        state = StageState(effective_stage="B4")
        for i in range(W):
            state = evaluate(state, env(i + 1, spotweak="active"), CFG)
        self.assertEqual(state.effective_stage, "B3")
        self.assertFalse(state.frozen)

    # ---- N2 -----------------------------------------------------------
    def test_n2_pillar_enum_enforced(self):
        for pillar, kw in (("A", {"A": "GARBAGE"}), ("B", {"B": "GARBAGE"}),
                           ("C", {"C": "GARBAGE"}), ("E", {"E": "GARBAGE"})):
            with self.assertRaises(EnvelopeContractError, msg=pillar):
                contracts.build_envelope(payload(1, **kw), CONFIG, engine_dir=ENGINE_DIR)

    def test_n2_cross_pillar_value_rejected(self):
        # a valid value for the wrong pillar is still out of enum
        with self.assertRaises(EnvelopeContractError):
            contracts.build_envelope(payload(1, A="SPOT_LED"), CONFIG,
                                     engine_dir=ENGINE_DIR)

    def test_n2_valid_enums_accepted(self):
        for kw in ({"A": "FRAGILE"}, {"B": "NO_DEMAND"}, {"C": "DISLOCATED"},
                   {"E": "BTC_ONLY"}, {"A": "UNKNOWN"}):
            contracts.build_envelope(payload(1, **kw), CONFIG, engine_dir=ENGINE_DIR)

    # ---- N3 -----------------------------------------------------------
    def _tamper_top_level(self, field, value):
        self.led.append(env(1), CFG)
        with open(self.led.path) as fh:
            rows = [json.loads(l) for l in fh if l.strip()]
        rows[0][field] = value
        with open(self.led.path, "w") as fh:
            for r in rows:
                fh.write(json.dumps(r, sort_keys=True) + "\n")

    def test_n3_top_level_evaluation_id_tamper_rejected(self):
        self._tamper_top_level("evaluation_id", "forged-top-level")
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)

    def test_n3_top_level_market_date_tamper_rejected(self):
        self._tamper_top_level("market_date", "2099-01-01")
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)

    def test_n3_top_level_kind_tamper_rejected(self):
        self._tamper_top_level("kind", "forged_kind")
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)


class TestAuditPatchR3(unittest.TestCase):
    """Negative/state tests for the three bypasses found in the r3 round."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.led = CanonicalLedger(self.tmp, CONFIG, private_roots=(self.tmp,),
                                   engine_dir=ENGINE_DIR)

    # ---- R3-1 : stale/missing freezes the breach counter too -----------
    def test_r3_1_stale_holds_breach_and_never_downgrades(self):
        state = StageState(effective_stage="B4")
        for i in range(W + 1):
            state = evaluate(state, env(i + 1, data="stale", spotweak="active"), CFG)
            self.assertEqual(state.effective_stage, "B4")
            self.assertEqual(state.maintenance_breach_streak, 0)
            self.assertTrue(state.frozen)

    def test_r3_1_missing_holds_breach_too(self):
        state = StageState(effective_stage="B4", maintenance_breach_streak=1)
        state = evaluate(state, env(1, data="missing", spotweak="active"), CFG)
        self.assertEqual(state.maintenance_breach_streak, 1)  # held, not advanced
        self.assertEqual(state.effective_stage, "B4")

    def test_r3_1_breach_resumes_after_data_recovers(self):
        state = StageState(effective_stage="B4")
        for i in range(W + 1):
            state = evaluate(state, env(i + 1, data="stale", spotweak="active"), CFG)
        self.assertEqual(state.effective_stage, "B4")
        for i in range(W):
            state = evaluate(state, env(W + 2 + i, spotweak="active"), CFG)
        self.assertEqual(state.effective_stage, "B3")

    def test_r3_1_unknown_only_freeze_still_allows_confirmed_downgrade(self):
        # N1 behaviour must survive the R3-1 split
        state = StageState(effective_stage="B4")
        for i in range(W):
            state = evaluate(state, env(i + 1, spotweak="active", dled="unknown"), CFG)
        self.assertEqual(state.effective_stage, "B3")

    def test_r3_1_structure_break_still_immediate_under_stale(self):
        state = StageState(effective_stage="B4")
        s = evaluate(state, env(1, data="stale", structure="active"), CFG)
        self.assertEqual(s.effective_stage, "B1")

    # ---- R3-2 : write boundary re-validates the payload ----------------
    def _forge(self, body):
        """Assemble a ValidatedEnvelope via the module token, bypassing checks."""
        from engine.contracts import _MINT, payload_digest
        return contracts.ValidatedEnvelope(
            payload=body,
            engine_code_sha256=contracts.engine_code_sha256(ENGINE_DIR),
            config_sha256=contracts.config_sha256(CONFIG),
            snapshot_sha256=payload_digest(body),
            _token=_MINT,
        )

    def test_r3_2_forged_future_input_rejected_at_append(self):
        body = payload(1)
        body["engine_code_sha256"] = contracts.engine_code_sha256(ENGINE_DIR)
        body["config_sha256"] = contracts.config_sha256(CONFIG)
        body["observations"]["core_etf"]["available_at"] = "2099-01-01T00:00:00+00:00"
        forged = self._forge(body)
        forged.assert_snapshot()  # snapshot is self-consistent; only re-validation catches it
        with self.assertRaises(TimeContractError):
            self.led.append(forged, CFG)
        self.assertEqual(self.led.entries(), [])

    def test_r3_2_forged_missing_field_rejected_at_append(self):
        body = payload(1)
        body["engine_code_sha256"] = contracts.engine_code_sha256(ENGINE_DIR)
        body["config_sha256"] = contracts.config_sha256(CONFIG)
        del body["b_maturity"]
        with self.assertRaises(EnvelopeContractError):
            self.led.append(self._forge(body), CFG)
        self.assertEqual(self.led.entries(), [])

    def test_r3_2_forged_bad_pillar_rejected_at_append(self):
        body = payload(1, )
        body["pillars"]["A"] = "GARBAGE"
        body["engine_code_sha256"] = contracts.engine_code_sha256(ENGINE_DIR)
        body["config_sha256"] = contracts.config_sha256(CONFIG)
        with self.assertRaises(EnvelopeContractError):
            self.led.append(self._forge(body), CFG)
        self.assertEqual(self.led.entries(), [])

    # ---- R3-3 : revision target must re-validate in full ---------------
    def _setup_two_then_tamper(self, field, value):
        self.led.append(env(1), CFG)
        self.led.append(env(2), CFG)
        with open(self.led.path) as fh:
            rows = [json.loads(l) for l in fh if l.strip()]
        rows[-1][field] = value
        with open(self.led.path, "w") as fh:
            for r in rows:
                fh.write(json.dumps(r, sort_keys=True) + "\n")
        return contracts.build_envelope(
            dict(payload(2, dled="active"), evaluation_id="2026-07-02.us_close.r1"),
            CONFIG, engine_dir=ENGINE_DIR)

    def test_r3_3_tampered_target_evaluation_id_blocks_revision(self):
        e = self._setup_two_then_tamper("evaluation_id", "forged-top-level")
        before = len(self.led.entries())
        with self.assertRaises(ReplayContractError):
            self.led.revise(e, CFG, "forged-top-level", "restated")
        self.assertEqual(len(self.led.entries()), before)  # nothing written

    def test_r3_3_tampered_target_kind_blocks_revision(self):
        e = self._setup_two_then_tamper("kind", "forged_kind")
        before = len(self.led.entries())
        with self.assertRaises(ReplayContractError):
            self.led.revise(e, CFG, "2026-07-02.us_close", "restated")
        self.assertEqual(len(self.led.entries()), before)

    # ---- non-blocking: strict market_date -----------------------------
    def test_market_date_must_be_real_iso_date(self):
        for bad in ("2026-7-1", "2026-99-99", "20260701", "not-a-date"):
            body = payload(1)
            body["market_date"] = bad
            body["evaluation_id"] = "%s.us_close" % bad
            with self.assertRaises(EnvelopeContractError, msg=bad):
                contracts.build_envelope(body, CONFIG, engine_dir=ENGINE_DIR)


class TestAuditPatchR4(unittest.TestCase):
    """Revision lineage and post-revision continuation (r4 round findings)."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.led = CanonicalLedger(self.tmp, CONFIG, private_roots=(self.tmp,),
                                   engine_dir=ENGINE_DIR)

    def _rows(self):
        with open(self.led.path) as fh:
            return [json.loads(l) for l in fh if l.strip()]

    def _write(self, rows):
        with open(self.led.path, "w") as fh:
            for r in rows:
                fh.write(json.dumps(r, sort_keys=True) + "\n")

    def _seed_with_revision(self):
        self.led.append(env(1), CFG)
        self.led.append(env(2), CFG)
        rev = contracts.build_envelope(
            dict(payload(2, dled="active"), evaluation_id="2026-07-02.us_close.r1"),
            CONFIG, engine_dir=ENGINE_DIR)
        self.led.revise(rev, CFG, "2026-07-02.us_close", "issuer restated")

    # ---- R4-1 -----------------------------------------------------------
    def test_r4_1_append_after_revision_matches_replay(self):
        self._seed_with_revision()
        stored = self.led.append(env(3), CFG)
        replayed = self.led.replay(CFG)
        self.assertEqual(stored.to_dict(), replayed.to_dict())
        self.assertTrue(self.led.verify_replay_invariant(CFG))

    def test_r4_1_revision_replaces_rather_than_adds_an_evaluation(self):
        """A revised day must not be counted twice in the following day."""
        self.led.append(env(1), CFG)
        self.led.append(env(2), CFG)
        no_rev_state = self.led.append(env(3), CFG)

        root2 = tempfile.mkdtemp()
        led2 = CanonicalLedger(root2, CONFIG, private_roots=(root2,),
                               engine_dir=ENGINE_DIR)
        led2.append(env(1), CFG)
        led2.append(env(2), CFG)
        rev = contracts.build_envelope(
            dict(payload(2), evaluation_id="2026-07-02.us_close.r1"),
            CONFIG, engine_dir=ENGINE_DIR)
        led2.revise(rev, CFG, "2026-07-02.us_close", "identical restatement")
        with_rev_state = led2.append(env(3), CFG)
        # an identical restatement must not change the day-3 verdict
        self.assertEqual(no_rev_state.to_dict(), with_rev_state.to_dict())

    def test_r4_1_multiple_revisions_then_append(self):
        self._seed_with_revision()
        rev2 = contracts.build_envelope(
            dict(payload(2, dover="active"), evaluation_id="2026-07-02.us_close.r2"),
            CONFIG, engine_dir=ENGINE_DIR)
        self.led.revise(rev2, CFG, "2026-07-02.us_close.r1", "second restatement")
        stored = self.led.append(env(3), CFG)
        self.assertEqual(stored.to_dict(), self.led.replay(CFG).to_dict())
        self.assertTrue(self.led.verify_replay_invariant(CFG))

    # ---- R4-2 -----------------------------------------------------------
    def test_r4_2_bogus_supersedes_rejected(self):
        self._seed_with_revision()
        rows = self._rows()
        rows[-1]["supersedes"] = "bogus"
        self._write(rows)
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)

    def test_r4_2_non_current_supersedes_rejected(self):
        self._seed_with_revision()
        rows = self._rows()
        rows[-1]["supersedes"] = "2026-07-01.us_close"   # wrong date, not pointer
        self._write(rows)
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)

    def test_r4_2_missing_revision_reason_rejected(self):
        self._seed_with_revision()
        rows = self._rows()
        rows[-1]["revision_reason"] = None
        self._write(rows)
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)

    def test_r4_2_blank_revision_reason_rejected(self):
        self._seed_with_revision()
        rows = self._rows()
        rows[-1]["revision_reason"] = "   "
        self._write(rows)
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)

    def test_r4_2_supersedes_on_normal_entry_rejected(self):
        self.led.append(env(1), CFG)
        self.led.append(env(2), CFG)
        rows = self._rows()
        rows[-1]["supersedes"] = "2026-07-01.us_close"
        self._write(rows)
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)

    def test_r4_2_reason_without_supersedes_rejected(self):
        self.led.append(env(1), CFG)
        rows = self._rows()
        rows[0]["revision_reason"] = "orphan reason"
        self._write(rows)
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)

    def test_r4_2_self_referencing_revision_rejected(self):
        self._seed_with_revision()
        rows = self._rows()
        rows[-1]["supersedes"] = rows[-1]["evaluation_id"]
        self._write(rows)
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)

    def test_r4_2_duplicate_id_in_ledger_rejected(self):
        self.led.append(env(1), CFG)
        rows = self._rows()
        self._write(rows + [dict(rows[0])])
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)


class TestAuditPatchR5(unittest.TestCase):
    """Ledger integrity must be established before anything new is written."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.led = CanonicalLedger(self.tmp, CONFIG, private_roots=(self.tmp,),
                                   engine_dir=ENGINE_DIR)

    def _rows(self):
        with open(self.led.path) as fh:
            return [json.loads(l) for l in fh if l.strip()]

    def _write(self, rows):
        with open(self.led.path, "w") as fh:
            for r in rows:
                fh.write(json.dumps(r, sort_keys=True) + "\n")

    # ---- R5-1 ----------------------------------------------------------
    def test_r5_1_tampered_past_market_date_blocks_next_append(self):
        for i in (1, 2, 3):
            self.led.append(env(i), CFG)
        rows = self._rows()
        rows[0]["market_date"] = "2099-01-01"      # would break the walk early
        self._write(rows)
        before = len(self._rows())
        with self.assertRaises(ReplayContractError):
            self.led.append(env(4), CFG)
        self.assertEqual(len(self._rows()), before)   # nothing written

    def test_r5_1_tampered_past_market_date_blocks_state_before(self):
        for i in (1, 2):
            self.led.append(env(i), CFG)
        rows = self._rows()
        rows[0]["market_date"] = "2099-01-01"
        self._write(rows)
        with self.assertRaises(ReplayContractError):
            self.led._state_before("2026-07-03", CFG)

    # ---- R5-2 ----------------------------------------------------------
    def _seed_damaged_lineage(self):
        self.led.append(env(1), CFG)
        rev = contracts.build_envelope(
            dict(payload(1, dled="active"), evaluation_id="2026-07-01.us_close.r1"),
            CONFIG, engine_dir=ENGINE_DIR)
        self.led.revise(rev, CFG, "2026-07-01.us_close", "first restatement")
        rows = self._rows()
        rows[-1]["supersedes"] = "bogus"
        self._write(rows)

    def test_r5_2_damaged_lineage_blocks_next_revision(self):
        self._seed_damaged_lineage()
        before = len(self._rows())
        r2 = contracts.build_envelope(
            dict(payload(1, dover="active"), evaluation_id="2026-07-01.us_close.r2"),
            CONFIG, engine_dir=ENGINE_DIR)
        with self.assertRaises(ReplayContractError):
            self.led.revise(r2, CFG, "2026-07-01.us_close.r1", "second restatement")
        self.assertEqual(len(self._rows()), before)

    def test_r5_2_damaged_lineage_blocks_next_append(self):
        self._seed_damaged_lineage()
        before = len(self._rows())
        with self.assertRaises(ReplayContractError):
            self.led.append(env(2), CFG)
        self.assertEqual(len(self._rows()), before)

    def test_r5_2_altered_stored_state_blocks_next_append(self):
        self.led.append(env(1), CFG)
        rows = self._rows()
        rows[0]["state"]["effective_stage"] = "B5"
        self._write(rows)
        before = len(self._rows())
        with self.assertRaises(ReplayContractError):
            self.led.append(env(2), CFG)
        self.assertEqual(len(self._rows()), before)

    def test_r5_2_healthy_ledger_still_accepts_writes(self):
        for i in (1, 2, 3):
            self.led.append(env(i), CFG)
        self.assertEqual(len(self._rows()), 3)
        self.assertTrue(self.led.verify_replay_invariant(CFG))

    # ---- R5-3 ----------------------------------------------------------
    def test_r5_3_second_non_revision_entry_same_date_rejected(self):
        self.led.append(env(1), CFG)
        rows = self._rows()
        dup = json.loads(json.dumps(rows[0]))
        dup["evaluation_id"] = "2026-07-01.daily_fallback"
        dup["kind"] = "daily_fallback"
        dup["envelope"]["evaluation_id"] = "2026-07-01.daily_fallback"
        dup["envelope"]["kind"] = "daily_fallback"
        self._write(rows + [dup])
        with self.assertRaises(ReplayContractError):
            self.led.verify_replay_invariant(CFG)

    def test_r5_3_revision_on_same_date_still_allowed(self):
        self.led.append(env(1), CFG)
        rev = contracts.build_envelope(
            dict(payload(1, dled="active"), evaluation_id="2026-07-01.us_close.r1"),
            CONFIG, engine_dir=ENGINE_DIR)
        self.led.revise(rev, CFG, "2026-07-01.us_close", "restated")
        self.assertTrue(self.led.verify_replay_invariant(CFG))


class TestWriteGuard(unittest.TestCase):
    def test_public_root_refused(self):
        with self.assertRaises(WriteGuardError):
            guard.assert_private_path("/var/www/f29/recovery.json")

    def test_outside_private_root_refused(self):
        with self.assertRaises(WriteGuardError):
            guard.assert_private_path("/tmp/anything.json")

    def test_inside_private_root_allowed(self):
        tmp = tempfile.mkdtemp()
        p = os.path.join(tmp, "x.json")
        self.assertTrue(guard.assert_private_path(p, private_roots=(tmp,)))
        with guard.open_private(p, "w", private_roots=(tmp,)) as fh:
            fh.write("{}")

    def test_open_private_refuses_read_mode(self):
        tmp = tempfile.mkdtemp()
        with self.assertRaises(WriteGuardError):
            guard.open_private(os.path.join(tmp, "x"), "r", private_roots=(tmp,))


class TestCoreAdapterReadOnly(unittest.TestCase):
    """Mirrors the measured core schema; the live DB is never touched here."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.db = os.path.join(cls.tmp, "core.sqlite")
        con = sqlite3.connect(cls.db)
        con.executescript(
            "CREATE TABLE etf_daily (asset TEXT, ticker TEXT, issuer_as_of_date TEXT,"
            " effective_trade_date TEXT, delta_shares REAL, nav_per_share REAL,"
            " est_creation_usd REAL, source_id TEXT, input_digest TEXT,"
            " first_seen_at TEXT, last_seen_at TEXT, persistence_mode TEXT,"
            " alignment_status TEXT DEFAULT 'provisional',"
            " PRIMARY KEY (asset,ticker,issuer_as_of_date));"
            "CREATE TABLE etf_daily_revisions (asset TEXT, ticker TEXT,"
            " issuer_as_of_date TEXT, delta_shares REAL, nav_per_share REAL,"
            " est_creation_usd REAL, source_revision_digest TEXT, seen_at TEXT,"
            " PRIMARY KEY (asset,ticker,issuer_as_of_date,source_revision_digest));"
            "CREATE VIEW etf_daily_resolved AS SELECT d.asset, d.ticker,"
            " d.issuer_as_of_date, d.delta_shares, d.nav_per_share,"
            " d.est_creation_usd, 'canonical' AS resolution FROM etf_daily d;"
        )
        for i, delta in enumerate([920000.0, 2200000.0, 3800000.0, -5280000.0]):
            con.execute(
                "INSERT INTO etf_daily (asset,ticker,issuer_as_of_date,delta_shares,"
                "alignment_status) VALUES ('BTC','IBIT',?,?, 'provisional')",
                ("2026-07-%02d" % (17 - i), delta),
            )
        con.commit()
        con.close()

    def test_connection_is_query_only(self):
        con = etf_core_ro.connect(self.db)
        self.assertEqual(int(con.execute("PRAGMA query_only").fetchone()[0]), 1)
        con.close()

    def test_write_attempt_raises(self):
        con = etf_core_ro.connect(self.db)
        with self.assertRaises(sqlite3.OperationalError):
            con.execute("DELETE FROM etf_daily")
        con.close()

    def test_reads_rows_and_reports_provisional_as_measured(self):
        con = etf_core_ro.connect(self.db)
        rows = etf_core_ro.fetch_etf_flow(con, "IBIT", 10)
        con.close()
        self.assertEqual(len(rows), 4)
        self.assertEqual(rows[0]["issuer_as_of_date"], "2026-07-17")
        st = etf_core_ro.f_axis_state(rows)
        self.assertEqual(st["alignment"], "provisional")
        self.assertEqual(st["latest_as_of"], "2026-07-17")

    def test_adapter_contains_no_write_sql(self):
        with open(os.path.join(ENGINE_DIR, "adapters", "etf_core_ro.py")) as _fh:
            src = _fh.read()
        for kw in ("insert ", "update ", "delete ", "drop ", "attach "):
            self.assertNotIn(kw, src.lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
