"""Typed contract failures. No behaviour beyond failing loudly."""


class ContractError(Exception):
    """Base for all contract violations."""


class EnvelopeContractError(ContractError):
    """Envelope missing required fields, malformed, or SHA mismatch."""


class TimeContractError(ContractError):
    """Point-in-time contract violation."""


class LedgerContractError(ContractError):
    """Append-only / monotonicity / revision contract violation."""


class ReplayContractError(ContractError):
    """Replay could not re-validate a stored entry, or replay diverged."""


class MaturityContractError(ContractError):
    """Provisional pillar used or promoted beyond its authority."""


class WriteGuardError(ContractError):
    """PRIVATE_ONLY writer guard refused a path."""
