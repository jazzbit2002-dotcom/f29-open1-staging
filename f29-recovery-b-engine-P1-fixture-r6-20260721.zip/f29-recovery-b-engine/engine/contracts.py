"""Trust boundary (kickoff item, defect class A) and time contract (class C).

Result contract, not a prescribed structure:

  * a validated envelope can only be produced by ``load_envelope`` /
    ``build_envelope`` in this module;
  * an unvalidated dict, an envelope missing required fields, or a caller
    assembled SHA cannot enter the canonical store or the replay path
    (``Ledger`` accepts ``ValidatedEnvelope`` instances only);
  * the SHA fields are computed here from the actual engine sources and the
    actual config file. The caller never supplies them on the load path.
"""
import datetime as _dt
import hashlib
import json
import os
from dataclasses import dataclass, field

from .errors import EnvelopeContractError, TimeContractError

# Fields every envelope must carry. Absent or null -> failure, never "skip".
REQUIRED_FIELDS = (
    "evaluation_id",
    "market_date",
    "kind",
    "evaluation_cutoff",
    "pillars",
    "blockers",
    "b_maturity",
    "data_status",
    "observations",
    "engine_code_sha256",
    "config_sha256",
)

REQUIRED_PILLARS = ("A", "B", "C", "E")
# Enum per pillar. A value outside the set is a contract failure, never coerced
# to UNKNOWN: a typo or upstream schema drift must not become a downgrade basis.
PILLAR_ENUMS = {
    "A": ("RECOVERED", "IMPROVING", "FRAGILE", "BROKEN", "UNKNOWN"),
    "B": ("SPOT_LED", "MIXED", "DERIVATIVES_LED", "NO_DEMAND", "UNKNOWN"),
    "C": ("HEALTHY", "EXPANDING", "LEVERAGE_LED", "OVERHEATED", "DISLOCATED", "UNKNOWN"),
    "E": ("BROADENING", "CONFIRMED", "BTC_ONLY", "COLLAPSING", "UNKNOWN"),
}
REQUIRED_BLOCKERS = (
    "structure_break",
    "spot_weakness",
    "derivatives_led",
    "derivatives_overheated",
)
# Time fields every observation must carry (source profile may require more).
REQUIRED_OBS_TIME_FIELDS = ("available_at", "source_as_of")

_MINT = object()  # construction token; keeps the dataclass un-forgeable


def canonical_json(payload):
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def payload_digest(payload):
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class ValidatedEnvelope:
    """Only produced by this module. Ledger accepts nothing else.

    frozen=True protects the field bindings, not the nested payload, so the
    validation snapshot digest is recorded here and re-checked at every entry
    point that can affect canonical state (P1-1).
    """

    payload: dict
    engine_code_sha256: str
    config_sha256: str
    snapshot_sha256: str
    _token: object = field(repr=False, compare=False)

    def __post_init__(self):
        if self._token is not _MINT:
            raise EnvelopeContractError(
                "ValidatedEnvelope cannot be constructed directly; "
                "use build_envelope() or load_envelope()"
            )

    def assert_snapshot(self):
        """Payload must be byte-identical to what was validated."""
        current = payload_digest(self.payload)
        if current != self.snapshot_sha256:
            raise EnvelopeContractError(
                "envelope payload was modified after validation "
                "(snapshot=%s current=%s)" % (self.snapshot_sha256, current)
            )
        return True

    def assert_intact(self, config_path, engine_dir=None):
        """Snapshot + the engine/config artifacts it was validated against."""
        self.assert_snapshot()
        actual_engine = engine_code_sha256(engine_dir)
        actual_config = config_sha256(config_path)
        if self.engine_code_sha256 != actual_engine:
            raise EnvelopeContractError(
                "engine sources changed since validation: envelope=%s actual=%s"
                % (self.engine_code_sha256, actual_engine)
            )
        if self.config_sha256 != actual_config:
            raise EnvelopeContractError(
                "config changed since validation: envelope=%s actual=%s"
                % (self.config_sha256, actual_config)
            )
        return True

    # convenience read-only accessors
    @property
    def evaluation_id(self):
        return self.payload["evaluation_id"]

    @property
    def market_date(self):
        return self.payload["market_date"]

    @property
    def kind(self):
        return self.payload["kind"]

    def raw_json(self):
        return canonical_json(self.payload)


# --------------------------------------------------------------------------
# SHA computation - owned here, never accepted from the caller on load
# --------------------------------------------------------------------------

def engine_code_sha256(engine_dir=None):
    """SHA over the engine package sources, sorted by relative path."""
    base = engine_dir or os.path.dirname(os.path.abspath(__file__))
    h = hashlib.sha256()
    for root, dirs, files in os.walk(base):
        dirs[:] = sorted(d for d in dirs if d != "__pycache__")
        for name in sorted(files):
            if not name.endswith(".py"):
                continue
            p = os.path.join(root, name)
            h.update(os.path.relpath(p, base).encode())
            with open(p, "rb") as fh:
                h.update(fh.read())
    return h.hexdigest()


def config_sha256(config_path):
    with open(config_path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def load_config(config_path):
    """Config is injected. Missing keys fail; the engine has no defaults."""
    with open(config_path, "rb") as fh:
        raw = fh.read()
    cfg = json.loads(raw.decode("utf-8"))
    for key in ("promotion_consecutive_days", "maintenance_breach_days", "S_max"):
        if key not in cfg or cfg[key] is None:
            raise EnvelopeContractError("config missing required key: %s" % key)
        if not isinstance(cfg[key], int) or cfg[key] < 1:
            raise EnvelopeContractError("config key %s must be int >= 1" % key)
    cfg["_sha256"] = hashlib.sha256(raw).hexdigest()
    cfg["_source_path"] = os.path.abspath(config_path)
    return cfg


# --------------------------------------------------------------------------
# Time contract (Phase 1 minimal set; no fields invented beyond v1.4)
# --------------------------------------------------------------------------

def parse_ts(value, label):
    if not isinstance(value, str) or not value:
        raise TimeContractError("%s missing or not a string" % label)
    text = value.replace("Z", "+00:00")
    try:
        ts = _dt.datetime.fromisoformat(text)
    except ValueError as exc:
        raise TimeContractError("%s not ISO-8601: %r (%s)" % (label, value, exc))
    if ts.tzinfo is None:
        raise TimeContractError("%s is not timezone-aware" % label)
    return ts


def check_time_contract(payload):
    """available_at <= evaluation_cutoff for every observation; no future input.

    Relationships among observation_time / source_as_of / collected_at are the
    business of each source profile and are not forced into one inequality here.
    """
    cutoff = parse_ts(payload.get("evaluation_cutoff"), "evaluation_cutoff")
    obs = payload.get("observations")
    if not isinstance(obs, dict):
        raise TimeContractError("observations must be an object")
    for source_id, rec in sorted(obs.items()):
        if not isinstance(rec, dict):
            raise TimeContractError("observation %s must be an object" % source_id)
        for f in REQUIRED_OBS_TIME_FIELDS:
            if f not in rec or rec[f] is None:
                raise TimeContractError(
                    "observation %s missing required time field %s" % (source_id, f)
                )
        available_at = parse_ts(rec["available_at"], "%s.available_at" % source_id)
        parse_ts(rec["source_as_of"], "%s.source_as_of" % source_id)
        if available_at > cutoff:
            raise TimeContractError(
                "observation %s available_at %s is after evaluation_cutoff %s "
                "(future input blocked; late arrivals are not applied "
                "retroactively)" % (source_id, rec["available_at"], payload["evaluation_cutoff"])
            )
    return cutoff


# --------------------------------------------------------------------------
# Structural validation
# --------------------------------------------------------------------------

def _validate_shape(payload):
    if not isinstance(payload, dict):
        raise EnvelopeContractError("envelope must be an object")
    for f in REQUIRED_FIELDS:
        if f not in payload:
            raise EnvelopeContractError("envelope missing required field: %s" % f)
        if payload[f] is None:
            raise EnvelopeContractError("envelope field is null: %s" % f)
    pillars = payload["pillars"]
    if not isinstance(pillars, dict):
        raise EnvelopeContractError("pillars must be an object")
    for p in REQUIRED_PILLARS:
        if p not in pillars or pillars[p] is None:
            raise EnvelopeContractError("pillars missing: %s" % p)
        if pillars[p] not in PILLAR_ENUMS[p]:
            raise EnvelopeContractError(
                "pillar %s has value %r outside allowed enum %s"
                % (p, pillars[p], list(PILLAR_ENUMS[p]))
            )
    blockers = payload["blockers"]
    if not isinstance(blockers, dict):
        raise EnvelopeContractError("blockers must be an object")
    for b in REQUIRED_BLOCKERS:
        if b not in blockers or blockers[b] is None:
            raise EnvelopeContractError("blockers missing: %s" % b)
        if blockers[b] not in ("active", "inactive", "unknown"):
            raise EnvelopeContractError(
                "blocker %s has invalid value %r" % (b, blockers[b])
            )
    if payload["b_maturity"] not in ("provisional", "validated"):
        raise EnvelopeContractError(
            "b_maturity must be provisional|validated, got %r" % payload["b_maturity"]
        )
    if payload["data_status"] not in ("ok", "stale", "missing"):
        raise EnvelopeContractError(
            "data_status must be ok|stale|missing, got %r" % payload["data_status"]
        )
    if payload["kind"] not in ("us_close", "daily_fallback"):
        raise EnvelopeContractError("kind must be us_close|daily_fallback")
    mdate_raw = payload["market_date"]
    if not isinstance(mdate_raw, str):
        raise EnvelopeContractError("market_date must be a string")
    # extended ISO form only: 3.11+ fromisoformat also accepts basic form
    # (YYYYMMDD), which would let two spellings of one date coexist.
    if len(mdate_raw) != 10 or mdate_raw[4] != "-" or mdate_raw[7] != "-":
        raise EnvelopeContractError(
            "market_date must be YYYY-MM-DD, got %r" % mdate_raw
        )
    try:
        _dt.date.fromisoformat(mdate_raw)
    except ValueError:
        raise EnvelopeContractError(
            "market_date must be a real calendar date, got %r" % mdate_raw
        )
    eid, mdate = payload["evaluation_id"], payload["market_date"]
    if not isinstance(eid, str) or not eid.startswith(str(mdate) + "."):
        raise EnvelopeContractError(
            "evaluation_id %r must start with market_date %r" % (eid, mdate)
        )


def build_envelope(payload, config_path, engine_dir=None):
    """Stamp the authoritative SHAs from the real files, then validate."""
    body = dict(payload)
    body["engine_code_sha256"] = engine_code_sha256(engine_dir)
    body["config_sha256"] = config_sha256(config_path)
    return load_envelope(body, config_path, engine_dir=engine_dir)


def load_envelope(payload, config_path, engine_dir=None):
    """Validate shape + time contract + SHA identity. Sole entry point.

    ``payload`` may be a dict or raw JSON bytes/str. SHAs declared inside the
    envelope are compared against values computed here from the actual files;
    a caller-assembled SHA that does not match the real artifact fails.
    """
    if isinstance(payload, (bytes, bytearray)):
        payload = json.loads(bytes(payload).decode("utf-8"))
    elif isinstance(payload, str):
        payload = json.loads(payload)
    if not isinstance(payload, dict):
        raise EnvelopeContractError("envelope must decode to an object")

    _validate_shape(payload)
    check_time_contract(payload)

    actual_engine = engine_code_sha256(engine_dir)
    actual_config = config_sha256(config_path)
    if payload["engine_code_sha256"] != actual_engine:
        raise EnvelopeContractError(
            "engine_code_sha256 mismatch: envelope=%s actual=%s"
            % (payload["engine_code_sha256"], actual_engine)
        )
    if payload["config_sha256"] != actual_config:
        raise EnvelopeContractError(
            "config_sha256 mismatch: envelope=%s actual=%s"
            % (payload["config_sha256"], actual_config)
        )
    frozen_payload = json.loads(canonical_json(payload))
    return ValidatedEnvelope(
        payload=frozen_payload,
        engine_code_sha256=actual_engine,
        config_sha256=actual_config,
        snapshot_sha256=payload_digest(frozen_payload),
        _token=_MINT,
    )
