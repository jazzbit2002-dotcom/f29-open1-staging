"""PRIVATE_ONLY public writer guard (kickoff item 8).

Single choke point for filesystem writes. Refuses any path outside the private
engine root and refuses known public roots outright.
"""
import os

from .errors import WriteGuardError

PRIVATE_ROOTS = ("/root/f29-recovery-b-engine",)
PUBLIC_DENY = ("/var/www", "/usr/share/nginx", "/srv/http", "/etc/nginx")


def _norm(p):
    return os.path.realpath(os.path.abspath(os.path.expanduser(str(p))))


def assert_private_path(path, private_roots=None):
    """Return normalised path, or raise WriteGuardError."""
    roots = tuple(_norm(r) for r in (private_roots or PRIVATE_ROOTS))
    target = _norm(path)
    for deny in PUBLIC_DENY:
        d = _norm(deny)
        if target == d or target.startswith(d + os.sep):
            raise WriteGuardError("public path refused: %s" % target)
    for root in roots:
        if target == root or target.startswith(root + os.sep):
            return target
    raise WriteGuardError("path outside private root refused: %s" % target)


def open_private(path, mode="w", private_roots=None, **kw):
    """Only writer entry point. Read-only modes are rejected on purpose."""
    if "r" in mode and "+" not in mode:
        raise WriteGuardError("open_private is for writes only")
    assert_private_path(path, private_roots)
    return open(path, mode, **kw)
