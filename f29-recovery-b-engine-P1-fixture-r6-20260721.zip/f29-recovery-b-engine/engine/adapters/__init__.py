"""Read-only adapters. No adapter in this package may contain write SQL."""
