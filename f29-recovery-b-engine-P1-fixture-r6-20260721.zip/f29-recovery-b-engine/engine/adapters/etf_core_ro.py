"""F-axis adapter over the existing recovery-core DB (kickoff item 7).

Read-only by construction:
  * sqlite3 URI with mode=ro (VFS level)
  * PRAGMA query_only set and verified after connect (connection level)
  * this module contains no data-modifying SQL (verified by grep evidence)
  * alignment_status is passed through as measured; there is no path here that
    promotes 'provisional' to 'confirmed'
"""
import sqlite3

CORE_DB_PATH = "/root/f29-recovery-core/data/recovery_core.sqlite"


def connect(db_path=CORE_DB_PATH):
    conn = sqlite3.connect("file:%s?mode=ro" % db_path, uri=True)
    conn.row_factory = sqlite3.Row
    # mode=ro blocks writes at the VFS layer; query_only adds the connection
    # level guard so a write attempt fails before it reaches the file.
    conn.execute("PRAGMA query_only = ON")
    if int(conn.execute("PRAGMA query_only").fetchone()[0]) != 1:
        conn.close()
        raise RuntimeError("core DB connection is not query_only")
    return conn


def fetch_etf_flow(conn, ticker="IBIT", limit=30):
    """Latest resolved ETF rows. Revision resolution is the core DB's own view."""
    rows = conn.execute(
        "select d.asset, d.ticker, d.issuer_as_of_date, d.effective_trade_date, "
        "r.delta_shares, r.resolution, d.alignment_status, d.input_digest, "
        "d.first_seen_at, d.last_seen_at "
        "from etf_daily d join etf_daily_resolved r "
        "  on r.asset=d.asset and r.ticker=d.ticker "
        " and r.issuer_as_of_date=d.issuer_as_of_date "
        "where upper(trim(d.ticker))=upper(?) "
        "order by d.issuer_as_of_date desc limit ?",
        (ticker, int(limit)),
    ).fetchall()
    return [dict(r) for r in rows]


def f_axis_state(records):
    """Map measured rows to an F-axis state.

    alignment_status is reported as measured. Every row being 'provisional'
    means the F axis is reported as provisional; it is not upgraded here.
    """
    if not records:
        return {"state": "UNKNOWN", "alignment": "unknown", "n": 0, "latest_as_of": None}
    statuses = {r.get("alignment_status") for r in records}
    alignment = "provisional" if statuses != {"confirmed"} else "confirmed"
    deltas = [r["delta_shares"] for r in records if r.get("delta_shares") is not None]
    if not deltas:
        state = "UNKNOWN"
    else:
        recent = sum(deltas[:3])
        prior = sum(deltas[3:6]) if len(deltas) > 3 else 0.0
        if recent > 0 and recent >= prior:
            state = "ACCELERATING" if prior and recent > prior else "POSITIVE"
        elif recent > 0:
            state = "SLOWING"
        else:
            state = "NEGATIVE"
    return {
        "state": state,
        "alignment": alignment,
        "n": len(records),
        "latest_as_of": records[0].get("issuer_as_of_date"),
    }
