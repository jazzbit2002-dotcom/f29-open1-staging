"""Canonical B1~B5 state machine (kickoff items 1-5).

Pure function of (previous state, validated envelope, config). No I/O, no
network, no clock. Same input -> same verdict, which is what makes the replay
invariant checkable.

Thresholds D / W / S_max are injected via config. Nothing is hardcoded here.
"""
from dataclasses import dataclass, field, replace

from .contracts import load_config
from .errors import EnvelopeContractError, MaturityContractError

STAGES = ("B1", "B2", "B3", "B4", "B5")


def _rank(stage):
    return STAGES.index(stage)


def _stage(rank):
    return STAGES[max(0, min(rank, len(STAGES) - 1))]


@dataclass(frozen=True)
class StageState:
    effective_stage: str = "B1"
    candidate_stage: str = "B1"
    ceiling_stage: str = "B5"
    ceiling_sources: tuple = ()
    stage_age: int = 0
    promotion_streak: int = 0
    maintenance_breach_streak: int = 0
    stale_streak: int = 0
    frozen: bool = False
    freeze_reasons: tuple = ()
    status: str = "ok"
    last_evaluation_id: str = ""
    decision_trace: tuple = field(default=(), compare=False)

    def to_dict(self):
        d = dict(self.__dict__)
        for k in ("ceiling_sources", "freeze_reasons", "decision_trace"):
            d[k] = list(d[k])
        return d


# --------------------------------------------------------------------------
# Pillar satisfaction
# --------------------------------------------------------------------------

def _a_ok(pillars, unknown_as_pass=False):
    if unknown_as_pass and pillars["A"] == "UNKNOWN":
        return True
    return pillars["A"] in ("RECOVERED", "IMPROVING")


def _a_strong(pillars, unknown_as_pass=False):
    if unknown_as_pass and pillars["A"] == "UNKNOWN":
        return True
    return pillars["A"] == "RECOVERED"


def _b_demand(pillars, unknown_as_pass=False):
    if unknown_as_pass and pillars["B"] == "UNKNOWN":
        return True
    return pillars["B"] in ("SPOT_LED", "MIXED")


def _e_broad(pillars, unknown_as_pass=False):
    if unknown_as_pass and pillars["E"] == "UNKNOWN":
        return True
    return pillars["E"] in ("BROADENING", "CONFIRMED")


def _c_clean(pillars, unknown_as_pass=False):
    if unknown_as_pass and pillars["C"] == "UNKNOWN":
        return True
    return pillars["C"] in ("HEALTHY", "EXPANDING")


def b_axis_satisfied(payload, required_for_rank, unknown_as_pass=False):
    """B pillar authority check (defect class B, Phase 1 minimal form).

    A provisional B maturity may not satisfy the required B axis for B3+.
    There is no path in this module that promotes provisional to validated.
    """
    pillars = payload["pillars"]
    if not _b_demand(pillars, unknown_as_pass):
        return False
    if required_for_rank >= _rank("B3") and payload["b_maturity"] == "provisional":
        return False
    return True


def promote_maturity(*_args, **_kw):
    """Explicitly absent capability. Kept as a named failure so that any future
    caller reaching for it fails loudly instead of finding a quiet path."""
    raise MaturityContractError(
        "B maturity promotion is not implemented in Phase 1; provisional cannot "
        "be raised to validated by the engine"
    )


# --------------------------------------------------------------------------
# Candidate + ceiling
# --------------------------------------------------------------------------

def compute_candidate(payload, unknown_as_pass=False):
    """Highest stage the pillars alone would support, before ceilings.

    ``unknown_as_pass`` yields the *known-signal* candidate: UNKNOWN pillars do
    not count against the stage. It is used for the downgrade test so that a
    missing reading never becomes a downgrade basis (N1).
    """
    u = unknown_as_pass
    pillars = payload["pillars"]
    rank = 0  # B1
    if _a_ok(pillars, u) or b_axis_satisfied(payload, _rank("B2"), u):
        rank = _rank("B2")
    if _a_ok(pillars, u) and b_axis_satisfied(payload, _rank("B3"), u):
        rank = _rank("B3")
        if _e_broad(pillars, u) and _c_clean(pillars, u):
            rank = _rank("B4")
            if _a_strong(pillars, u) and (
                pillars["E"] == "CONFIRMED" or (u and pillars["E"] == "UNKNOWN")
            ):
                rank = _rank("B5")
    return _stage(rank)


def compute_ceiling(payload):
    """Ceiling stage + the sources that imposed it (truth table, item 2)."""
    pillars, blockers = payload["pillars"], payload["blockers"]
    ceiling, sources = _rank("B5"), []

    def clamp(rank, source):
        nonlocal ceiling
        if rank < ceiling:
            ceiling = rank
        sources.append(source)

    if blockers["derivatives_led"] == "active":
        clamp(_rank("B2"), "blocker:derivatives_led")
    if blockers["derivatives_overheated"] == "active":
        clamp(_rank("B3"), "blocker:derivatives_overheated")
    if pillars["E"] in ("COLLAPSING", "BTC_ONLY"):
        clamp(_rank("B3"), "pillar_E:%s" % pillars["E"].lower())
    if payload["b_maturity"] == "provisional":
        clamp(_rank("B2"), "maturity:spot_demand:provisional")
    if blockers["spot_weakness"] == "active":
        clamp(_rank("B2"), "blocker:spot_weakness")
    # unknown is never treated as safe: it cannot raise a ceiling, and it
    # freezes promotion below.
    return _stage(ceiling), tuple(sources)


def _data_frozen(payload):
    """stale/missing means the current input itself is not trustworthy:
    promotion and maintenance counters both hold (R3-1)."""
    return payload["data_status"] in ("stale", "missing")


def _freeze_reasons(payload):
    reasons = []
    if _data_frozen(payload):
        reasons.append("data_delayed:%s" % payload["data_status"])
    for name, value in sorted(payload["blockers"].items()):
        if value == "unknown":
            reasons.append("blocker_unknown:%s" % name)
    for name, value in sorted(payload["pillars"].items()):
        if value == "UNKNOWN":
            reasons.append("pillar_unknown:%s" % name)
    return tuple(reasons)


# --------------------------------------------------------------------------
# Transition
# --------------------------------------------------------------------------

def resolve_config(config, envelope):
    """Bind evaluation thresholds to the config the envelope was validated with.

    The caller cannot hand over a threshold dict: values are re-read from the
    source file and its hash must equal ``envelope.config_sha256`` (P1-3).
    """
    path = config if isinstance(config, str) else config.get("_source_path")
    if not path:
        raise EnvelopeContractError(
            "config must be a path or the object returned by load_config()"
        )
    cfg = load_config(path)
    if cfg["_sha256"] != envelope.config_sha256:
        raise EnvelopeContractError(
            "config binding mismatch: evaluation config=%s envelope=%s"
            % (cfg["_sha256"], envelope.config_sha256)
        )
    return cfg


def evaluate(prev, envelope, config):
    """Advance one canonical evaluation. ``envelope`` must be validated."""
    envelope.assert_snapshot()
    cfg = resolve_config(config, envelope)
    payload = envelope.payload
    D = cfg["promotion_consecutive_days"]
    W = cfg["maintenance_breach_days"]
    S_max = cfg["S_max"]

    trace = []
    prev = prev or StageState()

    # 1. structure_break active -> immediate B1, streaks reset (item 4)
    if payload["blockers"]["structure_break"] == "active":
        trace.append("structure_break:active -> immediate B1, streaks reset")
        return StageState(
            effective_stage="B1",
            candidate_stage="B1",
            ceiling_stage="B1",
            ceiling_sources=("blocker:structure_break",),
            stage_age=prev.stage_age + 1 if prev.effective_stage == "B1" else 1,
            promotion_streak=0,
            maintenance_breach_streak=0,
            stale_streak=0,
            frozen=False,
            freeze_reasons=(),
            status="structure_break",
            last_evaluation_id=payload["evaluation_id"],
            decision_trace=tuple(trace),
        )

    candidate = compute_candidate(payload)
    ceiling, ceiling_sources = compute_ceiling(payload)
    freeze_reasons = _freeze_reasons(payload)
    frozen = bool(freeze_reasons)
    data_frozen = _data_frozen(payload)

    allowed = _stage(min(_rank(candidate), _rank(ceiling)))
    # Known-signal view: UNKNOWN readings do not lower this. Only a confirmed
    # deterioration can drive a downgrade (N1).
    known_allowed = _stage(
        min(_rank(compute_candidate(payload, unknown_as_pass=True)), _rank(ceiling))
    )
    trace.append(
        "candidate=%s ceiling=%s known_allowed=%s sources=%s"
        % (candidate, ceiling, known_allowed, list(ceiling_sources))
    )

    effective = prev.effective_stage
    promo = prev.promotion_streak
    breach = prev.maintenance_breach_streak
    stale = prev.stale_streak + 1 if payload["data_status"] in ("stale", "missing") else 0
    status = "ok"

    # 5. unknown / stale / missing freeze promotion only.
    if frozen:
        status = "frozen"
        trace.append("frozen: %s (promotion suspended, streak held)" % list(freeze_reasons))
        if stale > S_max:
            status = "data_delayed_exceeded"
            trace.append("stale_streak=%d exceeds S_max=%d" % (stale, S_max))
    else:
        # 3a. promotion requires D consecutive evaluations with allowed > effective
        if _rank(allowed) > _rank(effective):
            promo += 1
            trace.append("promotion_streak=%d/%d toward %s" % (promo, D, allowed))
            if promo >= D:
                effective = _stage(_rank(effective) + 1)
                promo = 0
                trace.append("promoted -> %s" % effective)
        else:
            if promo:
                trace.append("promotion_streak reset (allowed=%s <= effective=%s)"
                             % (allowed, effective))
            promo = 0

    # 3b. maintenance breach runs on the known-signal view. It keeps running
    #     under an unknown-only freeze, but stale/missing holds it as well
    #     because the input itself is not trustworthy (R3-1).
    if data_frozen:
        trace.append("data freeze: maintenance_breach held at %d" % breach)
    elif _rank(known_allowed) < _rank(effective):
        breach += 1
        trace.append("maintenance_breach=%d/%d (known_allowed=%s < effective=%s)"
                     % (breach, W, known_allowed, effective))
        if breach >= W:
            effective = _stage(_rank(effective) - 1)
            breach = 0
            promo = 0
            trace.append("downgraded -> %s" % effective)
    else:
        if breach:
            trace.append("maintenance_breach reset")
        breach = 0

    age = prev.stage_age + 1 if effective == prev.effective_stage else 1
    return StageState(
        effective_stage=effective,
        candidate_stage=candidate,
        ceiling_stage=ceiling,
        ceiling_sources=ceiling_sources,
        stage_age=age,
        promotion_streak=promo,
        maintenance_breach_streak=breach,
        stale_streak=stale,
        frozen=frozen,
        freeze_reasons=freeze_reasons,
        status=status,
        last_evaluation_id=payload["evaluation_id"],
        decision_trace=tuple(trace),
    )
