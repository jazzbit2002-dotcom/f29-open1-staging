"""F29 Recovery B-engine — Phase 1 fixture (canonical B1~B5).

PRIVATE_ONLY. No public route, no network, no writes outside the private root.
Transition model is NOT part of this package (kickoff item 9).
"""
