"""Canonical ledger: append-only, dedicated revision path, replay (items 6, 9).

Closes the defect class A bypasses by construction:

  * ``append`` accepts ``ValidatedEnvelope`` only. A dict raises immediately.
  * ``append``/``revise`` take no state argument: the write boundary computes
    the state itself from the replayed predecessor, so a forged state cannot
    be injected (P1-2).
  * ``append`` has no ``supersedes`` parameter at all; revisions go through
    ``revise``, which verifies that the target exists, is on the same market
    date, is the current canonical pointer, and carries a revision reason.
  * ``replay`` re-runs ``load_envelope`` on every stored raw payload. A stored
    entry with a stripped or altered SHA field fails there; it is never
    "nothing to compare".
  * canonical entries live under the canonical ledger root; the transition
    model writes elsewhere and this class refuses non-canonical kinds (item 9).
  * Phase 1 restricts revision to the latest market_date; revising older dates
    would leave later stored states stale.
"""
import json
import os

from .contracts import ValidatedEnvelope, load_envelope
from .errors import LedgerContractError, ReplayContractError
from .guard import assert_private_path, open_private
from .statespace import StageState, evaluate

CANONICAL_KINDS = ("us_close", "daily_fallback")


class CanonicalLedger:
    """Append-only JSONL ledger for canonical evaluations."""

    def __init__(self, root, config_path, private_roots=None, engine_dir=None):
        self.root = assert_private_path(root, private_roots)
        self.private_roots = private_roots
        self.config_path = config_path
        self.engine_dir = engine_dir
        self.path = os.path.join(self.root, "canonical.jsonl")
        os.makedirs(self.root, exist_ok=True)

    # ---------------- read -------------------------------------------------
    def entries(self):
        if not os.path.exists(self.path):
            return []
        out = []
        with open(self.path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line:
                    out.append(json.loads(line))
        return out

    def canonical_index(self):
        """market_date -> the active entry (later revision wins)."""
        index = {}
        for e in self.entries():
            index[e["market_date"]] = e
        return index

    def current_pointer(self, market_date):
        return self.canonical_index().get(market_date)

    # ---------------- write ------------------------------------------------
    def _write(self, record):
        with open_private(self.path, "a", private_roots=self.private_roots) as fh:
            fh.write(json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n")

    def _check_kind(self, envelope):
        if envelope.kind not in CANONICAL_KINDS:
            raise LedgerContractError(
                "canonical ledger refuses kind %r (transition output must use its "
                "own ledger)" % envelope.kind
            )

    def _assert_writable(self, envelope):
        """Return a freshly re-validated envelope; only that one is written.

        Type plus snapshot is not enough: the module token can be imported, so
        a caller could assemble a ValidatedEnvelope whose payload never passed
        shape/enum/time validation. The write boundary re-runs the full
        validation and uses its result (R3-2).
        """
        if not isinstance(envelope, ValidatedEnvelope):
            raise LedgerContractError(
                "write requires a ValidatedEnvelope; got %s. Build it with "
                "build_envelope()/load_envelope()." % type(envelope).__name__
            )
        # snapshot + engine/config artifacts must still match (P1-1)
        envelope.assert_intact(self.config_path, engine_dir=self.engine_dir)
        revalidated = load_envelope(
            envelope.payload, self.config_path, engine_dir=self.engine_dir
        )
        self._check_kind(revalidated)
        return revalidated

    def _preflight(self, config):
        """Existing ledger must be intact before anything new is written (R5-2).

        _state_before stops at the target date, so a damaged lineage on the
        same date would otherwise go unnoticed until a later replay.
        """
        if self.entries():
            self.verify_replay_invariant(config)

    def _assert_unique_id(self, evaluation_id):
        for e in self.entries():
            if e["evaluation_id"] == evaluation_id:
                raise LedgerContractError(
                    "duplicate evaluation_id: %s" % evaluation_id
                )

    def _walk(self, config, stop_before=None):
        """Single source of truth for replay semantics (R4-1).

        Both ``_state_before`` and ``replay`` use this, so a revision can never
        be counted as an extra evaluation on one path and as a replacement on
        the other. Revision lineage is validated here as well (R4-2).
        """
        state = StageState()
        before = {}        # market_date -> state entering that date
        pointer = {}       # market_date -> current canonical evaluation_id
        md_of = {}         # evaluation_id -> market_date
        computed = []
        for e in self.entries():
            # validate first: a tampered top-level market_date must not be able
            # to short-circuit the walk and skip its own validation (R5-1)
            envelope = self._revalidate(e)
            md = envelope.market_date
            if stop_before is not None and md >= stop_before:
                break
            eid = envelope.evaluation_id
            sup = e.get("supersedes")
            reason = e.get("revision_reason")
            if eid in md_of:
                raise ReplayContractError("duplicate evaluation_id in ledger: %s" % eid)
            if sup is None:
                if reason is not None:
                    raise ReplayContractError(
                        "entry %s has revision_reason without supersedes" % eid
                    )
                if md in pointer:
                    raise ReplayContractError(
                        "second non-revision entry on market_date %s: %s "
                        "(a repeat verdict for one date must be a revision)"
                        % (md, eid)
                    )
            else:
                if sup not in md_of:
                    raise ReplayContractError(
                        "entry %s supersedes unknown id %r" % (eid, sup)
                    )
                if md_of[sup] != md:
                    raise ReplayContractError(
                        "entry %s supersedes %s on a different market_date (%s != %s)"
                        % (eid, sup, md_of[sup], md)
                    )
                if pointer.get(md) != sup:
                    raise ReplayContractError(
                        "entry %s supersedes %r which was not the current pointer "
                        "for %s (current=%r)" % (eid, sup, md, pointer.get(md))
                    )
                if eid == sup:
                    raise ReplayContractError("entry %s supersedes itself" % eid)
                if not isinstance(reason, str) or not reason.strip():
                    raise ReplayContractError(
                        "revision %s has empty or missing revision_reason" % eid
                    )
                # a revision replaces that date's verdict; rewind to the state
                # that entered the date instead of chaining after the original
                state = before[md]
            before.setdefault(md, state)
            state = evaluate(state, envelope, config)
            pointer[md] = eid
            md_of[eid] = md
            computed.append((e, state))
        return state, computed

    def _state_before(self, market_date, config):
        """State entering ``market_date`` under the same revision semantics."""
        return self._walk(config, stop_before=market_date)[0]

    def append(self, envelope, config):
        """Append a new canonical evaluation. State is computed here."""
        envelope = self._assert_writable(envelope)
        self._preflight(config)
        self._assert_unique_id(envelope.evaluation_id)
        entries = self.entries()
        if entries and envelope.market_date <= entries[-1]["market_date"]:
            raise LedgerContractError(
                "market_date must increase: %s <= %s"
                % (envelope.market_date, entries[-1]["market_date"])
            )
        state = evaluate(self._state_before(envelope.market_date, config),
                         envelope, config)
        self._write(self._record(envelope, state, supersedes=None, reason=None))
        return state

    def revise(self, envelope, config, supersedes, revision_reason):
        """Dedicated revision path (defect class A, item c)."""
        envelope = self._assert_writable(envelope)
        self._preflight(config)
        if envelope.evaluation_id == supersedes:
            raise LedgerContractError(
                "revision evaluation_id must differ from supersedes: %s"
                % supersedes
            )
        self._assert_unique_id(envelope.evaluation_id)
        if not revision_reason or not str(revision_reason).strip():
            raise LedgerContractError("revision_reason is required")
        target = None
        for e in self.entries():
            if e["evaluation_id"] == supersedes:
                target = e
        if target is None:
            raise LedgerContractError("supersedes target does not exist: %r" % supersedes)
        if target["market_date"] != envelope.market_date:
            raise LedgerContractError(
                "revision must stay on the same market_date: target=%s new=%s"
                % (target["market_date"], envelope.market_date)
            )
        entries = self.entries()
        if envelope.market_date != entries[-1]["market_date"]:
            raise LedgerContractError(
                "Phase 1 allows revising only the latest market_date "
                "(latest=%s, given=%s). Mid-history revision requires forward "
                "recomputation of later entries, which is not implemented."
                % (entries[-1]["market_date"], envelope.market_date)
            )
        pointer = self.current_pointer(envelope.market_date)
        if pointer is None or pointer["evaluation_id"] != supersedes:
            raise LedgerContractError(
                "supersedes must be the current canonical pointer for %s "
                "(current=%s, given=%s)"
                % (
                    envelope.market_date,
                    pointer and pointer["evaluation_id"],
                    supersedes,
                )
            )
        # the target record must re-validate in full - envelope and its
        # top-level duplicate fields - before it can be revised (R3-3)
        self._revalidate(target)
        state = evaluate(self._state_before(envelope.market_date, config),
                         envelope, config)
        self._write(
            self._record(envelope, state, supersedes=supersedes,
                         reason=str(revision_reason))
        )
        return state

    def _record(self, envelope, state, supersedes, reason):
        return {
            "evaluation_id": envelope.evaluation_id,
            "market_date": envelope.market_date,
            "kind": envelope.kind,
            "supersedes": supersedes,
            "revision_reason": reason,
            "envelope": envelope.payload,
            "state": state.to_dict(),
        }

    # ---------------- replay ----------------------------------------------
    def _revalidate(self, entry):
        try:
            envelope = load_envelope(
                entry["envelope"], self.config_path, engine_dir=self.engine_dir
            )
        except Exception as exc:
            raise ReplayContractError(
                "stored entry %s failed re-validation: %s"
                % (entry.get("evaluation_id"), exc)
            )
        # top-level duplicates must match the validated envelope exactly (N3):
        # uniqueness checks and revision pointers read the top-level fields.
        for fname, expected in (
            ("evaluation_id", envelope.evaluation_id),
            ("market_date", envelope.market_date),
            ("kind", envelope.kind),
        ):
            if entry.get(fname) != expected:
                raise ReplayContractError(
                    "stored entry top-level %s=%r does not match envelope %r"
                    % (fname, entry.get(fname), expected)
                )
        return envelope

    def replay(self, config):
        """Re-validate every stored envelope and recompute the state chain."""
        state, computed = self._walk(config)
        self._last_replay = computed
        return state

    def verify_replay_invariant(self, config):
        """Every stored state must equal its replayed state, key set included."""
        entries = self.entries()
        if not entries:
            return True
        self.replay(config)
        for entry, state in self._last_replay:
            stored = entry.get("state")
            if not isinstance(stored, dict):
                raise ReplayContractError(
                    "entry %s has no stored state object" % entry.get("evaluation_id")
                )
            expected = state.to_dict()
            if set(stored) != set(expected):
                raise ReplayContractError(
                    "entry %s state key set mismatch: missing=%s unexpected=%s"
                    % (
                        entry.get("evaluation_id"),
                        sorted(set(expected) - set(stored)),
                        sorted(set(stored) - set(expected)),
                    )
                )
            diffs = {k: (stored[k], expected[k]) for k in expected if stored[k] != expected[k]}
            if diffs:
                raise ReplayContractError(
                    "entry %s stored state != replay: %s"
                    % (entry.get("evaluation_id"), diffs)
                )
        return True
