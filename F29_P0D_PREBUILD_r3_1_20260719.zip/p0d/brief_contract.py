#!/usr/bin/env python3
# F29 P0-D / D-3 — us_macro_brief_v1 fail-closed contract validator
# 2026-07-19 PREBUILD. Local bundle only. No deploy, no cron, no publish.
#
# Pure stdlib (no jsonschema dependency). Import from us_macro_delivery.py:
#     from brief_contract import validate_brief, ContractError
#
# Contract source: F29_US_BRIEFING_RULING_20260719_P0D.md  §9-1 / D-2 / D-3
# Fail-closed: any violation -> non-zero exit at caller, no canonical save,
#              no latest update, no publish. Raw model response may be kept
#              as failure evidence only.

import json
import re
import unicodedata

SCHEMA_VERSION = "us_macro_brief_v1"

DISCLAIMER = (
    "이 글은 시장 구조를 분석한 참고 자료이며 투자 권유가 아닙니다. "
    "투자 판단과 그 결과에 대한 책임은 본인에게 있습니다."
)

ALLOWED_SECTION_IDS = [
    "conclusion",
    "breadth",
    "size_style",
    "rates_vol",
    "commodities",
    "semis_sectors",
    "rotation",
    "value_chain_radar",
    "next_session",
]

# baseline_only 에서 금지되는 절 — 비교 기준이 없으므로 변화 서술 불가
BASELINE_FORBIDDEN_IDS = {"size_style", "rates_vol", "commodities", "semis_sectors"}

REQUIRED_SECTION_IDS = {"conclusion", "next_session"}

# moneyflow_digest 가 사용 가능하면 추가로 필수 — F29 차별 데이터 누락 방지
DIGEST_REQUIRED_SECTION_IDS = {"rotation", "value_chain_radar"}

FORBIDDEN = [
    "매수 추천", "매도 신호", "목표가", "손절", "순유입", "순유출",
    "진입", "청산", "예측", "적중", "신뢰도", "적중률",
]

INTERNAL = [
    "F29", "briefing-context", "briefing_context", "market_internals",
    "market_close_snapshot", "market_close_comparison", "lifecycle",
    "freshness", "theme_flow", "intraday", "moneyflow_digest",
    "stock_radar", "value_chains", "horizon_leaders", "theme_ranking",
    "strength_quality", "d_score", "d_rank",
]

BADPHRASE = ["공식 종가", "settlement", "확정 종가", "공식 일일"]

# v7 §9-3 (2) 자금 이동 은유 — 실제 순자금액 오해 유발
# 사이에 부사구가 끼어드는 형태("돈이 전체로 퍼지기보다")까지 잡기 위해 정규식으로 둔다.
MONEY_METAPHOR_RE = [
    re.compile(r"돈[이을]?[^.。\n]{0,12}?(몰렸|몰리|빠졌|빠져|빠지|퍼졌|퍼지|들어왔|들어오|이동)"),
    re.compile(r"자금[이을]?[^.。\n]{0,12}?(몰렸|몰리|빠졌|빠져|빠지|유입|유출|이탈|들어왔)"),
    re.compile(r"(수급|자금)\s*유입"),
]

TEXT_FIELDS_TOP = [
    "headline", "deck", "social_summary", "email_subject",
    "email_preview", "disclaimer",
]

TICKER_RE = re.compile(r"^[A-Z][A-Z0-9.-]{0,9}$")
ASOF_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
NUM_RE = re.compile(r"\d+(?:\.\d+)?")

# L1-3: 숫자만 대조하면 1bp 와 1% 가 같아진다. 단위까지 묶어 토큰화한다.
UNIT_RE = re.compile(
    r"(\d+(?:\.\d+)?)\s*(%p|%|bp|포인트|억\s*주|만\s*주|계단|배|개|일|위)?"
)


def number_tokens(text):
    """Return {(number_string, unit_string)}. unit '' means bare number."""
    out = set()
    if not isinstance(text, str):
        return out
    for m in UNIT_RE.finditer(text):
        num = m.group(1)
        unit = (m.group(2) or "").replace(" ", "")
        out.add((num, unit))
    return out


def numbers_absent_from(source_tokens, text):
    """Tokens in `text` that the source corpus does not support.
    A token carrying a unit must match number AND unit exactly.
    A bare number may match the same number under any unit."""
    bad = []
    bare = {n for n, _u in source_tokens}
    for num, unit in number_tokens(text):
        if unit:
            if (num, unit) not in source_tokens:
                bad.append("%s%s" % (num, unit))
        else:
            if num not in bare:
                bad.append(num)
    return bad

LIMITS = {
    "headline": (12, 60),
    "deck": (30, 160),
    "social_summary": (80, 240),
    "email_subject": (10, 50),
    "email_preview": (30, 120),
}

SECTION_LIMITS = {"title": (2, 30), "body": (60, 900)}


class ContractError(Exception):
    """Raised on any contract violation. Caller must fail closed."""

    def __init__(self, violations):
        self.violations = violations
        Exception.__init__(self, "; ".join(violations))


# ---------------------------------------------------------------- helpers

def _norm(s):
    """NFKC + collapse internal whitespace. Used for name matching only —
    never mutates the value that gets stored."""
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", s or ""))


def _walk_strings(obj, path="$"):
    """Recursively yield (path, string) for every string in the object."""
    if isinstance(obj, str):
        yield path, obj
    elif isinstance(obj, dict):
        for k, v in obj.items():
            for r in _walk_strings(v, "%s.%s" % (path, k)):
                yield r
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            for r in _walk_strings(v, "%s[%d]" % (path, i)):
                yield r


def build_allowlists(context):
    """Derive ticker / theme / name allowlists from the ACTUAL briefing-context
    payload. Never hardcode, never guess — §9 forbids field-name inference.

    Returns (tickers:set, themes_exact:set, name_to_ticker:dict)

    themes_exact holds the source strings verbatim (only outer whitespace
    stripped). Theme metadata feeds theme links downstream, so an inner-space
    variant must NOT pass — comparison is exact, not normalized.
    """
    tickers = set()
    themes = set()
    name_to_ticker = {}

    g = (context or {}).get("moneyflow_digest") or {}

    radar = g.get("stock_radar") or {}
    for bucket in radar.values():
        if not isinstance(bucket, list):
            continue
        for it in bucket:
            if not isinstance(it, dict):
                continue
            t = (it.get("ticker") or "").strip().upper()
            if t:
                tickers.add(t)
                nm = (it.get("name") or "").strip()
                if nm:
                    name_to_ticker[_norm(nm)] = t
            th = (it.get("theme") or "").strip()
            if th:
                themes.add(th.strip())

    tr = g.get("theme_ranking") or {}
    for bucket in tr.values():
        if not isinstance(bucket, list):
            continue
        for it in bucket:
            if isinstance(it, dict) and it.get("theme"):
                themes.add(it["theme"].strip())

    hl = g.get("horizon_leaders") or {}
    for bucket in hl.values():
        if isinstance(bucket, list):
            for th in bucket:
                if isinstance(th, str) and th.strip():
                    themes.add(th.strip())

    for vc in (g.get("value_chains") or []):
        if not isinstance(vc, dict):
            continue
        for k in ("group", "lead"):
            if vc.get(k):
                themes.add(vc[k].strip())
        for m in (vc.get("members") or []):
            if isinstance(m, dict) and m.get("theme"):
                themes.add(m["theme"].strip())

    sq = g.get("strength_quality") or {}
    if isinstance(sq, dict) and sq.get("theme"):
        themes.add(sq["theme"].strip())

    # leaders / exits / watching (non-digest summary fields) may also carry tickers
    for key in ("leaders", "exits", "watching"):
        for it in (context or {}).get(key) or []:
            if isinstance(it, dict):
                t = (it.get("ticker") or "").strip().upper()
                if t:
                    tickers.add(t)
                    nm = (it.get("name") or "").strip()
                    if nm:
                        name_to_ticker.setdefault(_norm(nm), t)

    themes.discard("")
    return tickers, themes, name_to_ticker


# ---------------------------------------------------------------- checks

def _check_shape(b, v):
    if not isinstance(b, dict):
        v.append("root is not an object")
        return False

    if b.get("schema_version") != SCHEMA_VERSION:
        v.append("schema_version != %s (got %r)"
                 % (SCHEMA_VERSION, b.get("schema_version")))

    required = ["schema_version", "as_of", "headline", "deck", "key_points",
                "sections", "watchpoints", "social_summary", "email_subject",
                "email_preview", "disclaimer"]
    for k in required:
        if k not in b:
            v.append("missing required field: %s" % k)

    extra = set(b.keys()) - set(required)
    if extra:
        v.append("unexpected top-level field(s): %s" % ", ".join(sorted(extra)))

    for k in TEXT_FIELDS_TOP:
        if k in b and not isinstance(b[k], str):
            v.append("%s must be string" % k)

    for k in ("key_points", "sections", "watchpoints"):
        if k in b and not isinstance(b[k], list):
            v.append("%s must be array" % k)

    return not v


def _check_lengths(b, v):
    for k, (lo, hi) in LIMITS.items():
        s = b.get(k)
        if isinstance(s, str):
            n = len(s.strip())
            if n == 0:
                v.append("%s is empty" % k)
            elif not (lo <= n <= hi):
                v.append("%s length %d out of range %d~%d" % (k, n, lo, hi))

    kp = b.get("key_points")
    if isinstance(kp, list):
        if len(kp) != 3:
            v.append("key_points must be exactly 3 (got %d)" % len(kp))
        for i, s in enumerate(kp):
            if not isinstance(s, str) or not s.strip():
                v.append("key_points[%d] empty or not string" % i)
            elif not (12 <= len(s.strip()) <= 120):
                v.append("key_points[%d] length %d out of range 12~120"
                         % (i, len(s.strip())))

    wp = b.get("watchpoints")
    if isinstance(wp, list):
        if not (1 <= len(wp) <= 3):
            v.append("watchpoints must be 1~3 (got %d)" % len(wp))
        for i, s in enumerate(wp):
            if not isinstance(s, str) or not s.strip():
                v.append("watchpoints[%d] empty or not string" % i)
            elif not (15 <= len(s.strip()) <= 200):
                v.append("watchpoints[%d] length %d out of range 15~200"
                         % (i, len(s.strip())))


def _digest_is_usable(context):
    """moneyflow_digest 가 제공되고 차별 근거 필드가 비어 있지 않은지."""
    g = (context or {}).get("moneyflow_digest") or {}
    if not isinstance(g, dict):
        return False
    hl = g.get("horizon_leaders") or {}
    radar = g.get("stock_radar") or {}
    has_horizon = any((hl.get(k) or []) for k in ("d7", "d30", "d90"))
    has_chain = bool(g.get("value_chains"))
    has_radar = any((radar.get(k) or []) for k in
                    ("dual_axis_winners", "mixed", "dual_axis_laggards", "watching"))
    return bool(has_horizon and (has_chain or has_radar))


def _check_sections(b, v, comparison_status, digest_usable=False):
    secs = b.get("sections")
    if not isinstance(secs, list):
        return
    if not (4 <= len(secs) <= 8):
        v.append("sections must be 4~8 (got %d)" % len(secs))

    seen = []
    for i, s in enumerate(secs):
        if not isinstance(s, dict):
            v.append("sections[%d] not an object" % i)
            continue
        for k in ("id", "title", "body", "tickers", "themes"):
            if k not in s:
                v.append("sections[%d] missing %s" % (i, k))
        extra = set(s.keys()) - {"id", "title", "body", "tickers", "themes"}
        if extra:
            v.append("sections[%d] unexpected field(s): %s"
                     % (i, ", ".join(sorted(extra))))

        sid = s.get("id")
        if sid in seen:
            v.append("duplicate section id: %s" % sid)
        seen.append(sid)
        if sid not in ALLOWED_SECTION_IDS:
            v.append("sections[%d] id not allowed: %r" % (i, sid))
        if comparison_status == "baseline_only" and sid in BASELINE_FORBIDDEN_IDS:
            v.append("sections[%d] id %r forbidden when comparison is baseline_only"
                     % (i, sid))

        for k, (lo, hi) in SECTION_LIMITS.items():
            t = s.get(k)
            if not isinstance(t, str) or not t.strip():
                v.append("sections[%d].%s empty or not string" % (i, k))
            elif not (lo <= len(t.strip()) <= hi):
                v.append("sections[%d].%s length %d out of range %d~%d"
                         % (i, k, len(t.strip()), lo, hi))

        for k in ("tickers", "themes"):
            arr = s.get(k)
            if not isinstance(arr, list):
                v.append("sections[%d].%s must be array" % (i, k))
                continue
            for j, x in enumerate(arr):
                if not isinstance(x, str) or not x.strip():
                    v.append("sections[%d].%s[%d] empty or not string" % (i, k, j))

    required = set(REQUIRED_SECTION_IDS)
    if digest_usable:
        required |= DIGEST_REQUIRED_SECTION_IDS
    missing = required - set(seen)
    if missing:
        v.append("required section id(s) missing: %s" % ", ".join(sorted(missing)))


def _check_vocab(b, v):
    for path, s in _walk_strings(b):
        if path == "$.disclaimer":
            continue
        for w in FORBIDDEN:
            if w in s:
                v.append("forbidden word %r at %s" % (w, path))
        for w in INTERNAL:
            if w in s:
                v.append("internal name %r at %s" % (w, path))
        for w in BADPHRASE:
            if w in s:
                v.append("banned phrase %r at %s" % (w, path))
        for rx in MONEY_METAPHOR_RE:
            m = rx.search(s)
            if m:
                v.append("money-flow metaphor %r at %s" % (m.group(0), path))


def _check_tickers_themes(b, v, allow_tickers, allow_themes, name_to_ticker):
    secs = b.get("sections") or []
    all_tickers = []

    for i, s in enumerate(secs):
        if not isinstance(s, dict):
            continue
        body = s.get("body") if isinstance(s.get("body"), str) else ""
        declared = [t for t in (s.get("tickers") or []) if isinstance(t, str)]

        for t in declared:
            if not TICKER_RE.match(t):
                v.append("sections[%d].tickers %r not uppercase ticker form" % (i, t))
            elif t not in allow_tickers:
                v.append("sections[%d].tickers %r not in context allowlist" % (i, t))
            all_tickers.append(t)

        # body mention -> must be declared
        nb = _norm(body)
        for nm, tk in name_to_ticker.items():
            if nm and nm in nb and tk not in declared:
                v.append("sections[%d] body mentions company (%s) not in tickers" % (i, tk))
        for t in allow_tickers:
            if re.search(r"(?<![A-Z0-9])%s(?![A-Z0-9])" % re.escape(t), body) \
                    and t not in declared:
                v.append("sections[%d] body mentions %s not in tickers" % (i, t))

        # declared -> must appear in body (no orphan metadata)
        for t in declared:
            hit = re.search(r"(?<![A-Z0-9])%s(?![A-Z0-9])" % re.escape(t), body)
            if not hit:
                names = [n for n, tk in name_to_ticker.items() if tk == t]
                hit = any(n in nb for n in names)
            if not hit:
                v.append("sections[%d].tickers %r declared but not mentioned in body"
                         % (i, t))

        if len(declared) > 4:
            v.append("sections[%d].tickers %d exceeds max 4" % (i, len(declared)))
        if len(declared) != len(set(declared)):
            v.append("sections[%d].tickers contains duplicates" % i)

        themes = [t for t in (s.get("themes") or []) if isinstance(t, str)]
        if len(themes) > 6:
            v.append("sections[%d].themes %d exceeds max 6" % (i, len(themes)))
        if len(themes) != len(set(themes)):
            v.append("sections[%d].themes contains duplicates" % i)
        for th in themes:
            if th not in allow_themes:
                v.append("sections[%d].themes %r not an exact source theme" % (i, th))

    if len(set(all_tickers)) > 8:
        v.append("total distinct tickers %d exceeds 8" % len(set(all_tickers)))


def _check_watchpoints_derived(b, v):
    """watchpoints 는 next_session body 를 1~3개로 재정리한 것이다.
    next_session 에 없는 새 숫자를 넣을 수 없다."""
    nxt = ""
    for s in (b.get("sections") or []):
        if isinstance(s, dict) and s.get("id") == "next_session" \
                and isinstance(s.get("body"), str):
            nxt = s["body"]
    if not nxt:
        return
    src = number_tokens(nxt)
    for i, s in enumerate(b.get("watchpoints") or []):
        if isinstance(s, str):
            for tok in numbers_absent_from(src, s):
                v.append("watchpoints[%d] introduces %s absent from next_session body"
                         % (i, tok))


def _check_social_no_new_claim(b, v):
    """social_summary / email_* must not introduce entities, numbers, or
    number+unit pairs that the body does not support."""
    corpus = []
    for k in ("headline", "deck"):
        if isinstance(b.get(k), str):
            corpus.append(b[k])
    for s in (b.get("key_points") or []):
        if isinstance(s, str):
            corpus.append(s)
    for s in (b.get("sections") or []):
        if isinstance(s, dict):
            for k in ("title", "body"):
                if isinstance(s.get(k), str):
                    corpus.append(s[k])
    for s in (b.get("watchpoints") or []):
        if isinstance(s, str):
            corpus.append(s)
    joined_raw = " ".join(corpus)
    src_tokens = number_tokens(joined_raw)

    for field in ("social_summary", "email_subject", "email_preview"):
        s = b.get(field)
        if not isinstance(s, str):
            continue
        for tok in numbers_absent_from(src_tokens, s):
            v.append("%s introduces %s absent from body (number/unit mismatch)"
                     % (field, tok))
        for t in set(re.findall(r"(?<![A-Za-z0-9])[A-Z]{2,6}(?![A-Za-z0-9])", s)):
            if t not in joined_raw:
                v.append("%s introduces ticker %s absent from body" % (field, t))

    # key_points 도 본문(sections/watchpoints)이 뒷받침해야 한다
    body_only = []
    for s in (b.get("sections") or []):
        if isinstance(s, dict) and isinstance(s.get("body"), str):
            body_only.append(s["body"])
    body_tokens = number_tokens(" ".join(body_only))
    for i, s in enumerate(b.get("key_points") or []):
        if isinstance(s, str):
            for tok in numbers_absent_from(body_tokens, s):
                v.append("key_points[%d] introduces %s absent from section bodies"
                         % (i, tok))


def _check_disclaimer_asof(b, v, expected_as_of):
    if b.get("disclaimer") != DISCLAIMER:
        v.append("disclaimer does not match canonical text exactly")
    a = b.get("as_of")
    if not isinstance(a, str) or not ASOF_RE.match(a or ""):
        v.append("as_of malformed: %r" % a)
    elif expected_as_of and a != expected_as_of:
        v.append("as_of %s != context as_of %s" % (a, expected_as_of))


def _check_volume(b, v, comparison_status):
    lo, hi = (1000, 1600) if comparison_status == "baseline_only" else (1500, 2500)
    parts = []
    if isinstance(b.get("deck"), str):
        parts.append(b["deck"])
    for s in (b.get("key_points") or []):
        if isinstance(s, str):
            parts.append(s)
    for s in (b.get("sections") or []):
        if isinstance(s, dict) and isinstance(s.get("body"), str):
            parts.append(s["body"])
    for s in (b.get("watchpoints") or []):
        if isinstance(s, str):
            parts.append(s)
    n = sum(len(p.strip()) for p in parts)
    if not (lo <= n <= hi):
        v.append("prose volume %d out of range %d~%d (%s)"
                 % (n, lo, hi, comparison_status))
    return n


# ---------------------------------------------------------------- entry

def parse_model_output(text):
    """Extract the JSON object from a raw model response.
    Tolerates a ```json fence but nothing else. Fails closed on anything
    that is not a single parseable object."""
    if not isinstance(text, str) or not text.strip():
        raise ContractError(["empty model response"])
    s = text.strip()
    if s.startswith("```"):
        s = re.sub(r"^```[a-zA-Z]*\s*", "", s)
        s = re.sub(r"\s*```$", "", s.strip())
    try:
        obj = json.loads(s)
    except Exception as e:
        raise ContractError(["JSON parse failed: %s" % str(e)[:160]])
    if not isinstance(obj, dict):
        raise ContractError(["top-level JSON is %s, expected object"
                             % type(obj).__name__])
    return obj


VALID_COMPARISON_STATUS = {"ready", "baseline_only"}


def validate_brief(brief, context, comparison_status, expected_as_of=None):
    """Full contract validation. Returns dict of computed metrics.
    Raises ContractError with the complete violation list on any failure."""
    v = []
    if comparison_status not in VALID_COMPARISON_STATUS:
        raise ContractError(["comparison_status invalid: %r (allowed: %s)"
                             % (comparison_status,
                                ", ".join(sorted(VALID_COMPARISON_STATUS)))])
    if expected_as_of is None:
        cs = ((context or {}).get("market_internals") or {}) \
            .get("market_close_snapshot") or {}
        expected_as_of = cs.get("as_of") or (context or {}).get("as_of")

    if not _check_shape(brief, v):
        raise ContractError(v)

    allow_tickers, allow_themes, name_to_ticker = build_allowlists(context)

    digest_usable = _digest_is_usable(context)

    _check_lengths(brief, v)
    _check_sections(brief, v, comparison_status, digest_usable)
    _check_vocab(brief, v)
    _check_tickers_themes(brief, v, allow_tickers, allow_themes, name_to_ticker)
    _check_watchpoints_derived(brief, v)
    _check_social_no_new_claim(brief, v)
    _check_disclaimer_asof(brief, v, expected_as_of)
    volume = _check_volume(brief, v, comparison_status)

    if v:
        raise ContractError(v)

    return {
        "prose_chars": volume,
        "section_ids": [s.get("id") for s in brief.get("sections", [])],
        "distinct_tickers": sorted({t for s in brief.get("sections", [])
                                    for t in (s.get("tickers") or [])}),
        "allowlist_sizes": {"tickers": len(allow_tickers),
                            "themes": len(allow_themes)},
        "digest_usable": digest_usable,
    }


def validate_raw(text, context, comparison_status, expected_as_of=None):
    """parse + validate in one step."""
    brief = parse_model_output(text)
    metrics = validate_brief(brief, context, comparison_status, expected_as_of)
    return brief, metrics
