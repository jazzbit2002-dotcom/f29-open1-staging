#!/usr/bin/env python3
# F29 P0-D / §9-2 — 합성 fixture 12종 생성기
# 계약 검증 전용. 시장 판단에 사용하지 않는다.
# 실행: python3 make_fixtures.py   (fixtures/ 아래에 기록)

import json, os, copy

HERE = os.path.dirname(os.path.abspath(__file__))
FX = os.path.join(HERE, "fixtures")
os.makedirs(FX, exist_ok=True)

DISCLAIMER = ("이 글은 시장 구조를 분석한 참고 자료이며 투자 권유가 아닙니다. "
              "투자 판단과 그 결과에 대한 책임은 본인에게 있습니다.")


def rs(a, b, c, d):
    return {"sector_20": a, "market_20": b, "sector_60": c, "market_60": d}


# ---------------------------------------------------------------- context
CONTEXT_BASE = {
    "as_of": "2026-07-17",
    "generated": "2026-07-18T23:28:19.067Z",
    "market_internals": {
        "market_close_snapshot": {
            "as_of": "2026-07-17",
            "freshness": {"state": "fresh", "reason": "ok"},
            "data": {"spy": 743.23, "qqq": 612.4, "vix": 18.46, "tnx": 4.542},
        },
        "daily": {
            "as_of": "2026-07-17",
            "freshness": {"state": "fresh", "reason": "ok"},
            "data": {"hign": 148, "lown": 12, "higq": 166, "lowq": 45,
                     "s5th": 69.1, "ndth": 66.2, "uvol": 705.2, "dvol": 547.4},
        },
        "intraday": {"data": {"tick": 120}},
    },
    "moneyflow_digest": {
        "theme_ranking": {
            "top": [
                {"theme": "금융", "score": 89, "direction": "상승", "d_score": -2, "d_rank": 0},
                {"theme": "헬스혁신", "score": 86, "direction": "상승", "d_score": -2, "d_rank": 0},
                {"theme": "운송", "score": 85, "direction": "상승", "d_score": 5, "d_rank": 0},
                {"theme": "바이오", "score": 78, "direction": "유지", "d_score": 5, "d_rank": 3},
                {"theme": "필수소비", "score": 75, "direction": "상승", "d_score": 1, "d_rank": 0},
            ],
            "fast_risers": [
                {"theme": "사이버보안", "score": 70, "direction": "상승", "d_score": 11, "d_rank": 7},
                {"theme": "농업", "score": 64, "direction": "상승", "d_score": 10, "d_rank": 3},
                {"theme": "에너지", "score": 59, "direction": "유지", "d_score": 7, "d_rank": 3},
            ],
            "fast_fallers": [
                {"theme": "게임", "score": 51, "direction": "유지", "d_score": -26, "d_rank": -14},
                {"theme": "전력인프라", "score": 30, "direction": "약화", "d_score": -13, "d_rank": -4},
                {"theme": "인프라건설", "score": 64, "direction": "둔화", "d_score": -2, "d_rank": -4},
            ],
        },
        "horizon_leaders": {
            "d7": ["필수소비", "금융", "부동산"],
            "d30": ["금융", "헬스혁신", "운송"],
            "d90": ["반도체", "반도체장비", "사이버보안"],
        },
        "value_chains": [
            {"group": "반도체", "lead": "반도체", "gap": 13,
             "members": [{"theme": "반도체", "score": 41},
                         {"theme": "반도체장비", "score": 34},
                         {"theme": "AI인프라", "score": 28}]},
            {"group": "에너지", "lead": "에너지", "gap": 29,
             "members": [{"theme": "에너지", "score": 59},
                         {"theme": "전력인프라", "score": 30},
                         {"theme": "원자력", "score": 18}]},
        ],
        "strength_quality": {"theme": "금융", "거래량동반": "충족",
                             "상대강도": "충족", "추세지속성": "충족"},
        "rotation": {"confirmed": "혼합", "candidate": "혼합",
                     "detail": "부정 우위 혼합", "pos": 7, "neg": 8, "lead": 2},
        "stock_radar": {
            "dual_axis_winners": [
                {"ticker": "OKTA", "name": "옥타", "theme": "보안SW", "axis": "양축우위",
                 "lifecycle": "신규부상", "rs": rs(23.7, 32.5, 19.2, 28.1)},
                {"ticker": "META", "name": "메타", "theme": "인터넷", "axis": "양축우위",
                 "lifecycle": "강화", "rs": rs(11.1, 17.0, 9.4, 14.2)},
                {"ticker": "MSFT", "name": "마이크로소프트", "theme": "클라우드",
                 "axis": "양축우위", "lifecycle": "주도", "rs": rs(9.9, 8.3, 7.1, 6.0)},
            ],
            "mixed": [
                {"ticker": "NVDA", "name": "엔비디아", "theme": "반도체", "axis": "혼조",
                 "lifecycle": "둔화관찰", "rs": rs(13.8, 3.5, 10.2, 2.1)},
                {"ticker": "AVGO", "name": "브로드컴", "theme": "반도체", "axis": "혼조",
                 "lifecycle": "관심도성숙", "rs": rs(8.7, -1.7, 6.3, -2.4)},
            ],
            "dual_axis_laggards": [
                {"ticker": "MRVL", "name": "마벨", "theme": "반도체", "axis": "양축열위",
                 "lifecycle": "이탈", "rs": rs(-30.2, -40.6, -25.1, -33.8)},
                {"ticker": "MU", "name": "마이크론", "theme": "반도체", "axis": "양축열위",
                 "lifecycle": "이탈관찰", "rs": rs(-7.8, -18.2, -6.1, -14.9)},
            ],
            "watching": [
                {"ticker": "IONQ", "name": "아이온큐", "theme": "양자컴퓨팅", "axis": "미확정",
                 "lifecycle": "관찰시작", "rs": rs(2.1, -1.2, 1.0, -0.8), "watch": "관찰"},
            ],
        },
        "note": "관심도 점수 기반 상태 분류",
    },
}

CONTEXT_READY = copy.deepcopy(CONTEXT_BASE)
CONTEXT_READY["as_of"] = "2026-07-20"
CONTEXT_READY["market_internals"]["market_close_snapshot"]["as_of"] = "2026-07-20"
CONTEXT_READY["market_internals"]["daily"]["as_of"] = "2026-07-20"

COMPARISON_READY = {
    "market_close_comparison": {
        "status": "ready",
        "current_as_of": "2026-07-20",
        "previous_as_of": "2026-07-17",
        "reference_label": "직전 보존 미국 거래 세션 대비",
        "price_change_pct": {"spy": 0.412, "qqq": 0.688, "iwm": -0.231,
                             "rsp": 0.104, "soxx": 1.203, "xlk": 0.771,
                             "xlf": 0.089, "xlp": -0.140, "xly": 0.352,
                             "dxy": -0.118, "cl1": 1.442, "brn1": 1.310,
                             "usdjpy": -0.207, "hyg": 0.061, "lqd": 0.133,
                             "srln": 0.012},
        "rate_change_bp": {"tnx": -1.2, "us02y": 0.8},
        "volatility_change": {"vix": {"points": 2.04, "pct": 12.4},
                              "move": {"points": -1.1, "pct": -1.6}},
        "relative_performance_pct": {"large_vs_small": 0.643,
                                     "capweight_vs_equalweight": 0.308,
                                     "nasdaq_vs_market": 0.276,
                                     "semi_vs_tech": 0.432,
                                     "cyclical_vs_staples": 0.492},
    }
}

COMPARISON_BASELINE = {
    "market_close_comparison": {"status": "baseline_only",
                                "current_as_of": "2026-07-17",
                                "previous_as_of": None}
}


# ---------------------------------------------------------------- baseline brief
B_CONCLUSION = (
    "미국장 마감 시점 기준으로 시장은 한 방향으로 뚜렷하게 쏠린 모습이 아니었습니다. "
    "시장의 선택이 전체로 넓게 퍼지기보다 일부 업종으로 좁혀졌고, 힘이 붙은 업종과 "
    "흐름에서 멀어진 업종이 동시에 나타났습니다. 지수의 방향보다 그 안에서 무엇이 "
    "갈렸는지가 더 중요했던 하루로 정리할 수 있습니다."
)
B_BREADTH = (
    "뉴욕증권거래소에서는 신고가 종목이 148개, 신저가가 12개로 신고가 쪽이 앞섰습니다. "
    "나스닥에서도 신고가 166개, 신저가 45개로 같은 방향이었습니다. 200일 이동평균선 위에 "
    "있는 종목 비율은 주요 시장 기준 약 69%, 나스닥 기준 약 66%로 장기 추세가 무너진 종목이 "
    "다수는 아니라는 뜻입니다. 상승 거래량은 약 7억 주, 하락 거래량은 약 5억 주로 상승 쪽 "
    "체결량이 더 컸습니다. 표면 아래에서도 오른 종목의 체결이 우위에 있었다는 점을 확인할 수 있습니다."
)
B_ROTATION = (
    "관심도 상위에는 금융과 헬스혁신, 운송이 자리했고 사이버보안은 순위가 7계단, 점수가 11 오르며 "
    "빠르게 올라왔습니다. 반대로 게임은 점수가 26 내리며 크게 밀렸고 전력인프라도 약해진 쪽에 "
    "놓였습니다. 시간 축을 나누면 대비가 분명해집니다. 7일 기준 강세축은 필수소비와 금융, 부동산이지만 "
    "90일 기준 주도축은 여전히 반도체와 반도체장비, 사이버보안에 남아 있습니다. 장기 주도축이 무너졌다기보다 "
    "단기적으로 시장의 선택이 다른 업종으로 옮겨간 순환 관찰 구간에 가깝습니다. 금융은 점수만 높은 것이 "
    "아니라 거래량 동반과 상대강도, 추세 지속성 조건을 함께 충족한 상태입니다."
)
B_RADAR = (
    "산업 계열 안을 들여다보면 강약 차이가 뚜렷합니다. 반도체 계열에서는 반도체 본체가 가장 앞섰고 "
    "반도체장비와 AI인프라가 뒤를 이었습니다. 에너지 계열의 격차는 더 컸습니다. 종목 단위에서도 갈림이 "
    "확인됩니다. OKTA와 META는 자기 업종과 시장을 모두 앞선 쪽에 놓였습니다. 반면 NVDA는 반도체 안에서는 "
    "20거래일 상대강도가 13.8%p로 앞섰지만 시장 대비로는 3.5%p에 그쳐 우위가 뚜렷하지 않았습니다. "
    "같은 업종의 MRVL은 업종 대비 -30.2%p, 시장 대비 -40.6%p로 양쪽 모두 크게 밑돌았습니다. "
    "같은 산업에 속해 있어도 종목별로 결과가 갈렸다는 뜻입니다."
)
B_NEXT = (
    "이번 자료는 직전 세션과의 비교 기준이 아직 마련되지 않아 지수와 금리, 변동성, 유가의 전일 대비 "
    "변화는 다루지 않았습니다. 비교값은 오늘부터 쌓이므로 다음 거래일부터는 금융과 운송의 상위 흐름이 "
    "이어지는지, 사이버보안의 빠른 개선이 계속되는지를 확인할 수 있습니다."
)

BASELINE_VALID = {
    "schema_version": "us_macro_brief_v1",
    "as_of": "2026-07-17",
    "headline": "지수 방향보다 시장 내부의 갈림이 컸던 하루",
    "deck": "신고가 종목이 앞서며 시장 체력은 유지됐지만 같은 업종 안에서도 종목별 결과가 크게 갈렸습니다.",
    "key_points": [
        "신고가 종목과 상승 거래량이 모두 앞서 시장 체력은 유지됐습니다.",
        "7일 강세축은 필수소비와 금융이지만 90일 주도축은 반도체 계열에 남아 있습니다.",
        "같은 반도체 안에서도 NVDA와 MRVL의 상대강도 격차가 크게 벌어졌습니다.",
    ],
    "sections": [
        {"id": "conclusion", "title": "오늘의 결론", "body": B_CONCLUSION,
         "tickers": [], "themes": []},
        {"id": "breadth", "title": "시장 체력과 스타일", "body": B_BREADTH,
         "tickers": [], "themes": []},
        {"id": "rotation", "title": "시장의 선택이 옮겨간 곳", "body": B_ROTATION,
         "tickers": [],
         "themes": ["금융", "헬스혁신", "운송", "사이버보안", "필수소비", "게임"]},
        {"id": "value_chain_radar", "title": "산업 안의 강약과 종목 레이더", "body": B_RADAR,
         "tickers": ["OKTA", "META", "NVDA", "MRVL"],
         "themes": ["반도체", "반도체장비", "AI인프라", "에너지"]},
        {"id": "next_session", "title": "다음 거래일 확인 조건", "body": B_NEXT,
         "tickers": [], "themes": ["금융", "운송", "사이버보안"]},
    ],
    "watchpoints": [
        "금융과 운송이 상위 흐름을 유지하는지 확인할 지점입니다.",
        "반도체 안에서 종목별 상대강도 격차가 더 벌어지는지 확인할 지점입니다.",
    ],
    "social_summary": ("미국장은 지수보다 내부의 갈림이 컸던 하루였습니다. "
                       "신고가 종목과 상승 거래량은 앞섰지만 7일 강세축은 필수소비와 금융으로 "
                       "옮겨갔고 90일 주도축은 반도체 계열에 남았습니다."),
    "email_subject": "지수보다 내부 갈림이 컸던 미국장",
    "email_preview": "시장 체력은 유지됐지만 같은 업종 안에서도 종목별 결과가 갈렸습니다.",
    "disclaimer": DISCLAIMER,
}


# ---------------------------------------------------------------- ready brief
R_SIZE = (
    "대형주와 소형주를 나란히 놓으면 대형주가 0.64%p 앞섰습니다. 시총가중 대비 동일가중 상대수익률은 "
    "0.31%p로 역시 대형주 쪽이 우위였고, 나스닥은 시장 대비 0.28%p 앞섰습니다. 지수 상승이 넓게 퍼지기보다 "
    "규모가 큰 쪽에 더 기울었던 구성입니다."
)
R_RATES = (
    "10년물 금리는 직전 세션보다 1.2bp 내렸고 2년물은 0.8bp 올랐습니다. 변동성 지표는 2.04포인트 오른 반면 "
    "금리 변동성 지표는 1.1포인트 내려 서로 다른 방향을 보였습니다. 회사채 쪽에서는 하이일드가 0.06%, "
    "투자등급이 0.13% 올라 큰 흔들림 없이 마감했습니다."
)
R_COMMOD = (
    "달러지수는 0.12% 내렸고 달러엔은 0.21% 하락했습니다. 유가는 서부텍사스산이 1.44%, 브렌트가 1.31% 올라 "
    "원자재 쪽이 상대적으로 앞선 흐름이었습니다."
)
R_SEMI = (
    "반도체는 기술주 대비 0.43%p 앞섰고 경기소비재는 필수소비재 대비 0.49%p 앞섰습니다. 위험을 지는 쪽이 "
    "조금 더 선택받은 구성이었다는 뜻입니다."
)

READY_VALID = copy.deepcopy(BASELINE_VALID)
READY_VALID["as_of"] = "2026-07-20"
READY_VALID["sections"] = [
    {"id": "conclusion", "title": "오늘의 결론", "body": B_CONCLUSION,
     "tickers": [], "themes": []},
    {"id": "breadth", "title": "시장 체력과 스타일", "body": B_BREADTH,
     "tickers": [], "themes": []},
    {"id": "size_style", "title": "대형주와 소형주", "body": R_SIZE,
     "tickers": [], "themes": []},
    {"id": "rates_vol", "title": "금리와 변동성", "body": R_RATES,
     "tickers": [], "themes": []},
    {"id": "commodities", "title": "달러와 원자재", "body": R_COMMOD,
     "tickers": [], "themes": []},
    {"id": "semis_sectors", "title": "반도체와 섹터", "body": R_SEMI,
     "tickers": [], "themes": []},
    {"id": "rotation", "title": "시장의 선택이 옮겨간 곳", "body": B_ROTATION,
     "tickers": [],
     "themes": ["금융", "헬스혁신", "운송", "사이버보안", "필수소비", "게임"]},
    {"id": "value_chain_radar", "title": "산업 안의 강약과 종목 레이더", "body": B_RADAR,
     "tickers": ["OKTA", "META", "NVDA", "MRVL"],
     "themes": ["반도체", "반도체장비", "AI인프라", "에너지"]},
]
READY_VALID["sections"].append(
    {"id": "next_session", "title": "다음 거래일 확인 조건",
     "body": ("다음 장에서는 대형주 우위가 이어지는지, 변동성 지표의 상승이 되돌려지는지를 함께 "
              "확인할 수 있습니다. 반도체가 기술주 대비 우위를 유지하는지도 관찰 지점입니다."),
     "tickers": [], "themes": ["반도체"]})
# ready 는 8개 상한 — conclusion 포함 9개가 되므로 breadth 를 제외해 8개로 맞춘다
READY_VALID["sections"] = [s for s in READY_VALID["sections"] if s["id"] != "breadth"]


# ---------------------------------------------------------------- mutations
def mut(base, fn):
    o = copy.deepcopy(base)
    fn(o)
    return o


def m_wrong_as_of(o):
    o["as_of"] = "2026-07-16"


def m_dup_id(o):
    o["sections"][1]["id"] = "conclusion"


def m_forbidden(o):
    o["sections"][0]["body"] = o["sections"][0]["body"] + " 상승 흐름에 진입했습니다."


def m_internal(o):
    o["sections"][2]["body"] = o["sections"][2]["body"] + " lifecycle 분류 기준입니다."


def m_unknown_ticker(o):
    for s in o["sections"]:
        if s["id"] == "value_chain_radar":
            s["tickers"].append("TSLA")


def m_body_mismatch(o):
    for s in o["sections"]:
        if s["id"] == "value_chain_radar":
            s["tickers"] = ["OKTA", "META", "NVDA"]   # MRVL 은 body 에 있는데 누락


def m_unknown_theme(o):
    for s in o["sections"]:
        if s["id"] == "rotation":
            s["themes"] = s["themes"] + ["우주항공"]


def m_wrong_disclaimer(o):
    o["disclaimer"] = "이 글은 참고 자료입니다."


def m_social_new_claim(o):
    o["social_summary"] = ("미국장은 지수보다 내부의 갈림이 컸던 하루였습니다. "
                           "TSLA가 시장을 이끌었고 상승 종목 비율은 82%에 달했습니다.")


def m_money_metaphor(o):
    o["sections"][0]["body"] = o["sections"][0]["body"].replace(
        "시장의 선택이 전체로 넓게 퍼지기보다", "돈이 전체로 퍼지기보다")


FIXTURES = {
    "baseline_valid": BASELINE_VALID,
    "ready_valid": READY_VALID,
    "wrong_as_of": mut(BASELINE_VALID, m_wrong_as_of),
    "duplicate_section_id": mut(BASELINE_VALID, m_dup_id),
    "forbidden_word": mut(BASELINE_VALID, m_forbidden),
    "internal_name": mut(BASELINE_VALID, m_internal),
    "unknown_ticker": mut(BASELINE_VALID, m_unknown_ticker),
    "body_ticker_mismatch": mut(BASELINE_VALID, m_body_mismatch),
    "unknown_theme": mut(BASELINE_VALID, m_unknown_theme),
    "wrong_disclaimer": mut(BASELINE_VALID, m_wrong_disclaimer),
    "social_summary_new_claim": mut(BASELINE_VALID, m_social_new_claim),
    "money_metaphor": mut(BASELINE_VALID, m_money_metaphor),
}


def m_tickers_over_4(o):
    for s in o["sections"]:
        if s["id"] == "value_chain_radar":
            s["tickers"] = ["OKTA", "META", "NVDA", "MRVL", "MSFT"]


def m_themes_over_6(o):
    for s in o["sections"]:
        if s["id"] == "rotation":
            s["themes"] = s["themes"] + ["부동산"]


def m_dup_ticker(o):
    for s in o["sections"]:
        if s["id"] == "value_chain_radar":
            s["tickers"] = ["OKTA", "META", "NVDA", "NVDA"]


def m_dup_theme(o):
    for s in o["sections"]:
        if s["id"] == "rotation":
            s["themes"] = ["금융", "금융", "운송"]


def m_theme_not_exact(o):
    for s in o["sections"]:
        if s["id"] == "rotation":
            s["themes"] = ["금 융", "운송"]


def m_social_unit(o):
    o["social_summary"] = ("미국장은 지수보다 내부의 갈림이 컸던 하루였습니다. "
                           "주요 시장에서 200일선 위 종목 비율은 69%p로 집계됐고 "
                           "7일 강세축은 필수소비와 금융으로 옮겨갔습니다.")


def m_key_point_unit(o):
    o["key_points"] = list(o["key_points"])
    o["key_points"][0] = "뉴욕증권거래소 신고가 종목은 148%로 집계돼 시장 체력은 유지됐습니다."


def m_email_preview_unit(o):
    o["email_preview"] = "반도체 안에서 상대강도 격차가 13.8%까지 벌어졌습니다."


FIXTURES.update({
    "section_tickers_over_4": mut(BASELINE_VALID, m_tickers_over_4),
    "section_themes_over_6": mut(BASELINE_VALID, m_themes_over_6),
    "duplicate_ticker_metadata": mut(BASELINE_VALID, m_dup_ticker),
    "duplicate_theme_metadata": mut(BASELINE_VALID, m_dup_theme),
    "theme_not_exact": mut(BASELINE_VALID, m_theme_not_exact),
    "social_summary_unit_mismatch": mut(BASELINE_VALID, m_social_unit),
    "key_point_unit_mismatch": mut(BASELINE_VALID, m_key_point_unit),
    "email_preview_unit_mismatch": mut(BASELINE_VALID, m_email_preview_unit),
})


def m_missing_rotation(o):
    o["sections"] = [s for s in o["sections"] if s["id"] != "rotation"]
    o["key_points"] = ["뉴욕증권거래소 신고가 종목이 신저가보다 많았습니다.",
                       "상승 거래량이 하락 거래량을 앞섰습니다.",
                       "같은 반도체 안에서도 종목별 상대강도 격차가 벌어졌습니다."]
    o["social_summary"] = ("미국장은 지수보다 내부의 갈림이 컸던 하루였습니다. "
                           "신고가 종목과 상승 거래량은 앞섰지만 같은 업종 안에서도 "
                           "종목별 결과가 크게 갈렸습니다.")


def m_missing_radar(o):
    o["sections"] = [s for s in o["sections"] if s["id"] != "value_chain_radar"]
    o["key_points"] = ["뉴욕증권거래소 신고가 종목이 신저가보다 많았습니다.",
                       "상승 거래량이 하락 거래량을 앞섰습니다.",
                       "7일 강세축은 필수소비와 금융이지만 90일 주도축은 남아 있습니다."]
    o["social_summary"] = ("미국장은 지수보다 내부의 갈림이 컸던 하루였습니다. "
                           "7일 강세축은 필수소비와 금융으로 옮겨갔고 시장 폭은 "
                           "유지된 모습이었습니다.")


def m_watchpoint_new_number(o):
    o["watchpoints"] = list(o["watchpoints"])
    o["watchpoints"][0] = "금융과 운송의 상위 흐름이 3거래일 이어지는지 확인할 지점입니다."


FIXTURES.update({
    "missing_rotation_section": mut(BASELINE_VALID, m_missing_rotation),
    "missing_value_chain_radar": mut(BASELINE_VALID, m_missing_radar),
    "watchpoint_new_number": mut(BASELINE_VALID, m_watchpoint_new_number),
})


def main():
    json.dump(CONTEXT_BASE, open(os.path.join(FX, "context_baseline.json"), "w",
              encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(CONTEXT_READY, open(os.path.join(FX, "context_ready.json"), "w",
              encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(COMPARISON_BASELINE, open(os.path.join(FX, "comparison_baseline.json"),
              "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(COMPARISON_READY, open(os.path.join(FX, "comparison_ready.json"),
              "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    for name, obj in FIXTURES.items():
        p = os.path.join(FX, name + ".json")
        json.dump(obj, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print("wrote", p)

    # malformed_json 는 JSON 이 아니어야 하므로 별도 기록
    p = os.path.join(FX, "malformed_json.txt")
    open(p, "w", encoding="utf-8").write(
        '여기 브리핑입니다.\n{"schema_version": "us_macro_brief_v1", "as_of": ')
    print("wrote", p)
    print("FIXTURES: %d + malformed" % len(FIXTURES))


if __name__ == "__main__":
    main()
