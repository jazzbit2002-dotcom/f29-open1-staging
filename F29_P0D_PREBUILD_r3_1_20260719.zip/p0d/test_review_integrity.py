#!/usr/bin/env python3
# F29 P0-D / D-4 통합 테스트 — brief.json 정본 무결성 (감리 재판정 L1-1)
# 회귀 항목 28~31, 33.
# 실행: python3 test_review_integrity.py

import json, os, sys, shutil, hashlib, tempfile, subprocess, unittest

HERE = os.path.dirname(os.path.abspath(__file__))
FX = os.path.join(HERE, "fixtures")
REVIEW = os.path.join(HERE, "build_review_v2.py")


def load(name):
    with open(os.path.join(FX, name + ".json"), encoding="utf-8") as f:
        return json.load(f)


class Stage(object):
    """임시 briefing_delivery 트리에 run 을 구성한다."""

    def __init__(self):
        self.root = tempfile.mkdtemp(prefix="f29rev-")
        self.base = os.path.join(self.root, "briefing_delivery")
        self.ev = os.path.join(self.base, "evidence")
        os.makedirs(self.ev)

    def close(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def add(self, rid, brief, ctx, cmpj, status, as_of,
            write_brief=True, tamper_brief=None, bad_sha=False,
            ev_status="brief_saved", cmp_file_status=None):
        d = os.path.join(self.ev, rid)
        os.makedirs(d)
        text = json.dumps(brief, ensure_ascii=False, indent=1)
        with open(os.path.join(d, "response.txt"), "w", encoding="utf-8") as f:
            f.write(text)
        with open(os.path.join(d, "briefing_context_raw.json"), "w",
                  encoding="utf-8") as f:
            json.dump(ctx, f, ensure_ascii=False)
        cj = json.loads(json.dumps(cmpj))
        if cmp_file_status:
            cj["market_close_comparison"]["status"] = cmp_file_status
        with open(os.path.join(d, "comparison.json"), "w", encoding="utf-8") as f:
            json.dump(cj, f, ensure_ascii=False)

        brief_sha = None
        if write_brief:
            on_disk = tamper_brief if tamper_brief is not None else brief
            bb = json.dumps(on_disk, ensure_ascii=False, indent=1).encode("utf-8")
            with open(os.path.join(d, "brief.json"), "wb") as f:
                f.write(bb)
            brief_sha = hashlib.sha256(bb).hexdigest()
            if tamper_brief is not None and not bad_sha:
                # 변조본을 정직하게 재해시한 경우 — 원시 응답 대조에서 걸려야 한다
                pass
            if bad_sha:
                brief_sha = "0" * 64

        e = {"run_id": rid, "model": "claude-opus-4-8", "stop_reason": "end_turn",
             "close_snapshot_state": "fresh", "daily_state": "fresh",
             "comparison_status": status, "current_as_of": as_of,
             "previous_as_of": None, "cost_usd": 0.12,
             "input_tokens": 15000, "output_tokens": 2000,
             "cache_read_input_tokens": 0, "cache_creation_input_tokens": 0,
             "snapshot_store_status": "noop", "status": ev_status,
             "output_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()}
        if brief_sha:
            e["brief_sha256"] = brief_sha
        with open(os.path.join(d, "evidence.json"), "w", encoding="utf-8") as f:
            json.dump(e, f, ensure_ascii=False)
        return d

    def run(self):
        env = dict(os.environ, F29_BRIEF_BASE=self.base)
        p = subprocess.run([sys.executable, REVIEW], env=env,
                           capture_output=True, text=True)
        assert p.returncode == 0, p.stderr[-800:]
        elig = {}
        latest = None
        for line in p.stdout.splitlines():
            if "latest자격:" in line:
                rid = line.split("evidence/")[1].split("/")[0]
                elig[rid] = line.strip().endswith("O")
            if line.startswith("latest.html") and "(run " in line:
                latest = line.split("(run ")[1].rstrip(")").strip()
        return elig, latest, p.stdout


CTX_B = load("context_baseline")
CMP_B = load("comparison_baseline")
VALID = load("baseline_valid")


class TestCanonicalIntegrity(unittest.TestCase):

    def setUp(self):
        self.s = Stage()

    def tearDown(self):
        self.s.close()

    def test_valid_run_is_eligible(self):
        self.s.add("20260721T000001Z-aaaa", VALID, CTX_B, CMP_B,
                   "baseline_only", "2026-07-17")
        elig, latest, _ = self.s.run()
        self.assertTrue(elig["20260721T000001Z-aaaa"])
        self.assertEqual(latest, "20260721T000001Z-aaaa")

    def test_28_brief_json_missing_is_ineligible(self):
        self.s.add("20260721T000002Z-bbbb", VALID, CTX_B, CMP_B,
                   "baseline_only", "2026-07-17", write_brief=False)
        elig, latest, out = self.s.run()
        self.assertFalse(elig["20260721T000002Z-bbbb"])
        self.assertIsNone(latest)

    def test_29_brief_json_sha_mismatch_is_ineligible(self):
        self.s.add("20260721T000003Z-cccc", VALID, CTX_B, CMP_B,
                   "baseline_only", "2026-07-17", bad_sha=True)
        elig, latest, _ = self.s.run()
        self.assertFalse(elig["20260721T000003Z-cccc"])
        self.assertIsNone(latest)

    def test_30_brief_response_object_mismatch_is_ineligible(self):
        tampered = json.loads(json.dumps(VALID))
        tampered["headline"] = "조용히 바꿔치기된 제목입니다 확인용"
        self.s.add("20260721T000004Z-dddd", VALID, CTX_B, CMP_B,
                   "baseline_only", "2026-07-17", tamper_brief=tampered)
        elig, latest, out = self.s.run()
        self.assertFalse(elig["20260721T000004Z-dddd"])
        self.assertIsNone(latest)

    def test_31_evidence_status_not_brief_saved_is_ineligible(self):
        self.s.add("20260721T000005Z-eeee", VALID, CTX_B, CMP_B,
                   "baseline_only", "2026-07-17", ev_status="draft_saved")
        elig, latest, _ = self.s.run()
        self.assertFalse(elig["20260721T000005Z-eeee"])
        self.assertIsNone(latest)

    def test_33_comparison_status_file_mismatch_is_ineligible(self):
        self.s.add("20260721T000006Z-ffff", VALID, CTX_B, CMP_B,
                   "baseline_only", "2026-07-17", cmp_file_status="ready")
        elig, latest, _ = self.s.run()
        self.assertFalse(elig["20260721T000006Z-ffff"])
        self.assertIsNone(latest)

    def test_tampered_run_never_wins_latest_over_valid(self):
        """감리 재현 시나리오: 변조 run 이 최신이어도 정상 run 이 latest 가 되어야 한다."""
        self.s.add("20260721T000010Z-good", VALID, CTX_B, CMP_B,
                   "baseline_only", "2026-07-17")
        tampered = json.loads(json.dumps(VALID))
        tampered["headline"] = "변조된 제목이 최신 run 으로 들어온 경우"
        self.s.add("20260721T000099Z-evil", VALID, CTX_B, CMP_B,
                   "baseline_only", "2026-07-17", tamper_brief=tampered)
        elig, latest, _ = self.s.run()
        self.assertTrue(elig["20260721T000010Z-good"])
        self.assertFalse(elig["20260721T000099Z-evil"])
        self.assertEqual(latest, "20260721T000010Z-good")


if __name__ == "__main__":
    unittest.main(verbosity=2)
