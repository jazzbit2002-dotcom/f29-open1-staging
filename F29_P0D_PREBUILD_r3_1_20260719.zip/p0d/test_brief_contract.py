#!/usr/bin/env python3
# F29 P0-D / D-3 — brief_contract 단위 테스트
# 실행: python3 test_brief_contract.py     (의존성 없음, unittest 표준 모듈)

import json, os, sys, unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
FX = os.path.join(HERE, "fixtures")

from brief_contract import (validate_brief, validate_raw, parse_model_output,
                            build_allowlists, ContractError)


def load(name):
    with open(os.path.join(FX, name + ".json"), encoding="utf-8") as f:
        return json.load(f)


CTX_B = load("context_baseline")
CTX_R = load("context_ready")


class TestValid(unittest.TestCase):

    def test_baseline_valid_passes(self):
        m = validate_brief(load("baseline_valid"), CTX_B, "baseline_only")
        self.assertTrue(1000 <= m["prose_chars"] <= 1600, m["prose_chars"])
        self.assertIn("conclusion", m["section_ids"])
        self.assertIn("next_session", m["section_ids"])

    def test_ready_valid_passes(self):
        m = validate_brief(load("ready_valid"), CTX_R, "ready")
        self.assertTrue(1500 <= m["prose_chars"] <= 2500, m["prose_chars"])
        self.assertLessEqual(len(m["section_ids"]), 8)

    def test_allowlists_derived_from_context_not_hardcoded(self):
        t, th, n2t = build_allowlists(CTX_B)
        self.assertIn("MRVL", t)
        self.assertIn("OKTA", t)
        self.assertNotIn("TSLA", t)
        self.assertIn("반도체", th)
        self.assertEqual(n2t.get("마벨"), "MRVL")

    def test_fence_tolerated(self):
        raw = "```json\n" + json.dumps(load("baseline_valid"), ensure_ascii=False) + "\n```"
        brief, m = validate_raw(raw, CTX_B, "baseline_only")
        self.assertEqual(brief["schema_version"], "us_macro_brief_v1")
        self.assertGreater(m["prose_chars"], 0)


class TestFailClosed(unittest.TestCase):
    """모든 위반은 ContractError 를 던져야 한다. 경고로 통과시키지 않는다."""

    def _expect(self, fixture, needle, ctx=CTX_B, status="baseline_only"):
        with self.assertRaises(ContractError) as cm:
            validate_brief(load(fixture), ctx, status)
        joined = " ".join(cm.exception.violations)
        self.assertIn(needle, joined,
                      "fixture=%s violations=%s" % (fixture, joined))

    def test_malformed_json(self):
        with open(os.path.join(FX, "malformed_json.txt"), encoding="utf-8") as f:
            raw = f.read()
        with self.assertRaises(ContractError) as cm:
            parse_model_output(raw)
        self.assertIn("JSON parse failed", " ".join(cm.exception.violations))

    def test_wrong_as_of(self):
        self._expect("wrong_as_of", "as_of 2026-07-16")

    def test_duplicate_section_id(self):
        self._expect("duplicate_section_id", "duplicate section id")

    def test_forbidden_word(self):
        self._expect("forbidden_word", "forbidden word")

    def test_internal_name(self):
        self._expect("internal_name", "internal name")

    def test_unknown_ticker(self):
        self._expect("unknown_ticker", "not in context allowlist")

    def test_body_ticker_mismatch(self):
        self._expect("body_ticker_mismatch", "not in tickers")

    def test_unknown_theme(self):
        self._expect("unknown_theme", "themes")

    def test_wrong_disclaimer(self):
        self._expect("wrong_disclaimer", "disclaimer does not match")

    def test_social_summary_new_claim(self):
        self._expect("social_summary_new_claim", "introduces")

    def test_money_metaphor(self):
        self._expect("money_metaphor", "money-flow metaphor")

    def test_baseline_forbids_comparison_sections(self):
        b = load("baseline_valid")
        b["sections"][1] = {"id": "rates_vol", "title": "금리와 변동성",
                            "body": b["sections"][1]["body"],
                            "tickers": [], "themes": []}
        with self.assertRaises(ContractError) as cm:
            validate_brief(b, CTX_B, "baseline_only")
        self.assertIn("forbidden when comparison is baseline_only",
                      " ".join(cm.exception.violations))

    def test_key_points_must_be_three(self):
        b = load("baseline_valid")
        b["key_points"] = b["key_points"][:2]
        with self.assertRaises(ContractError) as cm:
            validate_brief(b, CTX_B, "baseline_only")
        self.assertIn("key_points must be exactly 3",
                      " ".join(cm.exception.violations))

    def test_extra_top_level_field_rejected(self):
        b = load("baseline_valid")
        b["og_image"] = "https://example.com/a.png"
        with self.assertRaises(ContractError) as cm:
            validate_brief(b, CTX_B, "baseline_only")
        self.assertIn("unexpected top-level field",
                      " ".join(cm.exception.violations))

    def test_empty_string_rejected(self):
        b = load("baseline_valid")
        b["sections"][0]["body"] = "   "
        with self.assertRaises(ContractError) as cm:
            validate_brief(b, CTX_B, "baseline_only")
        self.assertIn("empty or not string", " ".join(cm.exception.violations))

    def test_empty_response_rejected(self):
        with self.assertRaises(ContractError):
            parse_model_output("")

    def test_non_object_root_rejected(self):
        with self.assertRaises(ContractError) as cm:
            parse_model_output("[1,2,3]")
        self.assertIn("expected object", " ".join(cm.exception.violations))


class TestAuditFixes(unittest.TestCase):
    """감리 재판정 L1-2 / L1-3 보정 회귀 (22~27, 32)."""

    def _expect(self, fixture, needle):
        with self.assertRaises(ContractError) as cm:
            validate_brief(load(fixture), CTX_B, "baseline_only")
        joined = " ".join(cm.exception.violations)
        self.assertIn(needle, joined, "%s -> %s" % (fixture, joined))

    def test_22_comparison_status_unknown(self):
        for bad in ("unknown", "", None, "READY"):
            with self.assertRaises(ContractError) as cm:
                validate_brief(load("baseline_valid"), CTX_B, bad)
            self.assertIn("comparison_status invalid",
                          " ".join(cm.exception.violations))

    def test_23_section_tickers_over_4(self):
        self._expect("section_tickers_over_4", "exceeds max 4")

    def test_24_section_themes_over_6(self):
        self._expect("section_themes_over_6", "exceeds max 6")

    def test_25_duplicate_ticker_metadata(self):
        self._expect("duplicate_ticker_metadata", "tickers contains duplicates")

    def test_26_duplicate_theme_metadata(self):
        self._expect("duplicate_theme_metadata", "themes contains duplicates")

    def test_27_theme_not_exact(self):
        self._expect("theme_not_exact", "not an exact source theme")

    def test_32a_social_summary_unit_mismatch(self):
        self._expect("social_summary_unit_mismatch", "69%p")

    def test_32b_key_point_unit_mismatch(self):
        self._expect("key_point_unit_mismatch", "148%")

    def test_32c_email_preview_unit_mismatch(self):
        self._expect("email_preview_unit_mismatch", "13.8%")

    def test_unit_tokenizer(self):
        from brief_contract import number_tokens, numbers_absent_from
        src = number_tokens("10년물 금리는 1bp 내렸고 비율은 69%였습니다")
        self.assertIn(("1", "bp"), src)
        self.assertIn(("69", "%"), src)
        self.assertEqual(numbers_absent_from(src, "1bp 내렸습니다"), [])
        self.assertEqual(numbers_absent_from(src, "시장은 1% 움직였습니다"), ["1%"])
        self.assertEqual(numbers_absent_from(src, "69%p 였습니다"), ["69%p"])



class TestV7Contract(unittest.TestCase):
    """v7 프롬프트 재감리 L1-2 / L1-3 대응 — 검증기 구현 회귀 (34·35·38)."""

    def _expect(self, fixture, needle, ctx=CTX_B, status="baseline_only"):
        with self.assertRaises(ContractError) as cm:
            validate_brief(load(fixture), ctx, status)
        joined = " ".join(cm.exception.violations)
        self.assertIn(needle, joined, "%s -> %s" % (fixture, joined))

    def test_34_rotation_required_when_digest_usable(self):
        self._expect("missing_rotation_section", "required section id(s) missing: rotation")

    def test_35_value_chain_radar_required_when_digest_usable(self):
        self._expect("missing_value_chain_radar",
                     "required section id(s) missing: value_chain_radar")

    def test_38_watchpoint_new_number(self):
        self._expect("watchpoint_new_number", "absent from next_session body")

    def test_digest_absent_relaxes_requirement(self):
        """digest 가 없으면 rotation·value_chain_radar 는 필수가 아니다."""
        import copy
        ctx = copy.deepcopy(CTX_B)
        ctx.pop("moneyflow_digest", None)
        b = load("missing_rotation_section")
        with self.assertRaises(ContractError) as cm:
            validate_brief(b, ctx, "baseline_only")
        self.assertNotIn("required section id(s) missing: rotation",
                         " ".join(cm.exception.violations))

    def test_theme_exact_rejects_outer_space(self):
        b = load("baseline_valid")
        for s in b["sections"]:
            if s["id"] == "rotation":
                s["themes"] = [" 금융 "] + s["themes"][1:]
        with self.assertRaises(ContractError) as cm:
            validate_brief(b, CTX_B, "baseline_only")
        self.assertIn("not an exact source theme", " ".join(cm.exception.violations))



if __name__ == "__main__":
    unittest.main(verbosity=2)
