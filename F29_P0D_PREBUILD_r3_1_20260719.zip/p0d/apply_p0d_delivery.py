#!/usr/bin/env python3
# F29 P0-D / D-3 wiring patch for us_macro_delivery.py
# PREBUILD ARTIFACT - NOT EXECUTED IN PREBUILD PHASE.
# Run only in P0-D FINALIZE, after bridge run fixture is folded in.
#
# Contract: literal anchor + str.replace only, no whole-file rewrite,
#           anchor count gate, duplicate-apply guard, automatic backup,
#           py_compile check, atomic write, rollback command printed.
# Pure ASCII by design (CJK never goes through mobile SSH paste).

import os
import sys
import shutil
import hashlib
import py_compile
import tempfile
from datetime import datetime, timezone

TARGET = "/root/moneyflow/us_macro_delivery.py"
BACKUP_ROOT = "/root/f29-backups"
MARKER = "F29-P0D-D3 v1"

ANCHOR_IMPORT = (
    "import json, os, re, sys, time, uuid, hashlib, subprocess, "
    "urllib.request, urllib.error\n"
)
INSERT_IMPORT = (
    ANCHOR_IMPORT
    + "sys.path.insert(0, \"/root/moneyflow\")\n"
    + "from brief_contract import validate_raw, ContractError  # " + MARKER + "\n"
)

ANCHOR_TAIL = 'print("DELIVERY: DONE")\n'
INSERT_TAIL = (
    "# ---------- 9. structured contract (P0-D / D-3) fail-closed ---------- "
    + MARKER + "\n"
    "cmp_status = comparison[\"market_close_comparison\"][\"status\"]\n"
    "\n"
    "def _write_evidence():\n"
    "    _t = os.path.join(outdir, \"evidence.json.tmp\")\n"
    "    with open(_t, \"w\", encoding=\"utf-8\") as _f:\n"
    "        json.dump(evidence, _f, ensure_ascii=False, indent=2)\n"
    "        _f.flush()\n"
    "        os.fsync(_f.fileno())\n"
    "    os.replace(_t, os.path.join(outdir, \"evidence.json\"))\n"
    "\n"
    "try:\n"
    "    brief, metrics = validate_raw(text, d, cmp_status)\n"
    "except ContractError as ce:\n"
    "    with open(os.path.join(outdir, \"violations.json\"), \"w\", encoding=\"utf-8\") as _f:\n"
    "        json.dump({\"violations\": ce.violations, \"comparison_status\": cmp_status},\n"
    "                  _f, ensure_ascii=False, indent=2)\n"
    "    evidence[\"status\"] = \"contract_failed\"\n"
    "    evidence[\"violation_count\"] = len(ce.violations)\n"
    "    _write_evidence()\n"
    "    print(\"CONTRACT: FAIL (%d violations)\" % len(ce.violations))\n"
    "    for _x in ce.violations[:20]:\n"
    "        print(\"  -\", _x)\n"
    "    print(\"raw response preserved as failure evidence:\", outdir)\n"
    "    print(\"HOLD: brief.json NOT written. latest NOT updated. no publish.\")\n"
    "    sys.exit(3)\n"
    "\n"
    "# canonical brief.json: atomic write, then hash the bytes actually on disk\n"
    "_bp = os.path.join(outdir, \"brief.json\")\n"
    "_bt = _bp + \".tmp\"\n"
    "_bb = json.dumps(brief, ensure_ascii=False, indent=1).encode(\"utf-8\")\n"
    "with open(_bt, \"wb\") as _f:\n"
    "    _f.write(_bb)\n"
    "    _f.flush()\n"
    "    os.fsync(_f.fileno())\n"
    "os.replace(_bt, _bp)\n"
    "_brief_sha = sha_bytes(open(_bp, \"rb\").read())\n"
    "if _brief_sha != sha_bytes(_bb):\n"
    "    evidence[\"status\"] = \"brief_write_mismatch\"\n"
    "    _write_evidence()\n"
    "    print(\"CONTRACT: FAIL (brief.json bytes differ after write)\")\n"
    "    sys.exit(4)\n"
    "evidence[\"status\"] = \"brief_saved\"\n"
    "evidence[\"brief_sha256\"] = _brief_sha\n"
    "evidence[\"schema_version\"] = brief.get(\"schema_version\")\n"
    "evidence[\"prose_chars\"] = metrics[\"prose_chars\"]\n"
    "evidence[\"section_ids\"] = metrics[\"section_ids\"]\n"
    "evidence[\"distinct_tickers\"] = metrics[\"distinct_tickers\"]\n"
    "_write_evidence()\n"
    "print(\"CONTRACT: PASS | %d chars | sections %s\"\n"
    "      % (metrics[\"prose_chars\"], \",\".join(metrics[\"section_ids\"])))\n"
    "print(\"brief_sha256      :\", _brief_sha)\n"
    + ANCHOR_TAIL
)


def sha256_file(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def die(msg):
    print("ABORT: " + msg)
    sys.exit(1)


def main():
    target = sys.argv[1] if len(sys.argv) > 1 else TARGET
    if not os.path.isfile(target):
        die("target not found: %s" % target)

    src = open(target, encoding="utf-8").read()
    pre_sha = sha256_file(target)

    if MARKER in src:
        print("already applied (marker present): " + MARKER)
        print("pre_sha256: " + pre_sha)
        return 0

    if not os.path.isfile(os.path.join(os.path.dirname(target), "brief_contract.py")):
        die("brief_contract.py missing next to target - deploy it first")

    for name, anchor in (("import", ANCHOR_IMPORT), ("tail", ANCHOR_TAIL)):
        n = src.count(anchor)
        print("anchor gate: %-6s count==%d" % (name, n))
        if n != 1:
            die("anchor %s count %d != 1" % (name, n))

    out = src.replace(ANCHOR_IMPORT, INSERT_IMPORT)
    out = out.replace(ANCHOR_TAIL, INSERT_TAIL)

    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    bdir = os.path.join(BACKUP_ROOT, "p0d-d3-" + ts)
    os.makedirs(bdir, exist_ok=True)
    shutil.copy2(target, os.path.join(bdir, os.path.basename(target)))
    print("backup: " + os.path.join(bdir, os.path.basename(target)))
    print("pre_sha256: " + pre_sha)

    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(target), suffix=".tmp")
    os.close(fd)
    open(tmp, "w", encoding="utf-8").write(out)
    try:
        py_compile.compile(tmp, doraise=True)
        print("py_compile: PASS")
    except Exception as e:
        os.unlink(tmp)
        die("py_compile failed: %s" % str(e)[:200])

    os.chmod(tmp, os.stat(target).st_mode & 0o7777)
    os.replace(tmp, target)

    post_sha = sha256_file(target)
    print("applied. post_sha256: " + post_sha)
    print("post size: %d bytes" % os.path.getsize(target))
    print("marker count: %d" % open(target, encoding="utf-8").read().count(MARKER))
    print("ROLLBACK: cp %s %s"
          % (os.path.join(bdir, os.path.basename(target)), target))
    print("NEXT: switch PROMPT_FILE to macro_prompt_v7.txt, then run a FINALIZE draft.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
