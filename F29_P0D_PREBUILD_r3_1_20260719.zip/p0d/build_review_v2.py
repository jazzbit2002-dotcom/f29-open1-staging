#!/usr/bin/env python3
# F29 LOCAL REVIEW VIEWER v2 — P0-D / D-4 (2026-07-19 PREBUILD)
# us_macro_brief_v1 구조화 출력 기준 검수. legacy 산문 run(v6 이전)은 축약 렌더로 병행 지원.
#
# Reads  : evidence/<run_id>/{evidence.json, brief.json | response.txt,
#                             briefing_context_raw.json, comparison.json}
# Writes : evidence/<run_id>/review.html + review/runs/<run_id>.html
#          + review/index.html + review/latest.html
# Constraints: single-file HTML, no external CSS/JS/CDN, full escaping,
#              never modifies canonical files, no public web root, no nginx, no cron.
#
# latest 자격 = 데이터 상태 + 차단 검사(bad) 0건. 경고(warn)는 자격을 막지 않는다.

import os, re, json, html, sys, hashlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from brief_contract import (parse_model_output, validate_brief, build_allowlists,
                            ContractError, SCHEMA_VERSION)

BASE = os.environ.get("F29_BRIEF_BASE", "/root/moneyflow/briefing_delivery")
EVIDIR = os.path.join(BASE, "evidence")
REVDIR = os.path.join(BASE, "review")

NUM_RE = re.compile(r"\d+(?:\.\d+)?")

CSS = """
:root{--bg:#0A0E17;--card:#131A28;--line:#1F2A3D;--txt:#E8EDF7;--txt2:#8B9AB5;
--txt3:#5A6B84;--teal:#3DD8B0;--gold:#f0c674;--red:#F0997B}
*{margin:0;padding:0;box-sizing:border-box}
body{background:var(--bg);color:var(--txt);line-height:1.6;
font-family:-apple-system,'Apple SD Gothic Neo','Malgun Gothic',sans-serif;
-webkit-font-smoothing:antialiased}
.wrap{max-width:860px;margin:0 auto;padding:20px}
h1{font-size:18px;color:var(--teal);margin-bottom:4px}
.sub{font-size:12px;color:var(--txt3);margin-bottom:18px}
.card{background:var(--card);border-radius:10px;padding:14px 16px;margin-bottom:16px}
.card h2{font-size:12px;color:var(--txt3);text-transform:uppercase;letter-spacing:.08em;
padding-bottom:8px;border-bottom:.5px solid var(--line);margin-bottom:10px}
table{width:100%;border-collapse:collapse;font-size:12.5px}
td{padding:5px 0;border-bottom:.5px solid var(--line);vertical-align:top}
td:first-child{color:var(--txt2);width:40%}
td.mono,.mono{font-family:ui-monospace,Menlo,monospace;font-size:11px;word-break:break-all}
.chk{font-size:13px;padding:6px 0;border-bottom:.5px solid var(--line)}
.chk:last-child{border-bottom:none}
.ok{color:var(--teal)}.warn{color:var(--gold)}.bad{color:var(--red)}
.hl{font-size:19px;line-height:1.45;margin-bottom:6px}
.deck{font-size:14px;color:var(--txt2);line-height:1.7}
.kp{font-size:13.5px;padding:5px 0 5px 14px;position:relative}
.kp:before{content:"";position:absolute;left:0;top:13px;width:5px;height:5px;
border-radius:50%;background:var(--teal)}
.sec{padding:12px 0;border-bottom:.5px solid var(--line)}
.sec:last-child{border-bottom:none}
.sid{font-size:10.5px;color:var(--txt3);font-family:ui-monospace,Menlo,monospace}
.stitle{font-size:15px;color:var(--teal);margin:2px 0 6px}
.sbody{font-size:14px;line-height:1.8;white-space:pre-wrap}
.meta{margin-top:7px;font-size:11px;color:var(--txt3)}
.pill{display:inline-block;padding:1px 7px;border:.5px solid var(--line);
border-radius:9px;margin-right:5px;font-family:ui-monospace,Menlo,monospace}
.body{white-space:pre-wrap;font-size:14.5px;line-height:1.85}
pre.raw{font-family:ui-monospace,Menlo,monospace;font-size:10.5px;line-height:1.5;
white-space:pre-wrap;word-break:break-all;color:var(--txt2);max-height:340px;overflow:auto}
a{color:var(--teal);text-decoration:none}
.idx td{font-size:12.5px}
.note{font-size:11px;color:var(--txt3);margin-top:14px;line-height:1.7}
"""


def esc(s):
    return html.escape("" if s is None else str(s), quote=True)


# ---------------------------------------------------------------- checks

def integrity_checks(ev, rd):
    out = []
    if not rd:
        return out
    for fn, key in (("response.txt", "output_sha256"), ("prompt.txt", "prompt_sha256")):
        fp = os.path.join(rd, fn)
        rec = ev.get(key)
        if os.path.isfile(fp) and rec:
            actual = hashlib.sha256(open(fp, "rb").read()).hexdigest()
            same = (actual == rec)
            out.append(("%s SHA 대조" % fn, "일치" if same else "불일치(변조 의심)",
                        "ok" if same else "bad"))
    return out


def number_conflict(brief):
    """headline/deck/key_points/social/email 에 등장한 숫자가 본문(sections/watchpoints)에
    존재하지 않으면 충돌로 본다. 요약이 본문과 다른 수치를 말하는 것을 막는다."""
    body_corpus = []
    for s in brief.get("sections") or []:
        if isinstance(s, dict) and isinstance(s.get("body"), str):
            body_corpus.append(s["body"])
    for s in brief.get("watchpoints") or []:
        if isinstance(s, str):
            body_corpus.append(s)
    joined = " ".join(body_corpus)

    bad = []
    for field in ("headline", "deck", "social_summary", "email_subject", "email_preview"):
        s = brief.get(field)
        if isinstance(s, str):
            for n in set(NUM_RE.findall(s)):
                if n not in joined:
                    bad.append("%s:%s" % (field, n))
    for i, s in enumerate(brief.get("key_points") or []):
        if isinstance(s, str):
            for n in set(NUM_RE.findall(s)):
                if n not in joined:
                    bad.append("key_points[%d]:%s" % (i, n))
    return bad


def run_checks_structured(brief, ev, raw, rd, violations):
    """violations = brief_contract 위반 목록(빈 리스트면 계약 PASS)."""
    out = integrity_checks(ev, rd)
    status = ev.get("comparison_status")

    out.append(("스키마 검증",
                "PASS" if not violations else "위반 %d건: %s"
                % (len(violations), " / ".join(violations[:6])),
                "ok" if not violations else "bad"))

    out.append(("schema_version", str(brief.get("schema_version")),
                "ok" if brief.get("schema_version") == SCHEMA_VERSION else "bad"))

    exp = ((raw or {}).get("market_internals") or {}).get("market_close_snapshot") or {}
    exp_as_of = exp.get("as_of") or (raw or {}).get("as_of")
    same = (brief.get("as_of") == exp_as_of) if exp_as_of else None
    out.append(("as_of 일치", "%s (원천 %s)" % (brief.get("as_of"), exp_as_of),
                "ok" if same else ("warn" if same is None else "bad")))

    ids = [s.get("id") for s in brief.get("sections") or [] if isinstance(s, dict)]
    dup = len(ids) - len(set(ids))
    out.append(("섹션 id 중복", "%d건 (총 %d절)" % (dup, len(ids)),
                "ok" if dup == 0 else "bad"))

    tks = sorted({t for s in brief.get("sections") or []
                  if isinstance(s, dict) for t in (s.get("tickers") or [])})
    allow_t, allow_th, _ = build_allowlists(raw or {})
    unknown = [t for t in tks if t not in allow_t]
    out.append(("ticker 정합", "%d종 %s" % (len(tks), ", ".join(tks) if tks else "-")
                + ("" if not unknown else " | 미허용 " + ", ".join(unknown)),
                "ok" if not unknown else "bad"))

    nums = number_conflict(brief)
    out.append(("본문과 요약의 숫자 충돌", "0건" if not nums
                else "%d건: %s" % (len(nums), ", ".join(nums[:8])),
                "ok" if not nums else "bad"))

    kp = brief.get("key_points") or []
    out.append(("핵심 3줄", "%d개" % len(kp), "ok" if len(kp) == 3 else "bad"))

    wp = brief.get("watchpoints") or []
    out.append(("다음 거래일 확인 조건", "%d개" % len(wp),
                "ok" if 1 <= len(wp) <= 3 else "bad"))

    parts = [brief.get("deck") or ""]
    parts += [x for x in kp if isinstance(x, str)]
    parts += [s.get("body") or "" for s in brief.get("sections") or []
              if isinstance(s, dict)]
    parts += [x for x in wp if isinstance(x, str)]
    n = sum(len(p.strip()) for p in parts)
    lo, hi = (1000, 1600) if status == "baseline_only" else (1500, 2500)
    out.append(("분량", "%d자 (기준 %d~%d)" % (n, lo, hi),
                "ok" if lo <= n <= hi else "bad"))

    sr = ev.get("stop_reason")
    out.append(("stop_reason", str(sr), "ok" if sr == "end_turn" else "bad"))
    if status not in ("ready", "baseline_only"):
        out.append(("비교 상태", str(status) + " (허용값 아님)", "bad"))
    else:
        out.append(("비교 상태", str(status), "ok" if status == "ready" else "warn"))
    return out


# ---------------------------------------------------------------- render

def _tr(k, v, mono=False):
    return "<tr><td>%s</td><td%s>%s</td></tr>" % (
        esc(k), ' class="mono"' if mono else "", esc(v))


def _chk_html(checks):
    return "".join(
        '<div class="chk"><span class="%s">%s</span> %s <span class="%s">%s</span></div>'
        % (c[2], "PASS" if c[2] == "ok" else ("WARN" if c[2] == "warn" else "FAIL"),
           esc(c[0]), c[2], esc(c[1]))
        for c in checks)


def _run_info(ev):
    rows = [
        ("현재 기준일", ev.get("current_as_of")),
        ("비교 기준일", ev.get("previous_as_of") or "없음 (baseline)"),
        ("비교 상태", ev.get("comparison_status")),
        ("수집 시각", ev.get("fetch_started_at")),
        ("원천 generated", ev.get("source_generated_at")),
        ("모델", ev.get("model")),
        ("input_tokens", ev.get("input_tokens")),
        ("output_tokens", ev.get("output_tokens")),
        ("cache_read / creation", "%s / %s" % (ev.get("cache_read_input_tokens"),
                                               ev.get("cache_creation_input_tokens"))),
        ("실측 비용", "$%s" % ev.get("cost_usd")),
        ("close_snapshot 상태", ev.get("close_snapshot_state")),
        ("daily 상태", ev.get("daily_state")),
        ("스냅샷 저장", ev.get("snapshot_store_status")),
    ]
    sha_rows = [
        ("snapshot_sha256", ev.get("snapshot_sha256")),
        ("prompt_sha256", ev.get("prompt_sha256")),
        ("output_sha256", ev.get("output_sha256")),
        ("close_snapshot_data_sha256", ev.get("close_snapshot_data_sha256")),
    ]
    return ('<div class="card"><h2>실행 정보 · 비용</h2><table>%s</table></div>'
            '<div class="card"><h2>무결성</h2><table>%s</table></div>'
            % ("".join(_tr(k, v) for k, v in rows),
               "".join(_tr(k, v, True) for k, v in sha_rows)))


def _comparison_card(comparison):
    mc = (comparison or {}).get("market_close_comparison") or {}
    if mc.get("status") != "ready":
        return ""

    def block(title, dct, unit=""):
        if not dct:
            return ""
        items = "".join("<tr><td>%s</td><td>%s%s</td></tr>" % (esc(k), esc(v), esc(unit))
                        for k, v in sorted(dct.items()))
        return "<h2>%s</h2><table>%s</table>" % (esc(title), items)

    vol = mc.get("volatility_change") or {}
    volflat = {k: "%s p (%s%%)" % (v.get("points"), v.get("pct")) for k, v in vol.items()}
    return ('<div class="card">'
            + block("상대수익률 (%p)", mc.get("relative_performance_pct") or {})
            + block("가격 변화율 (%)", mc.get("price_change_pct") or {})
            + block("금리 변화 (bp)", mc.get("rate_change_bp") or {})
            + block("변동성 변화", volflat)
            + "</div>")


def render_structured(run_id, ev, brief, raw, comparison, checks, raw_text):
    kp = "".join('<div class="kp">%s</div>' % esc(x)
                 for x in (brief.get("key_points") or []))

    secs = ""
    for s in (brief.get("sections") or []):
        if not isinstance(s, dict):
            continue
        meta = ""
        tk = [t for t in (s.get("tickers") or []) if isinstance(t, str)]
        th = [t for t in (s.get("themes") or []) if isinstance(t, str)]
        if tk or th:
            meta = ('<div class="meta">'
                    + "".join('<span class="pill">%s</span>' % esc(t) for t in tk)
                    + "".join('<span class="pill">%s</span>' % esc(t) for t in th)
                    + "</div>")
        secs += ('<div class="sec"><div class="sid">%s</div>'
                 '<div class="stitle">%s</div><div class="sbody">%s</div>%s</div>'
                 % (esc(s.get("id")), esc(s.get("title")), esc(s.get("body")), meta))

    wps = "".join('<div class="kp">%s</div>' % esc(x)
                  for x in (brief.get("watchpoints") or []))

    derived = ("<table>"
               + _tr("SNS 요약", brief.get("social_summary"))
               + _tr("이메일 제목", brief.get("email_subject"))
               + _tr("이메일 preview", brief.get("email_preview"))
               + _tr("면책 문구", brief.get("disclaimer"))
               + "</table>")

    return """<!DOCTYPE html><html lang="ko"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>검수 %s</title><style>%s</style></head><body><div class="wrap">
<h1>미국장 매크로 데일리 초안 검수</h1>
<div class="sub">run_id %s &nbsp;|&nbsp; %s &nbsp;|&nbsp; 내부 검수용 파생 문서. 게시물 아님.</div>
%s
<div class="card"><h2>자동 검사 (차단 검사 — FAIL 시 latest 자격 없음)</h2>%s</div>
<div class="card"><h2>제목</h2><div class="hl">%s</div><div class="deck">%s</div></div>
<div class="card"><h2>핵심 3줄</h2>%s</div>
<div class="card"><h2>본문</h2>%s</div>
<div class="card"><h2>다음 거래일 확인 조건</h2>%s</div>
<div class="card"><h2>파생 채널 미리보기</h2>%s</div>
%s
<div class="card"><h2>원시 JSON</h2><pre class="raw">%s</pre></div>
<div class="note">brief.json 과 evidence.json 이 정본이며 response.txt 는 모델 원시 응답 증거입니다.
이 HTML 은 파생 산출물로 언제든 재생성 가능하며 정본을 수정하지 않습니다. 파생 채널 미리보기는
문안일 뿐이며 링크·UTM·공개 URL·게시 상태는 이 계층의 책임이 아닙니다.</div>
</div></body></html>""" % (
        esc(run_id), CSS, esc(run_id), esc(brief.get("schema_version")),
        _run_info(ev), _chk_html(checks),
        esc(brief.get("headline")), esc(brief.get("deck")),
        kp, secs, wps, derived, _comparison_card(comparison), esc(raw_text))


def render_legacy(run_id, ev, text, comparison, checks):
    return """<!DOCTYPE html><html lang="ko"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>검수 %s (legacy)</title><style>%s</style></head><body><div class="wrap">
<h1>미국장 매크로 데일리 초안 검수</h1>
<div class="sub">run_id %s &nbsp;|&nbsp; legacy 산문 run (구조화 이전) &nbsp;|&nbsp; 내부 검수용.</div>
%s
<div class="card"><h2>자동 검사</h2>%s</div>
%s
<div class="card"><h2>초안 전문</h2><div class="body">%s</div></div>
<div class="note">구조화 이전 형식의 run 입니다. latest 자격은 구조화 run 에만 부여됩니다.</div>
</div></body></html>""" % (
        esc(run_id), CSS, esc(run_id), _run_info(ev),
        _chk_html(checks), _comparison_card(comparison), esc(text))


def render_index(runs):
    rows = "".join(
        '<tr><td><a href="runs/%s.html">%s</a></td><td>%s</td><td>%s</td>'
        '<td>%s</td><td>$%s</td><td>%s</td><td>%s</td></tr>'
        % (esc(r["run_id"]), esc(r["run_id"][:15]), esc(r["ev"].get("current_as_of")),
           esc(r["ev"].get("previous_as_of") or "-"), esc(r["ev"].get("comparison_status")),
           esc(r["ev"].get("cost_usd")), esc(r["kind"]),
           "적격" if r["eligible"] else "부적격")
        for r in runs)
    return """<!DOCTYPE html><html lang="ko"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>초안 검수 목록</title><style>%s</style></head><body><div class="wrap">
<h1>미국장 매크로 데일리 초안 검수 목록</h1>
<div class="sub">총 %d건 &nbsp;|&nbsp; 내부 검수용. 게시물 아님.</div>
<div class="card"><table class="idx">
<tr><td>run_id</td><td>기준일</td><td>비교일</td><td>상태</td><td>비용</td><td>형식</td><td>latest 자격</td></tr>
%s</table></div>
<div class="note">최근 검수본은 latest.html 입니다.</div>
</div></body></html>""" % (CSS, len(runs), rows)


# ---------------------------------------------------------------- eligibility

def canonical_checks(rd, ev, brief_file, parsed_resp, comparison):
    """L1-1: brief.json 이 P0-D 정본이다. 존재·상태·SHA·원시응답 일치를 모두 요구한다.
    하나라도 어긋나면 bad -> latest 자격 없음."""
    out = []
    bp = os.path.join(rd, "brief.json")
    present = os.path.isfile(bp)
    out.append(("정본 brief.json", "존재" if present else "없음",
                "ok" if present else "bad"))

    st = ev.get("status")
    out.append(("evidence.status", str(st),
                "ok" if st == "brief_saved" else "bad"))

    rec = ev.get("brief_sha256")
    if not present:
        out.append(("정본 SHA 대조", "brief.json 없음", "bad"))
    elif not rec:
        out.append(("정본 SHA 대조", "evidence.brief_sha256 미기록", "bad"))
    else:
        actual = hashlib.sha256(open(bp, "rb").read()).hexdigest()
        same = (actual == rec)
        out.append(("정본 SHA 대조", "일치" if same else "불일치(변조 의심)",
                    "ok" if same else "bad"))

    if brief_file is None or parsed_resp is None:
        out.append(("원시 응답 대조", "비교 불가(brief.json 또는 응답 파싱 실패)", "bad"))
    else:
        same = (brief_file == parsed_resp)
        out.append(("원시 응답 대조",
                    "brief.json == response.txt" if same
                    else "불일치(정본이 원시 응답과 다름)",
                    "ok" if same else "bad"))

    cs = ((comparison or {}).get("market_close_comparison") or {}).get("status")
    if cs is None:
        out.append(("comparison.json 상태", "파일 없음/미기재", "warn"))
    else:
        same = (cs == ev.get("comparison_status"))
        out.append(("comparison.json 상태",
                    "%s (evidence %s)" % (cs, ev.get("comparison_status")),
                    "ok" if same else "bad"))
    return out


def eligible_for_latest(ev, checks, kind):
    """구조화 run 만 latest 자격을 가진다.
    차단 검사 전건 PASS + evidence.status == brief_saved + brief_sha256 기록 필수."""
    if kind != "structured":
        return False
    if ev.get("status") != "brief_saved" or not ev.get("brief_sha256"):
        return False
    base = (ev.get("stop_reason") == "end_turn"
            and ev.get("close_snapshot_state") == "fresh"
            and ev.get("daily_state") == "fresh"
            and ev.get("comparison_status") in {"baseline_only", "ready"}
            and bool(ev.get("output_sha256")))
    if not base or checks is None:
        return False
    return not any(c[2] == "bad" for c in checks)


# ---------------------------------------------------------------- main

def _load(path):
    try:
        return json.load(open(path, encoding="utf-8"))
    except Exception:
        return None


def main():
    if not os.path.isdir(EVIDIR):
        print("no evidence dir:", EVIDIR)
        return 1
    os.makedirs(REVDIR, exist_ok=True)
    os.makedirs(os.path.join(REVDIR, "runs"), exist_ok=True)

    runs = []
    for rid in sorted(os.listdir(EVIDIR)):
        rd = os.path.join(EVIDIR, rid)
        ep = os.path.join(rd, "evidence.json")
        rp = os.path.join(rd, "response.txt")
        if not (os.path.isfile(ep) and os.path.isfile(rp)):
            continue
        ev = _load(ep) or {}
        text = open(rp, encoding="utf-8").read()
        raw = _load(os.path.join(rd, "briefing_context_raw.json"))
        cmpj = _load(os.path.join(rd, "comparison.json"))

        brief_file = _load(os.path.join(rd, "brief.json"))
        if not (isinstance(brief_file, dict)
                and brief_file.get("schema_version") == SCHEMA_VERSION):
            brief_file = None
        try:
            parsed_resp = parse_model_output(text)
            if not (isinstance(parsed_resp, dict)
                    and parsed_resp.get("schema_version") == SCHEMA_VERSION):
                parsed_resp = None
        except ContractError:
            parsed_resp = None

        # 정본은 brief.json. 없으면 원시 응답으로 복구 렌더만 하고 반드시 부적격 처리한다.
        brief = brief_file if brief_file is not None else parsed_resp

        if brief is None:
            kind = "legacy"
            checks = integrity_checks(ev, rd) + [
                ("형식", "구조화 이전 산문 run", "warn"),
                ("stop_reason", str(ev.get("stop_reason")),
                 "ok" if ev.get("stop_reason") == "end_turn" else "bad"),
                ("분량", "%d자" % len(text), "warn"),
            ]
            h = render_legacy(rid, ev, text, cmpj, checks)
        else:
            kind = "structured"
            violations = []
            try:
                validate_brief(brief, raw or {}, ev.get("comparison_status"))
            except ContractError as e:
                violations = e.violations
            checks = (canonical_checks(rd, ev, brief_file, parsed_resp, cmpj)
                      + run_checks_structured(brief, ev, raw, rd, violations))
            h = render_structured(rid, ev, brief, raw, cmpj, checks, text)

        elig = eligible_for_latest(ev, checks, kind)

        tmp = os.path.join(rd, "review.html.tmp")
        open(tmp, "w", encoding="utf-8").write(h)
        os.replace(tmp, os.path.join(rd, "review.html"))
        tmp2 = os.path.join(REVDIR, "runs", rid + ".html.tmp")
        open(tmp2, "w", encoding="utf-8").write(h)
        os.replace(tmp2, os.path.join(REVDIR, "runs", rid + ".html"))

        runs.append({"run_id": rid, "ev": ev, "html": h,
                     "eligible": elig, "kind": kind})
        nbad = sum(1 for c in checks if c[2] == "bad")
        print("review.html ->", os.path.join(rd, "review.html"),
              "| %s" % kind, "| 검사FAIL %d건" % nbad,
              "| latest자격:", "O" if elig else "X")

    if not runs:
        print("no successful runs found")
        return 0

    runs.sort(key=lambda r: r["run_id"], reverse=True)
    tmp = os.path.join(REVDIR, "index.html.tmp")
    open(tmp, "w", encoding="utf-8").write(render_index(runs))
    os.replace(tmp, os.path.join(REVDIR, "index.html"))
    print("index.html   ->", os.path.join(REVDIR, "index.html"))

    elig = [r for r in runs if r["eligible"]]
    if elig:
        tmp = os.path.join(REVDIR, "latest.html.tmp")
        open(tmp, "w", encoding="utf-8").write(elig[0]["html"])
        os.replace(tmp, os.path.join(REVDIR, "latest.html"))
        print("latest.html  ->", os.path.join(REVDIR, "latest.html"),
              "(run %s)" % elig[0]["run_id"])
    else:
        print("latest.html  -> 갱신 안 함 (적격 run 없음, 기존 latest 유지)")
    print("REVIEW BUILD: DONE (%d runs)" % len(runs))
    return 0


if __name__ == "__main__":
    sys.exit(main())
